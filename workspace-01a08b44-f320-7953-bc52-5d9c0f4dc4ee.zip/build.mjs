#!/usr/bin/env node
// ===========================================================================
//  AGER build  —  bundles the engine (and optionally a game) into a single
//  self-contained HTML file. No bundler, no node_modules, no CDN.
//
//    node build.mjs             # engine + smoke test  -> dist/ager.html
//    node build.mjs --game      # engine + CRUCIBLE    -> dist/index.html
//    node build.mjs --dev       # dist/ager.dev.js (unminified, for tooling)
// ===========================================================================
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

const root = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const withGame = args.includes('--game');
const dev = args.includes('--dev');

const ENGINE_SOURCES = [
  'ager/src/00-core.js',
  'ager/src/10-gl.js',
  'ager/src/20-textures.js',
  'ager/src/30-geometry.js',
  'ager/src/40-material.js',
  'ager/src/50-render.js',
  'ager/src/55-particles.js',
  'ager/src/60-scene.js',
  'ager/src/70-physics.js',
  'ager/src/80-audio.js',
  'ager/src/90-input.js',
  'ager/src/95-ai.js',
  'ager/src/99-ager.js',
];

const GAME_SOURCES = [
  'game/src/100-main.js',
  'game/src/110-world.js',
  'game/src/120-player.js',
  'game/src/130-enemies.js',
  'game/src/140-hud.js',
  'game/src/150-vfx.js',
  'game/src/160-audio.js',
  'game/src/170-game.js',
];

const SMOKE = 'tools/smoke-entry.js';

function read(rel) {
  const p = join(root, rel);
  if (!existsSync(p)) throw new Error('missing source: ' + rel);
  return readFileSync(p, 'utf8');
}

function bundle(files, { wrap = true } = {}) {
  const parts = files.map(f => {
    const src = read(f);
    return `\n// ============ ${f} ============\n` + src;
  });
  const body = parts.join('\n');
  if (!wrap) return body;
  const exports = `
// --- expose the engine (Ager is meant to be scriptable from the console) ---
if (typeof window !== 'undefined') {
  window.Ager = Ager;
  window.AGER = { Ager, Engine, MaterialLib, Material, Scene, Node, Light, Mesh, InstancedMesh, Camera,
    Vec3, Quat, Mat4, AABB, Frustum, Geometry, TexLab, TexData, SkyModel, AgerAI, Program, GPUMesh, InstanceBuffer,
    RenderTarget, CubeTarget, PhysicsWorld, Collider, KinematicBody, AudioEngine, MusicDirector, TAU, PI_HALF: Math.PI/2,
    DEG, RAD, clamp, lerp, smoothstep, damp, fract, fbm2, fbm3, fbm2t, valueNoise2, hash2, randRange, pick, now };
}`;
  return `(function(){\n'use strict';\n${body}\n${exports}\n})();`;
}

function page({ title, script, extraHead = '', bodyHtml = '' }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>${title}</title>
<style>
  html,body{margin:0;padding:0;height:100%;background:#05070a;overflow:hidden;color:#cfe9f5;
    font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;-webkit-font-smoothing:antialiased}
  canvas{display:block;width:100%;height:100%}
  *{box-sizing:border-box}
  ::selection{background:#1d6f8f;color:#fff}
  #ager-boot{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;
    background:radial-gradient(circle at 50% 40%, #0b1620, #04070a 70%);z-index:50;transition:opacity .6s}
  #ager-boot h1{font-size:clamp(30px,7vw,64px);letter-spacing:.34em;margin:0 0 6px;color:#dff6ff;
    text-shadow:0 0 26px rgba(70,200,255,.45);font-weight:600}
  #ager-boot .sub{opacity:.65;font-size:12px;letter-spacing:.28em;text-transform:uppercase;margin-bottom:26px}
  #ager-boot .bar{width:min(420px,72vw);height:3px;background:rgba(120,200,255,.14);overflow:hidden}
  #ager-boot .bar i{display:block;height:100%;width:0%;background:linear-gradient(90deg,#39e2ff,#ffb457);transition:width .2s}
  #ager-boot .st{margin-top:12px;font-size:11px;opacity:.55;letter-spacing:.16em}
</style>
${extraHead}
</head>
<body>
${bodyHtml}
<script>
${script}
</script>
</body>
</html>`;
}

const BOOT_HTML = `<div id="ager-boot"><h1>AGER</h1><div class="sub">engine · v${'1.0.0'}</div><div class="bar"><i id="ager-boot-bar"></i></div><div class="st" id="ager-boot-st">booting</div></div>`;

mkdirSync(join(root, 'dist'), { recursive: true });

if (dev) {
  const js = bundle([...ENGINE_SOURCES, ...(withGame ? GAME_SOURCES : [SMOKE])], { wrap: false });
  writeFileSync(join(root, 'dist/ager.dev.js'), js);
  console.log(`dist/ager.dev.js  ${(js.length / 1024).toFixed(1)} kB`);
}

const files = [...ENGINE_SOURCES, ...(withGame ? GAME_SOURCES : [SMOKE])];
const files2 = files.filter(f => existsSync(join(root, f)));
if (files2.length !== files.length) {
  const missing = files.filter(f => !existsSync(join(root, f)));
  console.log('  ! missing ' + missing.map(f => f.split('/').pop()).join(', '));
}
const js = bundle(files2);
const title = withGame ? 'AGER · CRUCIBLE' : 'AGER engine · smoke test';
const html = page({ title, script: js, bodyHtml: BOOT_HTML });
const out = withGame ? 'dist/index.html' : 'dist/ager.html';
writeFileSync(join(root, out), html);
console.log(`${out}  ${(html.length / 1024).toFixed(1)} kB  (${files2.length} sources)`);
const engineOnly = bundle(ENGINE_SOURCES.filter(f => existsSync(join(root, f))));
writeFileSync(join(root, 'dist/ager.js'), engineOnly);
console.log(`dist/ager.js  ${(engineOnly.length / 1024).toFixed(1)} kB  (engine only)`);
