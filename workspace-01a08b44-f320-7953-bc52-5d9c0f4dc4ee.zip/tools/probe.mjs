import puppeteer from 'puppeteer';
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file:///home/user/dist/ager.html', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
await new Promise(r=>setTimeout(r,1500));
const info = await p.evaluate(() => {
  const { SkyModel } = window.AGER;
  const e = window.AGER.Engine, R = e.renderer, S = e.scene;
  return {
    sh: Array.from(R.ambientSH).map(v => +v.toFixed(3)),
    sun: { dir: Array.from(S.sun.direction).map(v=>+v.toFixed(3)), int: S.sun.intensity, col: S.sun.color },
    skyInt: S.sky.intensity, boost: S.sky.ambientBoost,
    envCubeSize: R.envCube.size,
    skySample: SkyModel.sample([0,1,0]).map(v=>+v.toFixed(3)),
    skySampleSun: SkyModel.sample(S.sun.direction).map(v=>+v.toFixed(3)),
    fog: S.fog,
    lights: S.pointLights.length + S.spotLights.length,
    exposure: R.exposure,
    lightState: R.lightState ? { sunI: R.lightState.sunIntensity, p: R.lightState.pointCount, s: R.lightState.spotCount } : null,
    quality: R.quality, res: R.width + 'x' + R.height,
  };
});
console.log(JSON.stringify(info, null, 1));
await b.close();
