import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--mute-audio']});
const p = await b.newPage();
await p.setViewport({width:800,height:450});
p.on('pageerror', e => console.log('PAGEERROR:', e.message, '\n   ', (e.stack||'').split('\n').slice(1,4).join('\n    ')));
p.on('console', m => { const t=m.text(); if (/error|warn/i.test(t) && !/mipmap|Multiple instances/i.test(t)) console.log('['+m.type()+']', t.slice(0,400)); });
await p.goto('file://'+join(root,'dist/index.html')+'?quality=low', {waitUntil:'domcontentloaded'});
try {
  await p.waitForFunction('window.__AGER_READY__ === true', {timeout:180000, polling:300});
  console.log('READY');
} catch(e) {
  console.log('NOT READY');
  const errs = await p.evaluate(() => window.__AGER_ERRORS__ || []);
  console.log(JSON.stringify(errs.slice(-6), null, 1));
  await p.screenshot({path:'/tmp/game-boot-fail.png'});
  await b.close(); process.exit(1);
}
// click DEPLOY
await p.evaluate(() => { const b2 = document.getElementById('play'); if (b2) b2.click(); });
await new Promise(r=>setTimeout(r, 2500));
const info = await p.evaluate(() => {
  const G = window.AGER_GAME;
  return { state: G.Game.state, wave: G.Waves.wave, enemies: G.Game.enemies.length,
    playerHp: G.Player.health, pos: Array.from(G.Player.pos).map(v=>+v.toFixed(2)),
    stats: window.AGER.Ager.stats(), grounded: G.Player.grounded };
});
console.log('after deploy:', JSON.stringify(info));
// run the game for a while, force a wave and combat
await p.evaluate(() => { window.AGER_GAME.Waves.start(2); });
await p.evaluate(() => window.AGER_GAME.Game.say ? 0 : 0);
for (let i=0;i<6;i++){
  await new Promise(r=>setTimeout(r, 2000));
  const s = await p.evaluate(() => {
    const G = window.AGER_GAME;
    return { t:+window.AGER.Engine.time.toFixed(1), enemies:G.Game.enemies.filter(e=>e.alive).length,
      hp:Math.round(G.Player.health), sh:Math.round(G.Player.shield), core:Math.round(G.Game.coreHealth), score:G.Game.score,
      draws:window.AGER.Engine.renderer.stats.drawCalls, tris:Math.round(window.AGER.Engine.renderer.stats.triangles/1000),
      fps:Math.round(window.AGER.Engine.clock.fps), kills:G.Game.kills };
  });
  console.log('t+' + (i*2+2) + 's', JSON.stringify(s));
}
// fire the weapon + nova + grenade via the game API
await p.evaluate(() => {
  const P = window.AGER_GAME.Player;
  P.tryFire(0.016); P.throwGrenade(); P.pulseNova();
  window.AGER_GAME.Game.spawnGrenade([P.pos[0], P.pos[1]+1.5, P.pos[2]], [4,6,4]);
});
await new Promise(r=>setTimeout(r,1200));
const after = await p.evaluate(() => {
  const G = window.AGER_GAME;
  return { enemies:G.Game.enemies.filter(e=>e.alive).length, proj:G.Projectiles.list.length, kills:G.Game.kills,
    particles:Object.fromEntries(Object.entries(window.AGER.FX ? {} : {})), errs:(window.__AGER_ERRORS__||[]).length };
});
console.log('after firing:', JSON.stringify(after));
await p.screenshot({path:'/tmp/game-combat.png'});
const errs = await p.evaluate(() => window.__AGER_ERRORS__ || []);
if (errs.length) { console.log('ERRORS:'); errs.slice(-8).forEach(e=>console.log(' -', String(e).slice(0,300))); }
await b.close();
