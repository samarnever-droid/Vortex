import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:480,height:270});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file://'+join(root,'dist/ager.html')+'?quality=low', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
await p.evaluate(() => {
  const { Engine } = window.AGER, S = Engine.scene, R = Engine.renderer;
  Engine.callbacks.update.length = 0;
  S.meshes.forEach(m => { m.visible = (m.tag === 'ground'); });
  S.setSunFromAngles(52*Math.PI/180, 130*Math.PI/180, [1.0,0.97,0.93], 3.4);
  S.sky.night=0; S.sky.turbidity=0.4; S.sky.intensity=1; S.sky.ambientBoost=1;
  S.fog.enabled=false; S.fog.density=0.0006;
  R.enableBloom=false; R.enableSSAO=false; R.enableGodrays=false; R.enableFXAA=false; R.grain=0; R.chroma=0; R.vignette=0;
  R.envDirty = true;
  // camera: authored once, then the rotation is applied via a manual quaternion
  Engine.camera.setPosition(0, 6, 20);
  S.updateWorldMatrix();
  Engine.camera.lookAt([0, 0, 0]);
  Engine.camera.updateWorldMatrix();
  Engine.callbacks.render.push(() => { Engine.camera.updateWorldMatrix(); });
});
for (const v of [10,11,12,13,14]) {
  await p.evaluate((vv) => { window.AGER.Engine.renderer.debugView = vv; }, v);
  await new Promise(r=>setTimeout(r,1100));
  const path = `/tmp/p10-v${v}.png`;
  await p.screenshot({path});
  const s = stats(path);
  console.log('view ' + v, 'ground=' + s.groundMean, 'center=' + s.centerMean, 'mean=' + s.mean);
}
await b.close();
