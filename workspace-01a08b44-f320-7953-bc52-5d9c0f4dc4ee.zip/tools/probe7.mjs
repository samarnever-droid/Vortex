import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file://'+join(root,'dist/ager.html')+'?quality=low', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
await p.evaluate(() => {
  const S = window.AGER.Engine.scene, R = window.AGER.Engine.renderer;
  S.setSunFromAngles(52*Math.PI/180, 130*Math.PI/180, [1.0,0.97,0.93], 3.4);
  S.sky.night=0; S.sky.turbidity=0.4; S.sky.intensity=1; S.sky.ambientBoost=1;
  S.fog.enabled=false; S.fog.density=0.0006;
  S.meshes.forEach(m => { if (m.tag === 'ground') m.material = window.AGER.MaterialLib.get('concrete'); });
  R.enableBloom=false; R.enableSSAO=false; R.enableGodrays=false; R.enableFXAA=false; R.grain=0; R.chroma=0; R.vignette=0;
  R.envDirty = true;
});
for (const v of [0,1,2,3,4,5,6,7,8,9]) {
  await p.evaluate((vv) => { window.AGER.Engine.renderer.debugView = vv; }, v);
  await new Promise(r=>setTimeout(r,1100));
  const path = `/tmp/p7-${v}.png`;
  await p.screenshot({path});
  const s = stats(path);
  console.log('debugView ' + v, 'mean='+s.mean, 'ground='+s.groundMean, 'center='+s.centerMean);
}
await b.close();
