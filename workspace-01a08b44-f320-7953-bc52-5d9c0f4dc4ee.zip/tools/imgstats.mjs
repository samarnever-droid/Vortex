#!/usr/bin/env node
// Minimal PNG reader + image statistics, used to verify the renderer output
// objectively (mean luminance, region breakdown, histogram) without any deps.
import { readFileSync } from 'node:fs';
import { inflateSync } from 'node:zlib';

export function decodePNG(path) {
  const buf = readFileSync(path);
  if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('not a png');
  let pos = 8, width = 0, height = 0, bitDepth = 0, colorType = 0, idat = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos);
    const type = buf.toString('ascii', pos + 4, pos + 8);
    const data = buf.subarray(pos + 8, pos + 8 + len);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0); height = data.readUInt32BE(4);
      bitDepth = data[8]; colorType = data[9];
    } else if (type === 'IDAT') idat.push(data);
    else if (type === 'IEND') break;
    pos += 12 + len;
  }
  const raw = inflateSync(Buffer.concat(idat));
  const channels = colorType === 6 ? 4 : (colorType === 2 ? 3 : (colorType === 0 ? 1 : 4));
  const bpp = channels * (bitDepth / 8);
  const stride = width * bpp;
  const out = Buffer.alloc(height * stride);
  let rp = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[rp++];
    const row = raw.subarray(rp, rp + stride); rp += stride;
    const prev = y > 0 ? out.subarray((y - 1) * stride, y * stride) : Buffer.alloc(stride);
    const cur = out.subarray(y * stride, (y + 1) * stride);
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? cur[x - bpp] : 0;
      const b = prev[x];
      const c = x >= bpp ? prev[x - bpp] : 0;
      let v = row[x];
      switch (filter) {
        case 1: v = v + a; break;
        case 2: v = v + b; break;
        case 3: v = v + ((a + b) >> 1); break;
        case 4: {
          const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
          v = v + (pa <= pb && pa <= pc ? a : (pb <= pc ? b : c));
          break;
        }
      }
      cur[x] = v & 255;
    }
  }
  return { width, height, channels, data: out };
}

export function stats(path, opts = {}) {
  const img = decodePNG(path);
  const { width: w, height: h, channels: ch, data } = img;
  const lum = (i) => (0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2]) / 255;
  let sum = 0, n = 0, max = 0, dark = 0, bright = 0;
  let skySum = 0, skyN = 0, groundSum = 0, groundN = 0, centerSum = 0, centerN = 0;
  const hist = new Array(10).fill(0);
  for (let y = 0; y < h; y += 2) {
    for (let x = 0; x < w; x += 2) {
      const i = (y * w + x) * ch;
      const l = lum(i);
      sum += l; n++;
      if (l > max) max = l;
      if (l < 0.02) dark++;
      if (l > 0.9) bright++;
      hist[Math.min(9, Math.floor(l * 10))]++;
      // NB: images are top-down; the sky/horizon band is the upper third
      if (y < h * 0.35) { skySum += l; skyN++; }
      else { groundSum += l; groundN++; }
      if (x > w * 0.3 && x < w * 0.7 && y > h * 0.35 && y < h * 0.75) { centerSum += l; centerN++; }
    }
  }
  return {
    size: `${w}x${h}`,
    mean: +(sum / n).toFixed(4),
    max: +max.toFixed(3),
    darkFrac: +(dark / n).toFixed(3),
    blownFrac: +(bright / n).toFixed(3),
    skyMean: +(skySum / Math.max(1, skyN)).toFixed(4),
    groundMean: +(groundSum / Math.max(1, groundN)).toFixed(4),
    centerMean: +(centerSum / Math.max(1, centerN)).toFixed(4),
    histogram: hist.map(v => +(v / n).toFixed(3)),
  };
}

if (process.argv[1] && process.argv[1].endsWith('imgstats.mjs')) {
  for (const f of process.argv.slice(2)) {
    console.log(f, JSON.stringify(stats(f)));
  }
}
