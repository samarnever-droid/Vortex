#!/usr/bin/env node
// ===========================================================================
//  tools/photo.mjs — headless capture harness
//  Renders the built page in Chromium (SwiftShader), drives the scripted
//  shot list the game exposes and writes docs/shots/*.png + a report.
//
//  node tools/photo.mjs                 # dist/ager.html (smoke test)
//  node tools/photo.mjs --game          # dist/index.html (CRUCIBLE)
//  node tools/photo.mjs --game --size=1600x900 --only=combat,nova
// ===========================================================================
import puppeteer from 'puppeteer';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const game = args.includes('--game');
const sizeArg = (args.find(a => a.startsWith('--size=')) || '--size=1280x720').split('=')[1];
const [W, H] = sizeArg.split('x').map(Number);
const only = (args.find(a => a.startsWith('--only=')) || '').split('=')[1];
const onlyList = only ? only.split(',') : null;
const url = 'file://' + join(root, game ? 'dist/index.html' : 'dist/ager.html') + '?quality=low&stats=0&pose=' + (game ? (onlyList ? onlyList[0] : '01-arena') : '');

mkdirSync(join(root, 'docs/shots'), { recursive: true });

const browser = await puppeteer.launch({
  headless: 'shell',
  args: [
    '--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage',
    '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
    '--ignore-gpu-blocklist', '--enable-webgl', '--disable-gpu-sandbox',
    `--window-size=${W},${H}`, '--hide-scrollbars', '--mute-audio',
    '--js-flags=--max-old-space-size=1024',
  ],
});

const page = await browser.newPage();
await page.setViewport({ width: W, height: H, deviceScaleFactor: 1 });
const logs = [];
page.on('console', m => logs.push(`[${m.type()}] ${m.text()}`));
page.on('pageerror', e => logs.push('[pageerror] ' + e.message));
page.on('requestfailed', r => logs.push('[requestfailed] ' + r.url()));

await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
try {
  await page.waitForFunction('window.__AGER_READY__ === true', { timeout: 180000, polling: 250 });
} catch (e) {
  console.log('!! page never became ready');
  console.log(logs.slice(-40).join('\n'));
  const errors = await page.evaluate(() => window.__AGER_ERRORS__ || []);
  console.log('engine errors:', JSON.stringify(errors, null, 2));
  await page.screenshot({ path: join(root, 'docs/shots/00-failed.png') });
  await browser.close();
  process.exit(1);
}

const shotList = await page.evaluate(() => window.__AGER_SHOT_LIST__ || []);
const hasPose = await page.evaluate(() => typeof window.__AGER_POSE__ === 'function');
const names = shotList.length ? shotList : ['shot'];
const results = [];
for (const name of names) {
  if (onlyList && !onlyList.includes(name)) continue;
  if (hasPose) {
    await page.evaluate(async (n) => { await window.__AGER_POSE__(n); }, name);
  }
  // let a few frames render (software rasteriser is slow)
  await page.evaluate(() => new Promise(r => setTimeout(r, 700)));
  await page.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
  const path = join(root, 'docs/shots', `${name}.png`);
  await page.screenshot({ path });
  const stats = await page.evaluate(() => (window.Ager ? window.Ager.stats() : {}));
  results.push({ name, stats });
  console.log(`  saved docs/shots/${name}.png   ${stats.fps || 0}fps ${stats.drawCalls || 0} draws ${((stats.triangles || 0) / 1000).toFixed(0)}k tris`);
}

const errors = await page.evaluate(() => window.__AGER_ERRORS__ || []);
const report = { url, size: `${W}x${H}`, shots: results, consoleErrors: logs.filter(l => /error|fail|warn/i.test(l)).slice(0, 30), engineErrors: errors };
writeFileSync(join(root, 'docs/shots/report.json'), JSON.stringify(report, null, 2));
if (errors.length) {
  console.log('\n!! ' + errors.length + ' engine errors:');
  errors.slice(0, 12).forEach(e => console.log('   ' + e));
}
const warn = logs.filter(l => /error|warn/i.test(l)).slice(0, 10);
if (warn.length) { console.log('\nconsole:'); warn.forEach(l => console.log('   ' + l.slice(0, 200))); }
console.log('done');
await browser.close();
process.exit(errors.length ? 0 : 0);
