import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
p.on('console', m => { if (m.type()==='error') console.log('[err]', m.text().slice(0,300)); });
await p.goto('file://'+join(root,'dist/ager.html')+'?quality=low', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
await p.evaluate(() => {
  const { Engine } = window.AGER, S = Engine.scene, R = Engine.renderer;
  Engine.callbacks.update.length = 0;                       // stop the orbit camera
  S.meshes.forEach(m => { m.visible = (m.tag === 'ground'); });
  S.setSunFromAngles(52*Math.PI/180, 130*Math.PI/180, [1.0,0.97,0.93], 3.4);
  S.sky.night=0; S.sky.turbidity=0.4; S.sky.intensity=1; S.sky.ambientBoost=1;
  S.fog.enabled=false; S.fog.density=0.0006;
  R.enableBloom=false; R.enableSSAO=false; R.enableGodrays=false; R.enableFXAA=false; R.grain=0; R.chroma=0; R.vignette=0;
  R.envDirty = true;
  Engine.camera.setPosition(0, 8, 26); S.updateWorldMatrix(); Engine.camera.lookAt([0,0,0]);
  window.__SETCA__ = () => { Engine.camera.setPosition(0, 8, 26); S.updateWorldMatrix(); Engine.camera.lookAt([0,0,0]); };
  window.__SETMAT__ = (n) => { S.meshes.forEach(m => { if (m.tag==='ground') m.material = window.AGER.MaterialLib.get(n); }); };
});
await p.evaluate(() => window.__SETCA__());
for (const mat of ['concrete','metal','crate','sand']) {
  await p.evaluate((m) => window.__SETMAT__(m), mat);
  await p.evaluate(() => window.__SETCA__());
  await new Promise(r=>setTimeout(r,1200));
  const path = `/tmp/p8-${mat}.png`;
  await p.screenshot({path});
  const s = stats(path);
  const info = await p.evaluate(() => { const st = window.AGER.Engine.renderer.stats; return { drawn: st.drawn, calls: st.drawCalls, tris: st.triangles }; });
  console.log(mat.padEnd(10), 'ground='+s.groundMean, 'center='+s.centerMean, JSON.stringify(info));
}
await b.close();
