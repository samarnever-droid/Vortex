import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file://'+join(root,'dist/ager.html')+'?quality=low', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
await p.evaluate(() => {
  window.__POST__ = (on) => {
    const R = window.AGER.Engine.renderer;
    R.enableBloom = on; R.enableSSAO = on; R.enableGodrays = on; R.enableFXAA = on;
    R.grain = on ? 0.022 : 0; R.chroma = on ? 0.0028 : 0; R.vignette = on ? 0.3 : 0;
  };
  window.__MAT__ = (name) => {
    const S = window.AGER.Engine.scene;
    S.meshes.forEach(m => { if (m.tag === 'ground') m.material = name === 'unlit' ? new window.AGER.Material({color:0xffffff, unlit:true}) : window.AGER.MaterialLib.get(name); });
  };
  const S = window.AGER.Engine.scene, R = window.AGER.Engine.renderer;
  S.setSunFromAngles(52*Math.PI/180, 130*Math.PI/180, [1.0,0.97,0.93], 3.4);
  S.sky.night=0; S.sky.turbidity=0.4; S.sky.intensity=1; S.sky.ambientBoost=1;
  S.fog.enabled=false; S.fog.density=0.0006;
});
const tests = [
  ['unlit_postoff', () => { window.__POST__(false); window.__MAT__('unlit'); }],
  ['unlit_poston', () => { window.__POST__(true); window.__MAT__('unlit'); }],
  ['basalt_postoff', () => { window.__POST__(false); window.__MAT__('basalt'); }],
  ['concrete_postoff', () => { window.__POST__(false); window.__MAT__('concrete'); }],
];
for (const [name, fn] of tests) {
  await p.evaluate(fn);
  await new Promise(r=>setTimeout(r,1200));
  const path = `/tmp/p6-${name}.png`;
  await p.screenshot({path});
  const s = stats(path);
  console.log(name.padEnd(16), 'mean='+s.mean, 'ground='+s.groundMean, 'center='+s.centerMean);
}
await b.close();
