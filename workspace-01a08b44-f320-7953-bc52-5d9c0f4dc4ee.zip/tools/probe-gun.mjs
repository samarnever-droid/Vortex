import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--mute-audio']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file://'+join(root,'dist/index.html')+'?quality=low&pose=07-gameplay&hud=0', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:180000, polling:300});
const info = await p.evaluate(() => {
  const G = window.AGER_GAME, E = window.AGER.Engine;
  const vm = G.Player.view;
  const world = vm.root.worldMatrix;
  const cam = E.camera;
  const list = E.scene.renderList.map(m => m.name);
  return {
    camPos: Array.from(cam.position).map(v=>+v.toFixed(2)),
    camQuat: Array.from(cam.quaternion).map(v=>+v.toFixed(3)),
    vmParent: vm.root.parent ? vm.root.parent.name : null,
    vmPos: Array.from(vm.root.position).map(v=>+v.toFixed(3)),
    vmScale: Array.from(vm.root.scale).map(v=>+v.toFixed(3)),
    vmWorld: [world[12], world[13], world[14]].map(v=>+v.toFixed(2)),
    vmVisible: vm.root.visible, bodyVisible: vm.body.visible,
    bodyWorld: Array.from(vm.body.worldMatrix).slice(12,15).map(v=>+v.toFixed(2)),
    inRenderList: list.filter(n => n === 'mesh').length,
    totalList: list.length,
    camNear: cam.near,
    bodyMat: vm.body.material.name, bodyTransparent: vm.body.material.transparent,
    bodyBounds: [vm.body._worldCenter ? vm.body._worldCenter.map(v=>+v.toFixed(2)) : null, vm.body._worldRadius],
    drawNames: E.renderer.stats ? Object.keys(E.renderer.stats.drawn || {}).join(',') : '',
  };
});
console.log(JSON.stringify(info, null, 1));
await b.close();
