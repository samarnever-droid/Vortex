import puppeteer from 'puppeteer';
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file:///home/user/dist/ager.html', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
// sample the framebuffer right after render, inside the same frame
await p.evaluate(() => {
  const { Engine } = window.AGER;
  const gl = Engine.device.gl;
  window.__PROBE__ = { full: 0, noSun: 0, noAmbient: 0, envOnly: 0, samples: [] };
  let mode = 'full';
  window.__SETMODE__ = (m) => { mode = m; const r = Engine.renderer; r.debugNoSun = (m === 'noSun'); r.debugNoAmbient = (m === 'noAmbient'); };
  Engine.on('render', () => {
    const w = gl.drawingBufferWidth, h = gl.drawingBufferHeight;
    const px = new Uint8Array(4 * 16);
    let sum = 0, n = 0;
    for (let i = 0; i < 16; i++) {
      const x = Math.floor(w * (0.15 + 0.7 * Math.random()));
      const y = Math.floor(h * (0.1 + 0.7 * Math.random()));
      gl.readPixels(x, y, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px);
      sum += (px[0] + px[1] + px[2]) / 3; n++;
    }
    window.__PROBE__[mode] = sum / n;
  });
});
for (const mode of ['full', 'noSun', 'noAmbient']) {
  await p.evaluate((m) => window.__SETMODE__(m), mode);
  await new Promise(r => setTimeout(r, 1600));
}
const out = await p.evaluate(() => window.__PROBE__);
console.log(JSON.stringify(out));
await b.close();
