#!/usr/bin/env node
// Lighting diagnostics: render the same frame under different configurations
// and report objective luminance stats for each.
import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
const p = await b.newPage();
await p.setViewport({ width: 640, height: 360 });
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
p.on('console', m => { const t = m.text(); if (/error|warn/i.test(t) && !/mipmap/.test(t)) console.log('[js]', t.slice(0, 200)); });
await p.goto('file://' + join(root, 'dist/ager.html') + '?quality=low', { waitUntil: 'domcontentloaded' });
await p.waitForFunction('window.__AGER_READY__ === true', { timeout: 120000, polling: 200 });

const configs = {
  A_baseline: () => {},
  B_noSun: () => { window.AGER.Engine.scene.sun.intensity = 0; },
  C_noAmbient: () => { window.AGER.Engine.scene.sky.intensity = 0; window.AGER.Engine.renderer.ambientBoost = 0; },
  D_noFogNoSSAO: () => { window.AGER.Engine.renderer.enableSSAO = false; window.AGER.Engine.scene.fog.enabled = false; window.AGER.Engine.scene.fog.density = 0; },
  E_plainMats: () => {
    const S = window.AGER.Engine.scene;
    S.meshes.forEach(m => { if (m.tag === 'ground') m.material = window.AGER.MaterialLib.get('basalt'); else if (m.tag === 'prop') m.material = window.AGER.MaterialLib.get('concrete'); });
  },
  F_noon: () => {
    const S = window.AGER.Engine.scene;
    S.setSunFromAngles(58 * Math.PI / 180, 130 * Math.PI / 180, [1.0, 0.97, 0.92], 3.4);
    S.sky.night = 0; S.sky.turbidity = 0.4;
    window.AGER.Engine.renderer.envDirty = true;
  },
  G_allOff: () => {
    const R = window.AGER.Engine.renderer;
    R.enableBloom = false; R.enableSSAO = false; R.enableGodrays = false; R.chroma = 0; R.grain = 0; R.vignette = 0;
  },
};

for (const [name, fn] of Object.entries(configs)) {
  await p.evaluate(fn);
  await new Promise(r => setTimeout(r, 1400));
  const path = `/tmp/probe-${name}.png`;
  await p.screenshot({ path });
  const s = stats(path);
  console.log(name.padEnd(16), 'mean=' + s.mean, 'sky=' + s.skyMean, 'ground=' + s.groundMean, 'center=' + s.centerMean, 'dark=' + s.darkFrac, 'blown=' + s.blownFrac);
}
await b.close();
