import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--mute-audio']});
const p = await b.newPage();
let count = 0, cur = 'all';
p.on('console', m => { if (/Two textures/.test(m.text())) count++; });
await p.goto('file://'+join(root,'dist/index.html')+'?quality=low&hud=0', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:180000, polling:300});
await p.evaluate(() => { const b2=document.getElementById('play'); if (b2) b2.click(); });
const toggles = {
  water: () => { window.AGER.Engine.renderer.enableWater = false; },
  godrays: () => { window.AGER.Engine.renderer.enableGodrays = false; },
  ssao: () => { window.AGER.Engine.renderer.enableSSAO = false; },
  bloom: () => { window.AGER.Engine.renderer.enableBloom = false; },
  shadows: () => { window.AGER.Engine.scene.sun.castShadow = false; window.AGER.Engine.scene.spotLights.forEach(s=>s.castShadow=false); },
};
for (const [name, fn] of Object.entries(toggles)) {
  cur = name; count = 0;
  await p.evaluate(fn);
  await new Promise(r=>setTimeout(r,1500));
  console.log(name.padEnd(10), 'warnings after toggle:', count);
}
await b.close();
