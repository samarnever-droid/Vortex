import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file://'+join(root,'dist/ager.html')+'?quality=low', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
// reset to a clean noon setup first
await p.evaluate(() => {
  const S = window.AGER.Engine.scene, R = window.AGER.Engine.renderer;
  S.setSunFromAngles(52*Math.PI/180, 130*Math.PI/180, [1.0,0.97,0.93], 3.4);
  S.sky.night = 0; S.sky.turbidity = 0.4; S.sky.intensity = 1; S.sky.ambientBoost = 1;
  S.fog.enabled = false; S.fog.density = 0.0005;
  R.envDirty = true; R.exposure = 1;
});
const tests = {
  t0_noon: () => {},
  t1_groundUnlit: () => { const S = window.AGER.Engine.scene; S.meshes.forEach(m => { if (m.tag === 'ground') { m.material = new window.AGER.Material({ color: 0xffffff, unlit: true }); } }); },
  t2_groundWhitePBR: () => { const S = window.AGER.Engine.scene; S.meshes.forEach(m => { if (m.tag === 'ground') m.material = new window.AGER.Material({ color: 0xcccccc, roughness: 1, metalness: 0 }); }); },
  t3_propsWhitePBR: () => { const S = window.AGER.Engine.scene; S.meshes.forEach(m => { if (m.tag === 'prop') m.material = new window.AGER.Material({ color: 0xcccccc, roughness: 0.8, metalness: 0 }); }); },
  t4_showWire: () => { window.AGER.Engine.renderer.enableBloom = true; },
};
for (const [name, fn] of Object.entries(tests)) {
  await p.evaluate(fn);
  await new Promise(r=>setTimeout(r,1200));
  const path = `/tmp/p4-${name}.png`;
  await p.screenshot({path});
  const s = stats(path);
  console.log(name.padEnd(18), 'mean='+s.mean, 'sky='+s.skyMean, 'ground='+s.groundMean, 'center='+s.centerMean);
}
const info = await p.evaluate(() => {
  const S = window.AGER.Engine.scene;
  const ground = S.meshes.find(m => m.tag === 'ground');
  return { groundMat: ground.material.name, metal: ground.material.metalness, rough: ground.material.roughness, splat: ground.material.splat,
    visible: ground.visible, count: ground.count, geoKey: ground.geometryKey,
    sunDir: Array.from(S.sun.direction).map(v=>+v.toFixed(2)), sunI: S.sun.intensity,
    sh: Array.from(window.AGER.Engine.renderer.ambientSH.slice(0,3)).map(v=>+v.toFixed(3)) };
});
console.log(JSON.stringify(info));
await b.close();
