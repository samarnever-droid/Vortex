// --- AGER smoke test: boots the engine, builds a small scene, renders ---------
(function () {
  window.__AGER_ERRORS__ = [];
  const _err = console.error.bind(console);
  console.error = function (...a) { window.__AGER_ERRORS__.push(a.map(String).join(' ')); _err(...a); };
  addEventListener('error', e => window.__AGER_ERRORS__.push('window: ' + (e.message || e.error)));

  const bootBar = document.getElementById('ager-boot-bar');
  const bootSt = document.getElementById('ager-boot-st');
  function progress(p, msg) {
    if (bootBar) bootBar.style.width = (p * 100).toFixed(0) + '%';
    if (bootSt) bootSt.textContent = msg;
  }

  function start() {
    const { engine, scene, camera } = Ager.create({ quality: 'high' });
    progress(0.25, 'generating procedural textures…');
    setTimeout(() => {
      MaterialLib.build(engine.device, 256, (p, name) => progress(0.25 + p * 0.5, 'texture: ' + name));
      progress(0.8, 'building world…');
      // terrain
      const t = Ager.mesh('plane', 'terrain', { args: [400, 400, 96, 96], tag: 'ground' });
      scene.water = null;
      // some props in a ring
      for (let i = 0; i < 8; i++) {
        const a = i / 8 * TAU;
        const m = Ager.mesh(i % 2 ? 'box' : 'cylinder', i % 2 ? 'crate' : 'metalDark', {
          args: [0.8, 0.8, 0.8], position: [Math.cos(a) * 6, 1, Math.sin(a) * 6], name: 'prop' + i, tag: 'prop'
        });
        m.setRotation(0, a, 0);
      }
      Ager.mesh('icosphere', 'energy', { args: [1.6, 3], position: [0, 2.4, 0] });
      Ager.mesh('ring', 'hazard', { args: [6, 10, 64], position: [0, 0.05, 0] });
      Ager.light('point', { position: [0, 3, 0], color: [0.35, 0.85, 1], intensity: 60, range: 26 });
      Ager.light('spot', { position: [-6, 7, -4], color: [1, 0.6, 0.3], intensity: 120, range: 40, castShadow: true, target: [0, 0, 0] });
      scene.setSunFromAngles(9 * DEG, 250 * DEG, [1.0, 0.55, 0.32], 1.6);
      scene.sky.turbidity = 1.0;
      scene.fog.color = [0.42, 0.36, 0.34];
      scene.fog.density = 0.006;
      // orbit camera
      let t0 = 0;
      let first = true;
      Ager.update((dt) => {
        t0 += dt * 0.12;
        camera.setPosition(Math.cos(t0) * 13, 5.2, Math.sin(t0) * 13);
        if (first) { scene.updateWorldMatrix(); first = false; }
        camera.lookAt([0, 1.6, 0]);
      });
      engine.start();
      progress(1, 'ready');
      setTimeout(() => { const b = document.getElementById('ager-boot'); if (b) { b.style.opacity = '0'; setTimeout(() => b.remove(), 700); } window.__AGER_READY__ = true; }, 400);
    }, 30);
  }
  window.__AGER_START__ = start;
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(start, 0);
  else addEventListener('DOMContentLoaded', start);
})();
