import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--mute-audio']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
p.on('console', m => { const t=m.text(); if (/error/i.test(t) && !/mipmap|Two textures|Feedback loop/.test(t)) console.log('[err]', t.slice(0,300)); });
await p.goto('file://'+join(root,'dist/index.html')+'?quality=low&pose=01-arena&hud=0', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:180000, polling:300});
await p.evaluate(() => { document.getElementById('ager-ui').style.display='none'; });
for (const v of [0,10,3,4]) {
  await p.evaluate((vv) => { window.AGER.Engine.renderer.debugView = vv; }, v);
  await new Promise(r=>setTimeout(r,1600));
  const path = `/tmp/g-${v}.png`;
  await p.screenshot({path});
  const s = stats(path);
  console.log('view '+v, 'mean='+s.mean, 'sky='+s.skyMean, 'ground='+s.groundMean, 'center='+s.centerMean);
}
const info = await p.evaluate(() => {
  const { Engine } = window.AGER, S = Engine.scene, R = Engine.renderer;
  const terrain = S.meshes.find(m => m.name === 'terrain');
  const floor = S.meshes.find(m => m.name === 'arena_floor');
  const cam = Engine.camera;
  return {
    camPos: Array.from(cam.position).map(v=>+v.toFixed(2)),
    camFwd: Array.from(cam.getForward([0,0,0])).map(v=>+v.toFixed(2)),
    terrain: terrain ? { inFrustum: cam.frustum.intersectsSphere(terrain._worldCenter, terrain._worldRadius), c: terrain._worldCenter.map(v=>+v.toFixed(1)), r: +terrain._worldRadius.toFixed(1), vis: terrain.visible, mat: terrain.material.name } : null,
    floor: floor ? { inFrustum: cam.frustum.intersectsSphere(floor._worldCenter, floor._worldRadius), c: floor._worldCenter.map(v=>+v.toFixed(1)), r: +floor._worldRadius.toFixed(1) } : null,
    drawn: R.stats.drawn, calls: R.stats.drawCalls,
    sunIntensity: S.sun.intensity, skyInt: S.sky.intensity,
    sh0: Array.from(R.ambientSH.slice(0,3)).map(v=>+v.toFixed(2)),
    exposure: R.exposure, shadowStrength: S.sun.shadowStrength,
    fog: { d: S.fog.density, color: S.fog.color },
  };
});
console.log(JSON.stringify(info, null, 1));
await b.close();
