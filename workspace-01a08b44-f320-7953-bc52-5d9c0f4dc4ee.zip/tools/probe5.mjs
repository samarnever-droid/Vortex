import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stats } from './imgstats.mjs';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:640,height:360});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file://'+join(root,'dist/ager.html')+'?quality=low', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
await p.evaluate(() => {
  window.__RESET__ = () => {
    const R = window.AGER.Engine.renderer, S = window.AGER.Engine.scene;
    R.enableBloom = true; R.enableSSAO = true; R.enableGodrays = true; R.enableFXAA = true;
    R.chroma = 0.0028; R.grain = 0.022; R.vignette = 0.35; R.exposure = 1;
    S.setSunFromAngles(52*Math.PI/180, 130*Math.PI/180, [1.0,0.97,0.93], 3.4);
    S.sky.night=0; S.sky.turbidity=0.4; S.sky.intensity=1; S.sky.ambientBoost=1;
    S.fog.enabled=false; S.fog.density=0.0006;
    S.meshes.forEach(m => { if (m.tag === 'ground') m.material = window.AGER.MaterialLib.get('basalt'); });
    R.envDirty = true;
  };
  window.__RESET__();
});
const tests = {
  a_all: () => {},
  b_noSSAO: () => { window.AGER.Engine.renderer.enableSSAO = false; },
  c_noBloomGod: () => { const R = window.AGER.Engine.renderer; R.enableBloom=false; R.enableGodrays=false; },
  d_noGrainChroma: () => { const R = window.AGER.Engine.renderer; R.grain=0; R.chroma=0; R.vignette=0; },
  e_noShadow: () => { const S = window.AGER.Engine.scene; S.sun.castShadow = false; },
  f_shadowOn: () => { const S = window.AGER.Engine.scene; S.sun.castShadow = true; },
};
for (const [name, fn] of Object.entries(tests)) {
  await p.evaluate(() => window.__RESET__());
  await p.evaluate(fn);
  await new Promise(r=>setTimeout(r,1300));
  const path = `/tmp/p5-${name}.png`;
  await p.screenshot({path});
  const s = stats(path);
  console.log(name.padEnd(16), 'mean='+s.mean, 'ground='+s.groundMean, 'center='+s.centerMean, 'dark='+s.darkFrac);
}
await b.close();
