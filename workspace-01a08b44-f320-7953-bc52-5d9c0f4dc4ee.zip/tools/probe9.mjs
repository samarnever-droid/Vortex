import puppeteer from 'puppeteer';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const b = await puppeteer.launch({headless:'shell',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p = await b.newPage();
await p.setViewport({width:480,height:270});
p.on('pageerror', e => console.log('PAGEERROR:', e.message));
await p.goto('file://'+join(root,'dist/ager.html')+'?quality=low', {waitUntil:'domcontentloaded'});
await p.waitForFunction('window.__AGER_READY__ === true', {timeout:120000, polling:200});
const out = await p.evaluate(() => {
  const { Engine } = window.AGER, S = Engine.scene, R = Engine.renderer;
  Engine.callbacks.update.length = 0;
  S.meshes.forEach(m => { m.visible = (m.tag === 'ground'); });
  S.updateWorldMatrix();
  Engine.camera.setPosition(0, 8, 26); S.updateWorldMatrix(); Engine.camera.lookAt([0,0,0]);
  Engine.camera.updateMatrices();
  const cam = Engine.camera;
  // manual CPU-side visibility check of the ground mesh
  const g = S.meshes.find(m => m.tag === 'ground');
  g.computeWorldBounds();
  const info = {
    inFrustum: cam.frustum.intersectsSphere(g._worldCenter, g._worldRadius),
    center: g._worldCenter, radius: g._worldRadius,
    worldMat: Array.from(g.worldMatrix),
    pos: Array.from(g.position), scale: Array.from(g.scale),
    quat: Array.from(g.quaternion),
    camPos: Array.from(cam.position), camQuat: Array.from(cam.quaternion),
    camView: Array.from(cam.view), camProj: Array.from(cam.projection),
    geoBbox: [Array.from(g.mesh.bounds.min), Array.from(g.mesh.bounds.max)],
    normal0: Array.from(g.geometry.normal.slice(0,3)),
    triangleCount: g.mesh.indexCount / 3,
    indexType: g.mesh.indexType,
  };
  // project the plane's four corners through the camera
  const proj = (x,y,z) => { const vp = cam.viewProjection;
    const cx = vp[0]*x+vp[4]*y+vp[8]*z+vp[12], cy = vp[1]*x+vp[5]*y+vp[9]*z+vp[13], cz = vp[2]*x+vp[6]*y+vp[10]*z+vp[14], cw = vp[3]*x+vp[7]*y+vp[11]*z+vp[15];
    return [ +(cx/cw).toFixed(2), +(cy/cw).toFixed(2), +(cz/cw).toFixed(3), +cw.toFixed(2) ]; };
  info.corners = { nw: proj(-200,0,-200), ne: proj(200,0,-200), near0: proj(-200,0,40), near1: proj(200,0,40) };
  return info;
});
console.log(JSON.stringify(out, null, 1));
await b.close();
