// ===========================================================================
//  AGER · CRUCIBLE  ·  110-world  ·  the arena, the terrain, the Crucible
// ===========================================================================

const CRUCIBLE = {
  ARENA_RADIUS: 62,          // flat combat bowl
  OUTER_RADIUS: 190,
  WATER_LEVEL: -2.4,
  CRUCIBLE_POS: [0, 0, -26], // the core we defend
  cores: [],
  pylons: [],
  lights: {},
};

// ---- terrain height field -------------------------------------------------
const World = {
  seed: 1337,
  heightAt(x, z) {
    const r = Math.hypot(x, z);
    // base rolling dunes + ridge
    let h = (fbm2(x * 0.006 + 4.1, z * 0.006 - 2.7, 5) - 0.5) * 26;
    h += (ridged2(x * 0.013, z * 0.013, 4) - 0.5) * 9;
    // carve the arena bowl: flat platform, walls rising around it
    const flat = smoothstep(CRUCIBLE.ARENA_RADIUS + 26, CRUCIBLE.ARENA_RADIUS - 6, r);   // 1 inside
    const rim = smoothstep(CRUCIBLE.ARENA_RADIUS - 2, CRUCIBLE.ARENA_RADIUS + 22, r) *
      smoothstep(CRUCIBLE.ARENA_RADIUS + 90, CRUCIBLE.ARENA_RADIUS + 30, r);
    h = h * (1 - flat) - 1.2 * flat + rim * 7.5;
    // lake basin to the east
    const lakeD = Math.hypot((x - 96) * 0.75, (z + 30) * 0.62);
    const lake = smoothstep(64, 26, lakeD);
    h = h * (1 - lake) + (CRUCIBLE.WATER_LEVEL - 3.4) * lake;
    // gentle detail
    h += (fbm2(x * 0.09, z * 0.09, 3) - 0.5) * 0.55 * (1 - flat * 0.85);
    return h;
  },
  normalAt(x, z, e = 0.6) {
    const hx = this.heightAt(x + e, z) - this.heightAt(x - e, z);
    const hz = this.heightAt(x, z + e) - this.heightAt(x, z - e);
    const n = [0, 0, 0];
    Vec3.normalize(n, [-hx, 2 * e, -hz]);
    return n;
  },
  raycast(origin, dir, maxDist) {
    // march the height field (cheap, robust enough for bullets)
    const step = 0.5;
    let t = 0, prevDiff = origin[1] - this.heightAt(origin[0], origin[2]);
    if (prevDiff < 0) return null;
    while (t < maxDist) {
      t += step;
      const x = origin[0] + dir[0] * t, y = origin[1] + dir[1] * t, z = origin[2] + dir[2] * t;
      const diff = y - this.heightAt(x, z);
      if (diff <= 0) {
        const f = prevDiff / Math.max(1e-5, prevDiff - diff);
        const ht = t - step + step * f;
        const px = origin[0] + dir[0] * ht, py = origin[1] + dir[1] * ht, pz = origin[2] + dir[2] * ht;
        return { t: ht, point: [px, py, pz], normal: this.normalAt(px, pz), terrain: true, material: 'sand' };
      }
      prevDiff = diff;
    }
    return null;
  },
};

// ---- the arena ------------------------------------------------------------
function buildWorld(scene, physics) {
  const M = MaterialLib;
  const R = CRUCIBLE.ARENA_RADIUS;

  // --- terrain ------------------------------------------------------------
  const tGeo = Geometry.terrain(520, 200, (x, z) => World.heightAt(x, z), 46);
  tGeo.primitiveKey = 'terrain';
  const terrain = new Mesh(tGeo, M.get('terrain'), 'terrain');
  terrain.tag = 'ground';
  scene.add(terrain);
  scene.meshes.push(terrain);
  physics.terrain = World;

  // --- arena floor: hazard ring + deck plates ----------------------------
  const floor = Ager.mesh('disc', 'metalDark', { args: [R + 7, 96], name: 'arena_floor', tag: 'ground' });
  floor.setPosition(0, -0.55, 0);
  floor.material = M.get('hull').clone({ name: 'deck', color: 0x8e959c, uvScale: [26, 26], roughness: 0.85 });

  const ring = Ager.mesh('ring', 'hazard', { args: [R - 1.5, R + 2.5, 128, 40], name: 'arena_ring', tag: 'ground' });
  ring.setPosition(0, -0.5, 0);

  const glowRing = Ager.mesh('ring', 'glow', { args: [R - 6, R - 5.4, 128], name: 'arena_glow' });
  glowRing.setPosition(0, -0.36, 0);
  glowRing.tag = 'transient';

  // --- perimeter wall with crenellations ---------------------------------
  const wall = new Mesh(Geometry.arenaWall(R + 3, 7.5, 160, 2.2, 0.8), M.get('concrete').clone({ uvScale: [1, 1] }), 'arena_wall');
  wall.tag = 'wall';
  scene.add(wall); scene.meshes.push(wall);
  // wall colliders: ring of boxes
  for (let i = 0; i < 48; i++) {
    const a = (i / 48) * TAU;
    const cx = Math.cos(a) * (R + 4.2), cz = Math.sin(a) * (R + 4.2);
    const node = new Node('wallseg');
    node.setPosition(cx, 3, cz);
    node.setRotation(0, -a, 0);
    scene.add(node);
    node.updateWorldMatrix();
    physics.addBox(node, [7, 16, 2.4], { static: true, tag: 'wall' });
  }

  // --- the Crucible: the thing you defend ---------------------------------
  const cp = CRUCIBLE.CRUCIBLE_POS;
  const base = Ager.mesh('cylinder', 'concrete', { args: [4.6, 6.4, 2.6, 32], name: 'crucible_base', tag: 'structure', position: [cp[0], 0.9, cp[2]] });
  const mid = Ager.mesh('cylinder', 'metalDark', { args: [3.0, 4.0, 5.0, 32], name: 'crucible_mid', tag: 'structure', position: [cp[0], 4.4, cp[2]] });
  const collar = Ager.mesh('torus', 'metal', { args: [3.6, 0.4, 40, 16], name: 'crucible_collar', tag: 'structure', position: [cp[0], 7.0, cp[2]] });
  const core = Ager.mesh('icosphere', 'energy', { args: [2.2, 3], name: 'crucible_core', tag: 'core', position: [cp[0], 10.4, cp[2]] });
  const cage = Ager.mesh('sphere', 'metal', { args: [2.9, 24, 12], name: 'crucible_cage', tag: 'structure', position: [cp[0], 10.4, cp[2]] });
  cage.material = M.get('metal').clone({ transparent: true, opacity: 0.28, roughness: 0.4, castShadow: false });
  cage.skipShadow = true;
  const halo = Ager.mesh('ring', 'glow', { args: [4.2, 7.0, 64], name: 'crucible_halo', position: [cp[0], 10.4, cp[2]], tag: 'transient' });
  const beam = Ager.mesh('cylinder', 'energy', { args: [0.9, 1.1, 30, 20], name: 'crucible_beam', tag: 'transient', position: [cp[0], 26, cp[2]] });
  beam.material = M.get('energy').clone({ transparent: true, opacity: 0.35, blending: 'additive', depthWrite: false, castShadow: false });
  beam.skipShadow = true;

  physics.addBox(base, [9, 3, 9], { static: true, tag: 'structure' });
  physics.addBox(mid, [6, 6, 6], { static: true, tag: 'structure' });

  const coreLight = Ager.light('point', { position: [cp[0], 10.4, cp[2]], color: [0.25, 0.8, 1.0], intensity: 90, range: 46, flicker: 0.12, flickerSpeed: 3.4, name: 'core_light' });
  const rimLight = Ager.light('point', { position: [cp[0], 3.0, cp[2]], color: [1.0, 0.45, 0.15], intensity: 26, range: 22, flicker: 0.08, name: 'core_rim' });
  CRUCIBLE.lights.core = coreLight;
  CRUCIBLE.lights.rim = rimLight;

  // --- hardened pylons with spot lights (shadow casters) ------------------
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU + 0.4;
    const px = Math.cos(a) * (R - 9), pz = Math.sin(a) * (R - 9);
    const pylon = Ager.mesh('cylinder', 'metalDark', { args: [0.55, 0.9, 15, 12], name: 'pylon' + i, tag: 'structure', position: [px, 6.5, pz] });
    const cap = Ager.mesh('box', 'metal', { args: [1.9, 0.5, 1.9], name: 'pylon_cap' + i, tag: 'structure', position: [px, 13.6, pz] });
    cap.setRotation(0, a, 0);
    const lamp = Ager.mesh('box', 'glow', { args: [1.2, 0.16, 1.2], name: 'pylon_lamp' + i, tag: 'transient', position: [px, 13.3, pz] });
    lamp.setRotation(0, a, 0);
    const isShadow = i % 2 === 0;
    const spot = Ager.light('spot', {
      position: [px, 13.2, pz], target: [Math.cos(a) * (R * 0.15), 0, Math.sin(a) * (R * 0.15)],
      color: i % 2 ? [0.45, 0.75, 1.0] : [1.0, 0.6, 0.28], intensity: isShadow ? 260 : 130,
      range: 90, innerAngle: 22, outerAngle: 40, castShadow: isShadow, name: 'spot' + i,
    });
    CRUCIBLE.pylons.push({ pylon, lamp, spot, angle: a });
    physics.addBox(pylon, [1.8, 15, 1.8], { static: true, tag: 'structure' });
  }

  // --- gate arch (where the waves come from) ------------------------------
  const gateA = Ager.mesh('box', 'concrete', { args: [26, 15, 4], name: 'gate', tag: 'structure', position: [0, 7, R + 8] });
  const gateRing = Ager.mesh('torus', 'metal', { args: [7.2, 1.0, 40, 14], name: 'gate_ring', tag: 'structure', position: [0, 7.4, R + 5.4] });
  gateRing.setRotation(Math.PI / 2, 0, 0);
  const gateGlow = Ager.mesh('disc', 'glow', { args: [7.0, 40], name: 'gate_glow', tag: 'transient', position: [0, 7.4, R + 5.2] });
  gateGlow.setRotation(Math.PI / 2, 0, 0);
  gateGlow.material = M.get('glow').clone({ color: 0xff5522, emissive: 0xff5522, transparent: true, opacity: 0.35, blending: 'additive', depthWrite: false });
  CRUCIBLE.gate = { arch: gateA, ring: gateRing, glow: gateGlow, position: [0, 0, R + 10], spawn: [0, 0.4, R - 2], light: Ager.light('point', { position: [0, 7, R + 4], color: [1.0, 0.35, 0.15], intensity: 40, range: 40, name: 'gate_light' }) };
  physics.addBox(gateA, [30, 16, 5], { static: true, tag: 'structure' });

  // --- cover: instanced crates, pillars, rocks ----------------------------
  const rng = (a, b) => a + Math.random() * (b - a);
  const crateGeo = Geometry.box(1.5, 1.5, 1.5, 1);
  const crates = scene.makeInstanced(crateGeo, M.get('crate'), 160, 'cover_crates');
  crates.material = M.get('crate').clone({ instanceTint: 0.55 });
  crates.material.defines.INSTANCED = 1;
  crates.material.defines.RECEIVE_SHADOW = 1;
  crates.begin();
  const cratePositions = [];
  for (let i = 0; i < 64; i++) {
    const a = Math.random() * TAU, r = 12 + Math.random() * (R - 20);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (Math.hypot(x - cp[0], z - cp[2]) < 9) continue;
    const y = World.heightAt(x, z) + 0.75;
    const q = Quat.fromEuler(Quat.create(), 0, Math.random() * TAU, 0);
    const s = rng(0.85, 1.5);
    crates.push([x, y, z], q, [s, s, s], [0, 0, 0, Math.random() * 97]);
    cratePositions.push([x, y, z, s]);
  }
  crates.count = crates.instances.count;
  for (const [x, y, z, s] of cratePositions) {
    const n = new Node('crate_col'); n.setPosition(x, y, z); scene.add(n); n.updateWorldMatrix();
    physics.addBox(n, [1.5 * s, 1.5 * s, 1.5 * s], { static: true, tag: 'cover' });
  }

  const pillarGeo = Geometry.cylinder(0.75, 1.1, 9, 10);
  const pillars = scene.makeInstanced(pillarGeo, M.get('concrete').clone({ instanceTint: 0.3, defines: { INSTANCED: 1 } }), 40, 'pillars');
  pillars.begin();
  for (let i = 0; i < 22; i++) {
    const a = (i / 22) * TAU + rng(-0.1, 0.1), r = R - rng(4, 12);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    const y = World.heightAt(x, z) + 4.5;
    pillars.push([x, y, z], Quat.fromEuler(Quat.create(), rng(-0.05, 0.05), Math.random() * TAU, 0), 1, [0, 0, 0, Math.random() * 55]);
    const n = new Node('pillar_col'); n.setPosition(x, y, z); scene.add(n); n.updateWorldMatrix();
    physics.addBox(n, [2, 9, 2], { static: true, tag: 'cover' });
  }
  pillars.count = pillars.instances.count;

  // rocks outside the arena for scale
  const rockGeo = Geometry.icosphere(1, 1);
  const rocks = scene.makeInstanced(rockGeo, M.get('rock').clone({ instanceTint: 0.6, defines: { INSTANCED: 1 } }), 260, 'rocks');
  rocks.begin();
  for (let i = 0; i < 220; i++) {
    const a = Math.random() * TAU, r = R + 12 + Math.pow(Math.random(), 0.6) * (CRUCIBLE.OUTER_RADIUS - R - 20);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    const y = World.heightAt(x, z);
    if (y < CRUCIBLE.WATER_LEVEL + 0.6) continue;
    const s = rng(1.2, 6.5);
    rocks.push([x, y + s * 0.25, z], Quat.fromEuler(Quat.create(), rng(-0.3, 0.3), Math.random() * TAU, rng(-0.3, 0.3)), [s, s * rng(0.6, 1.1), s], [0, 0, 0, Math.random() * 71]);
  }
  rocks.count = rocks.instances.count;

  // alien crystal clusters (emissive, pretty at night)
  const crystalGeo = Geometry.icosphere(0.6, 1);
  const crystals = scene.makeInstanced(crystalGeo, M.get('crystal').clone({ defines: { INSTANCED: 1, RECEIVE_SHADOW: 1 } }), 120, 'crystals');
  crystals.begin();
  const crystalNodes = [];
  for (let i = 0; i < 70; i++) {
    const a = Math.random() * TAU, r = R + 8 + Math.random() * (CRUCIBLE.OUTER_RADIUS - R - 30);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    const y = World.heightAt(x, z);
    if (y < CRUCIBLE.WATER_LEVEL + 0.5) continue;
    const s = rng(0.7, 2.6);
    crystals.push([x, y + s * 0.5, z], Quat.fromEuler(Quat.create(), rng(-0.4, 0.4), Math.random() * TAU, rng(-0.4, 0.4)), [s * 0.5, s * 1.9, s * 0.5], [0, 0, 0, Math.random() * 61]);
    if (i % 6 === 0 && crystalNodes.length < 8) crystalNodes.push([x, y + s, z]);
  }
  crystals.count = crystals.instances.count;
  for (const [x, y, z] of crystalNodes) Ager.light('point', { position: [x, y, z], color: [0.2, 0.7, 1.0], intensity: 14, range: 18, name: 'crystal_light' });

  // --- water --------------------------------------------------------------
  const waterGeo = Geometry.terrain(300, 48, (x, z) => 0, 40);
  const waterMat = M.get('glass').clone({ name: 'water', transparent: true, opacity: 1, doubleSided: false, castShadow: false });
  const waterMesh = new Mesh(waterGeo, waterMat, 'water');
  waterMesh.tag = 'water';
  waterMesh.setPosition(96, CRUCIBLE.WATER_LEVEL, -30);
  waterMesh.skipShadow = true;
  // deliberately NOT parented to the scene graph: the water pass draws it with
  // full refraction/reflection state instead of the standard material path.
  waterMesh.updateWorldMatrix();
  scene.water = {
    level: CRUCIBLE.WATER_LEVEL, mesh: waterMesh, shallow: [0.05, 0.22, 0.26], deep: [0.01, 0.06, 0.12],
    foam: 1.1, waveDirA: [1, 0.25], waveDirB: [-0.35, 1],
  };
  scene.waterNormalMap = MaterialLib.tex.metalPlate_normal;

  // --- sky / lighting mood ------------------------------------------------
  scene.setSunFromAngles(11.5 * DEG, 284 * DEG, [1.0, 0.58, 0.34], 3.4);
  scene.sky.turbidity = 0.95;
  scene.sky.night = 0.18;
  scene.sky.exposure = 1.0;
  scene.sky.ambientBoost = 1.15;
  scene.fog.color = [0.38, 0.34, 0.38];
  scene.fog.density = 0.0034;
  scene.fog.sunAmount = 1.0;
  scene.fog.height = 3.5;
  scene.fog.falloff = 0.05;

  // dust motes
  FX.init(scene, physics);
  CRUCIBLE.dust = new ParticleEmitter(scene, { capacity: 260, name: 'dust', material: M.get('sprite'), blending: 'additive' });
  for (let i = 0; i < 200; i++) {
    const a = Math.random() * TAU, r = Math.random() * 150;
    CRUCIBLE.dust.spawn({
      x: Math.cos(a) * r, y: World.heightAt(Math.cos(a) * r, Math.sin(a) * r) + 1 + Math.random() * 14, z: Math.sin(a) * r,
      vx: (Math.random() - 0.5) * 0.5, vy: 0.06 + Math.random() * 0.2, vz: (Math.random() - 0.5) * 0.5,
      life: 12 + Math.random() * 14, size: 0.05 + Math.random() * 0.09, sizeEnd: 0.02,
      color: [1.0, 0.72, 0.42], drag: 0.2, gravity: 0.02,
    });
  }

  return { terrain, floor, wall, gate: CRUCIBLE.gate, core };
}
