// ===========================================================================
//  AGER · CRUCIBLE  ·  170-game  ·  the game itself
// ===========================================================================

const Game = {
  state: 'boot',            // boot | menu | playing | over | victory
  score: 0, credits: 4, kills: 0, headshots: 0,
  coreMax: 1200, coreHealth: 1200,
  enemies: [], grenadeCount: 0, enemyCount: 0,
  time: 0, waveTimer: 0, hitStop: 0, timeScaleTarget: 1,
  poseMode: false, poseHold: null,
  shotsFired: 0, accuracyHits: 0,

  init() {
    const scene = Engine.scene, physics = Engine.physics;
    Player.init(scene, physics);
    Projectiles.init(scene);
    Pickups.init(scene);
    VFX.init(scene, physics);
    HUD.init();
    GameAudio.init(Engine.audio);

    // frame hooks
    Engine.on('update', (dt) => this.update(dt));
    Engine.on('lateUpdate', (dt) => this.lateUpdate(dt));
    Engine.on('resize', () => this.onResize());

    this.registerAI();
    this.physics = physics;
    this.scene = scene;
    CRUCIBLE.coreMesh = scene.findByName('crucible_core')[0];
    CRUCIBLE.haloMesh = scene.findByName('crucible_halo')[0];
    CRUCIBLE.beamMesh = scene.findByName('crucible_beam')[0];
    CRUCIBLE.cageMesh = scene.findByName('crucible_cage')[0];
    return this;
  },

  start() {
    this.state = 'playing';
    GameAudio.start();
    Waves.wave = 0;
    Waves.state = 'idle';
    this.waveTimer = 3.0;
    HUD.banner('CRUCIBLE ONLINE', 'hold the arena — the gate opens in 3s', 2600);
    HUD.log('<b style="color:#7de3ff">MISSION</b> — defend the Crucible. Left click to fire, F to dash, Q for the nova.');
    HUD.log('Open the console with <b>`</b> and talk to the engine — try <b>"spawn 20 crawlers near me"</b>.');
  },

  // ---------------------------------------------------------------- update
  update(dt) {
    if (this.hitStop > 0) { this.hitStop -= dt; dt *= 0.15; }
    this.time += dt;
    if (this.state !== 'playing') return;
    const p = Player;
    if (this.poseMode) { this.updatePose(dt); return; }

    p.update(dt);
    for (const e of this.enemies) e.update(dt, p, this.physics, CRUCIBLE.CRUCIBLE_POS);
    this.enemies = this.enemies.filter(e => e.alive || e.node);
    Projectiles.update(dt, p, this.physics, this.enemies);
    Pickups.update(dt, p);
    Waves.update(dt, this.enemies);
    this.enemyCount = this.enemies.filter(e => e.alive).length;

    // resupply window
    if (Waves.state === 'between' && Waves.betweenWaves > 1) {
      HUD.resupply(true, UPGRADES.map(u => ({ label: u.label, cost: u.cost })));
    } else {
      HUD.resupply(false);
    }
    const input = Engine.input;
    if (Waves.state === 'between') {
      for (let i = 0; i < UPGRADES.length; i++) if (input.isDown('Digit' + (i + 7))) this.buyUpgrade(i);
    }

    // objective pressure: the core bleeds slowly if enemies reach it
    const dmg = this.enemies.filter(e => e.alive).reduce((a, e) => {
      const d = Vec3.dist(e.pos, [CRUCIBLE.CRUCIBLE_POS[0], e.pos[1], CRUCIBLE.CRUCIBLE_POS[2]]);
      return a + (d < 12 ? e.type.damage * 0.02 : 0);
    }, 0);
    if (dmg > 0) this.damageCrucible(dmg * dt, null, true);

    if (this.coreHealth <= 0 && this.state === 'playing') this.gameOver();
  },

  lateUpdate(dt) {
    // visual state
    const t = Engine.time;
    const R = Engine.renderer;
    const core = CRUCIBLE;
    const hurt = 1 - clamp(this.coreHealth / this.coreMax, 0, 1);
    if (core.coreMesh) {
      core.coreMesh.setRotation(t * 0.25, t * 0.4, 0);
      const pulse = 1 + Math.sin(t * 2.2) * 0.06 + hurt * 0.1;
      core.coreMesh.setScale(pulse, pulse, pulse);
      const mat = core.coreMesh.material;
      mat.emissive = [lerp(0.15, 1.0, hurt), lerp(0.75, 0.25, hurt), lerp(1.0, 0.15, hurt)];
      mat.emissiveIntensity = 2.4 + Math.sin(t * 3) * 0.4 + hurt * 1.6;
    }
    if (core.haloMesh) {
      core.haloMesh.setRotation(0, t * 0.6, 0);
      core.haloMesh.material.opacity = 0.5 + hurt * 0.4;
    }
    if (core.beamMesh) {
      const k = clamp(this.coreHealth / this.coreMax, 0, 1);
      core.beamMesh.setScale(1, 1, 1);
      core.beamMesh.material.opacity = 0.12 + k * 0.28 + Math.sin(t * 4) * 0.03;
      core.beamMesh.setRotation(0, t * 0.3, 0);
    }
    if (core.cageMesh) core.cageMesh.setRotation(t * 0.08, -t * 0.12, 0);
    // gate glow pulses with the wave state
    if (core.gate) {
      const pulse = Waves.state === 'spawning' ? 0.6 + Math.sin(t * 9) * 0.25 : 0.14 + Math.sin(t * 2) * 0.05;
      core.gate.glow.material.opacity = pulse;
      core.gate.glow.material.emissiveIntensity = 1.5 + pulse * 3;
      core.gate.ring.setRotation(0, 0, t * 0.2);
    }
    if (core.dust) {
      core.dust.update(dt, this.physics);
    }
    FX.update(dt);
    VFX.update(dt);
    HUD.update(dt, this);
    // combat intensity drives the score
    const near = this.enemies.filter(e => e.alive && Vec3.dist(e.pos, Player.pos) < 45).length;
    GameAudio.setCombatIntensity(clamp(near / 9 + (Player.health < 40 ? 0.25 : 0), 0, 1));
    // slow-mo recovery
    Engine.timeScale = damp(Engine.timeScale, this.timeScaleTarget, 3.5, dt);
    this.timeScaleTarget = 1;
    if (this.victoryShown && this.state === 'playing') { }
  },

  onResize() { },

  // ---------------------------------------------------------------- combat
  fireHitscan(origin, dir, def, muzzle) {
    this.shotsFired++;
    const ENEMY_PAD = 1.25;
    let best = null;
    const cam = Engine.camera;
    const camPos = cam.getWorldPosition([0, 0, 0]);
    for (const e of this.enemies) {
      if (!e.alive) continue;
      // cheap cull
      const dx = e.pos[0] - origin[0], dy = e.pos[1] + e.height * 0.5 - origin[1], dz = e.pos[2] - origin[2];
      const proj = dx * dir[0] + dy * dir[1] + dz * dir[2];
      if (proj < 0 || proj > 200) continue;
      const cx = origin[0] + dir[0] * proj, cy = origin[1] + dir[1] * proj, cz = origin[2] + dir[2] * proj;
      const d2 = (cx - e.pos[0]) ** 2 + (cy - (e.pos[1] + e.height * 0.5)) ** 2 + (cz - e.pos[2]) ** 2;
      const rad = Math.max(e.radius, e.height * 0.42) * ENEMY_PAD;
      if (d2 > rad * rad) continue;
      const head = e.hitPosition([0, 0, 0]);
      const hp = [(head[0] - origin[0]) * dir[0] + (head[1] - origin[1]) * dir[1] + (head[2] - origin[2]) * dir[2]];
      const hx = origin[0] + dir[0] * hp[0], hy = origin[1] + dir[1] * hp[0], hz = origin[2] + dir[2] * hp[0];
      const headR = (e.type.boss ? 0.85 : 0.42);
      const headHit = ((hx - head[0]) ** 2 + (hy - head[1]) ** 2 + (hz - head[2]) ** 2) < headR * headR;
      const t = proj;
      if (!best || t < best.t) best = { t, enemy: e, point: [cx, cy, cz], head: headHit };
    }
    // world
    const world = this.physics.raycast(origin, dir, 220, c => c.tag !== 'prop');
    const terrainHit = World.raycast(origin, dir, 220);
    let worldT = 1e9, worldPoint = null, worldNormal = null, worldSurface = 'concrete';
    if (world && world.t < worldT) { worldT = world.t; worldPoint = world.point; worldNormal = world.normal; worldSurface = world.collider && world.collider.material === 'metal' ? 'metal' : 'concrete'; }
    if (terrainHit && terrainHit.t < worldT) { worldT = terrainHit.t; worldPoint = terrainHit.point; worldNormal = terrainHit.normal; worldSurface = 'sand'; }

    if (best && best.t < worldT) {
      const dmg = def.damage * (best.head ? def.headMult : 1);
      this.damageEnemy(best.enemy, dmg, best.point, best.head, origin);
      VFX.tracer(muzzle, best.point, def.tracer, def.pellets > 5 ? 0.7 : 1);
      VFX.impact(best.point, Vec3.normalize([0, 0, 0], Vec3.sub([0, 0, 0], origin, best.point)), { color: def.tracer, count: 8, surface: 'flesh', smoke: false });
    } else if (worldPoint) {
      VFX.tracer(muzzle, worldPoint, def.tracer, def.pellets > 5 ? 0.7 : 1);
      VFX.impact(worldPoint, worldNormal, { color: def.tracer, count: def.pellets > 5 ? 5 : 9, surface: worldSurface, decal: Math.random() < 0.3 });
    } else {
      VFX.tracer(muzzle, [origin[0] + dir[0] * 160, origin[1] + dir[1] * 160, origin[2] + dir[2] * 160], def.tracer, 0.8);
    }
  },

  damageEnemy(enemy, amount, point, isHead, fromPos) {
    if (!enemy.alive) return;
    this.accuracyHits++;
    const dealt = enemy.takeDamage(amount, point, isHead);
    Player.damageDealt += dealt;
    HUD.damageNumber(point, dealt, isHead);
    HUD.hitmarker(!enemy.alive, isHead);
    Engine.audio.hitMarker(isHead);
    FX.burst(point, { count: isHead ? 12 : 7, speed: 5, life: 0.35, size: 0.16, color: isHead ? [1, 0.85, 0.4] : [1, 0.45, 0.3], gravity: 8, drag: 3 });
    if (isHead) {
      Player.headshots++;
      HUD.feed(`<b>HEADSHOT</b> ${enemy.name} <span style="opacity:.6">${Math.round(dealt)}</span>`, '#ffd45a');
    }
    if (enemy.alive === false) {
      this.onEnemyKilled(enemy, point);
    }
  },

  onEnemyKilled(enemy, point) {
    if (enemy._counted) return;
    enemy._counted = true;
    this.kills++;
    Player.kills++;
    Waves.totalKilled++;
    const mult = 1 + Math.floor(Waves.wave / 4) * 0.25;
    const score = Math.round(enemy.type.score * mult);
    this.score += score;
    this.credits += enemy.type.boss ? 6 : 1;
    Engine.audio.kill();
    HUD.feed(`<b style="color:#ffb27a">${enemy.name}</b> destroyed <span style="opacity:.6">+${score}</span>`, '#ffe0b8');
    if (enemy.type.boss) this.hitStop = 0.45;
    else this.hitStop = 0.06;
    // drops
    const r = Math.random();
    const dropPos = [enemy.pos[0], World.heightAt(enemy.pos[0], enemy.pos[2]) + 0.7, enemy.pos[2]];
    if (enemy.type.boss) {
      Pickups.spawn('health', [dropPos[0] + 1.5, dropPos[1], dropPos[2]]);
      Pickups.spawn('ammo', [dropPos[0] - 1.5, dropPos[1], dropPos[2]]);
      Pickups.spawn('shield', [dropPos[0], dropPos[1], dropPos[2] + 1.5]);
    } else if (r < 0.11) Pickups.spawn('health', dropPos);
    else if (r < 0.24) Pickups.spawn('ammo', dropPos);
    else if (r < 0.3) Pickups.spawn('shield', dropPos);
  },

  areaDamage(center, radius, damage, source, enemies = null, enemySource = false) {
    const list = enemies || this.enemies;
    for (const e of list) {
      if (!e.alive) continue;
      const d = Vec3.dist(e.pos, center);
      if (d > radius) continue;
      const falloff = 1 - (d / radius) * 0.75;
      const pt = e.hitPosition([0, 0, 0]);
      this.damageEnemy(e, damage * falloff, pt, false, center);
      // knockback
      const dir = Vec3.normalize([0, 0, 0], Vec3.sub([0, 0, 0], e.pos, center));
      const k = (1 - d / radius) * 26 / Math.max(1, e.type.mass);
      e.vel[0] += dir[0] * k; e.vel[1] += Math.abs(dir[1]) * k * 0.5 + 6 / Math.max(1, e.type.mass); e.vel[2] += dir[2] * k;
      e.stagger = Math.max(e.stagger, 0.35);
    }
    if (!enemySource) {
      // player self-damage from own explosives
      const pd = Vec3.dist([Player.pos[0], Player.pos[1] + 1, Player.pos[2]], center);
      if (pd < radius * 0.55) Player.takeDamage(damage * 0.22 * (1 - pd / (radius * 0.55)), center);
    }
  },

  nova(center, radius, damage, source) {
    this.areaDamage(center, radius, damage, source, this.enemies, true);
    Engine.renderer.flash = 0.55;
    Engine.renderer.flashColor = [0.6, 0.9, 1.0];
    FX.ring(center, [0.55, 0.9, 1.0], 40, 26, 0.75);
    FX.burst(center, { count: 60, speed: 20, life: 0.7, size: 0.34, color: [0.6, 0.9, 1], drag: 3.2, gravity: 0 });
    for (const e of this.enemies) {
      if (e.alive && Vec3.dist(e.pos, center) < radius) FX.trail(e.hitPosition([0, 0, 0]), [0.7, 0.95, 1], 0.3);
    }
  },

  slam(center, damage, radius, source) {
    this.areaDamage(center, radius, damage, source, [Player], true);
    FX.ring(center, [1, 0.55, 0.2], 24, 14, 0.45);
    this.cameraShake(0.4, 12);
  },

  damageCrucible(amount, source, quiet = false) {
    if (this.state !== 'playing') return;
    const before = this.coreHealth;
    this.coreHealth = Math.max(0, this.coreHealth - amount);
    if (before > 0 && this.coreHealth <= this.coreMax * 0.3 && !this._warned) {
      this._warned = true;
      HUD.banner('CRUCIBLE CRITICAL', 'integrity below 30%', 3000);
      Engine.audio.alarm(CRUCIBLE.CRUCIBLE_POS);
      Engine.music.setIntensity(1);
    }
    if (!quiet && amount > 8) {
      HUD.damageFlash(0.35);
      this.cameraShake(0.35, 8);
    }
  },

  cameraShake(amount, freq) { Player.camShake = Math.max(Player.camShake, amount); },

  slowmo(t) { this.timeScaleTarget = 0.35; setTimeout(() => { this.timeScaleTarget = 1; }, t * 1000); },

  spawnProjectile(o) { return Projectiles.spawn(o); },
  spawnGrenade(pos, vel) {
    this.grenadeCount++;
    return Projectiles.spawn({
      pos, dir: vel, speed: 1, life: 1.75, radius: 0.22, owner: 'grenade', damage: 120, speedVec: vel,
    });
  },

  spawnPickupBatch(wave) {
    const n = 2 + Math.floor(wave / 2);
    for (let i = 0; i < Math.min(6, n); i++) {
      const a = Math.random() * TAU, r = 12 + Math.random() * 34;
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      const y = World.heightAt(x, z) + 0.7;
      const kind = ['health', 'ammo', 'shield'][i % 3];
      Pickups.spawn(kind, [x, y, z]);
    }
  },

  buyUpgrade(i) {
    const u = UPGRADES[i];
    if (!u || this.credits < u.cost) { HUD.log('<span style="color:#ff9b8a">not enough cores</span>'); return; }
    this.credits -= u.cost;
    u.apply(this);
    Engine.audio.pickup(Player.pos, 1.2);
    HUD.log(`<b style="color:#7dff9a">${u.label}</b> acquired`);
  },

  onPlayerDeath() {
    this.score = Math.max(0, this.score - 250);
    setTimeout(() => { if (this.state === 'playing') HUD.log('the Crucible is still under attack…'); }, 2600);
  },

  gameOver() {
    if (this.state !== 'playing') return;
    this.state = 'over';
    HUD.banner('CRUCIBLE LOST', `survived ${Waves.wave} waves · ${this.score.toLocaleString()} pts`, 9000);
    Engine.audio.explosion(CRUCIBLE.CRUCIBLE_POS, 2.4);
    VFX.explosion([CRUCIBLE.CRUCIBLE_POS[0], 6, CRUCIBLE.CRUCIBLE_POS[2]], 3, [1, 0.4, 0.2]);
    Engine.renderer.flash = 1;
    Engine.renderer.flashColor = [1, 0.4, 0.2];
    if (CRUCIBLE.coreMesh) CRUCIBLE.coreMesh.visible = false;
    setTimeout(() => this.showEndScreen(false), 3200);
  },

  victory() {
    this.state = 'victory';
    HUD.banner('CRUCIBLE SECURED', `wave ${Waves.wave} cleared · ${this.score.toLocaleString()} pts`, 9000);
    setTimeout(() => this.showEndScreen(true), 3600);
  },

  showEndScreen(won) {
    if (document.getElementById('endscreen')) return;
    const el = document.createElement('div');
    el.id = 'endscreen';
    el.style.cssText = `position:fixed;inset:0;background:radial-gradient(circle at 50% 40%, rgba(10,24,34,.86), rgba(2,5,8,.96));
      display:flex;align-items:center;justify-content:center;flex-direction:column;z-index:30;font-family:ui-monospace,monospace;color:#dff6ff`;
    el.innerHTML = `
      <div style="font-size:12px;letter-spacing:.42em;opacity:.6">AGER · CRUCIBLE</div>
      <div style="font-size:52px;letter-spacing:.2em;margin:10px 0 2px;color:${won ? '#7dffd0' : '#ff7062'}">${won ? 'SECURED' : 'OVERRUN'}</div>
      <div style="display:flex;gap:44px;margin:26px 0 34px;text-align:center">
        <div><div style="font-size:30px">${this.score.toLocaleString()}</div><div style="font-size:10px;letter-spacing:.22em;opacity:.55">SCORE</div></div>
        <div><div style="font-size:30px">${Waves.wave}</div><div style="font-size:10px;letter-spacing:.22em;opacity:.55">WAVES</div></div>
        <div><div style="font-size:30px">${this.kills}</div><div style="font-size:10px;letter-spacing:.22em;opacity:.55">KILLS</div></div>
        <div><div style="font-size:30px">${this.headshots}</div><div style="font-size:10px;letter-spacing:.22em;opacity:.55">HEADSHOTS</div></div>
        <div><div style="font-size:30px">${this.shotsFired ? Math.round(this.accuracyHits / Math.max(1, this.shotsFired) * 100) : 0}%</div><div style="font-size:10px;letter-spacing:.22em;opacity:.55">HITS</div></div>
      </div>
      <button id="restart" style="pointer-events:auto;background:rgba(8,26,36,.9);border:1px solid rgba(120,220,255,.5);color:#dff6ff;font-family:inherit;
        font-size:14px;letter-spacing:.24em;padding:14px 34px;cursor:pointer">RE-INITIALISE CRUCIBLE</button>
      <div style="margin-top:18px;font-size:11px;opacity:.5">the console (` + '`' + `) is still listening — try "spawn 30 crawlers near me"</div>`;
    document.body.appendChild(el);
    el.querySelector('#restart').onclick = () => { el.remove(); this.restart(); };
  },

  restart() {
    for (const e of this.enemies) if (e.node) Engine.scene.remove(e.node);
    this.enemies.length = 0;
    for (const p of Projectiles.list.slice()) { if (p.mesh) Engine.scene.remove(p.mesh); if (p.light) Engine.scene.removeLight(p.light); }
    Projectiles.list.length = 0;
    for (const p of Pickups.list.slice()) { Engine.scene.remove(p.mesh); Engine.scene.removeLight(p.light); }
    Pickups.list.length = 0;
    this.score = 0; this.kills = 0; this.headshots = 0; this.credits = 4;
    this.coreHealth = this.coreMax;
    this._warned = false;
    if (CRUCIBLE.coreMesh) CRUCIBLE.coreMesh.visible = true;
    Player.health = Player.maxHealth; Player.shield = Player.maxShield; Player.alive = true;
    Player.grenades = 4; Player.novaCooldown = 0;
    Player.pos = [0, World.heightAt(0, 16) + 1, 16];
    this.state = 'playing';
    Waves.start(1);
  },

  // ------------------------------------------------------------------- AI
  registerAI() {
    const r = AgerAI.router;
    r.register('spawnEnemy', (a) => {
      const kind = (a.kind || 'crawler').toLowerCase();
      if (!ENEMY_TYPES[kind]) return { result: `unknown enemy "${kind}" — try crawler, brute, sentinel, warden, prime`, ok: false };
      const count = clamp(a.count | 0 || 1, 1, 40);
      const near = a.near || 'ahead';
      const cam = Engine.camera;
      const cp = cam.getWorldPosition([0, 0, 0]);
      const fwd = cam.getForward([0, 0, 0]);
      for (let i = 0; i < count; i++) {
        const a2 = Math.random() * TAU, r2 = 8 + Math.random() * 22;
        const px = near === 'player' ? cp[0] + Math.cos(a2) * r2 : cp[0] + fwd[0] * 18 + Math.cos(a2) * r2;
        const pz = near === 'player' ? cp[2] + Math.sin(a2) * r2 : cp[2] + fwd[2] * 18 + Math.sin(a2) * r2;
        this.enemies.push(new Enemy(kind, [px, World.heightAt(px, pz) + 0.4, pz]));
      }
      return { result: `spawned ${count} ${kind}(s) near ${near}`, count };
    }, 'spawnEnemy {kind, count, near} — inject hostiles');
    r.register('clearEnemies', () => {
      let n = 0;
      for (const e of this.enemies) if (e.alive) { e.die(e.hitPosition([0, 0, 0])); n++; }
      return { result: `cleared ${n} hostiles` };
    }, 'clearEnemies — wipe every hostile');
    r.register('nextWave', () => { Waves.start(Waves.wave + 1); return { result: 'wave ' + Waves.wave }; }, 'nextWave — jump to the next wave');
    r.register('spawnBoss', (a) => {
      const kind = a.kind === 'prime' ? 'prime' : 'warden';
      const cam = Engine.camera;
      const cp = cam.getWorldPosition([0, 0, 0]);
      const fwd = cam.getForward([0, 0, 0]);
      const px = cp[0] + fwd[0] * 22, pz = cp[2] + fwd[2] * 22;
      this.enemies.push(new Enemy(kind, [px, World.heightAt(px, pz), pz]));
      HUD.banner(ENEMY_TYPES[kind].name + ' INBOUND', 'injected by command', 2600);
      return { result: kind + ' inbound' };
    }, 'spawnBoss {kind} — drop a boss in front of the player');
    r.register('godmode', () => { Player.godmode = !Player.godmode; return { result: 'godmode ' + Player.godmode }; }, 'godmode — toggle invulnerability');
    r.register('heal', () => { Player.health = Player.maxHealth; Player.shield = Player.maxShield; this.coreHealth = this.coreMax; return { result: 'player + crucible repaired' }; }, 'heal — repair the player and the Crucible');
    r.register('boom', () => {
      const cam = Engine.camera, cp = cam.getWorldPosition([0, 0, 0]), f = cam.getForward([0, 0, 0]);
      const p = [cp[0] + f[0] * 12, cp[1] + f[1] * 4, cp[2] + f[2] * 12];
      VFX.explosion(p, 2.2);
      this.areaDamage(p, 12, 180, Player);
      Engine.audio.explosion(p, 2);
      return { result: 'boom' };
    }, 'boom — detonate in front of the player');
    r.register('laserRain', () => {
      const cam = Engine.camera, cp = cam.getWorldPosition([0, 0, 0]);
      for (let i = 0; i < 40; i++) {
        const a = Math.random() * TAU, r = Math.random() * 30;
        this.spawnProjectile({
          pos: [cp[0] + Math.cos(a) * r, cp[1] + 22, cp[2] + Math.sin(a) * r], dir: [0, -1, 0], speed: 60,
          damage: 12, radius: 0.3, color: [1, 0.4, 0.5], owner: 'enemy', life: 1.2,
        });
      }
      return { result: 'orbital strike descending' };
    }, 'laserRain — rain plasma from the sky');
    r.register('enemySpeed', (a) => {
      for (const e of this.enemies) e.speedMul = clamp(a.value || 1, 0.2, 4);
      return { result: 'enemy speed ×' + (a.value || 1) };
    }, 'enemySpeed {value} — scale hostile movement');
    r.register('upgrade', (a) => {
      const i = UPGRADES.findIndex(u => u.label.toLowerCase().includes(String(a.name || '').toLowerCase()));
      if (i < 0) return { result: 'upgrades: ' + UPGRADES.map(u => u.label).join(', ') };
      UPGRADES[i].apply(this);
      return { result: 'applied ' + UPGRADES[i].label };
    }, 'upgrade {name} — grant an upgrade for free');
  },

  // -------------------------------------------------- photo / capture poses
  setPose(name) {
    this.poseMode = true;
    Player.godmode = true;
    const cam = Engine.camera;
    const S = Engine.scene, R = Engine.renderer;
    const clearEnemies = () => { for (const e of this.enemies) if (e.node) Engine.scene.remove(e.node); this.enemies.length = 0; };
    const spawnAt = (kind, x, z, delay = 0) => {
      const e = new Enemy(kind, [x, World.heightAt(x, z) + 0.4, z]);
      e.spawnTimer = delay;
      this.enemies.push(e);
      return e;
    };
    HUD.banner('', '');
    HUD.el.banner.style.opacity = '0';
    R.enableBloom = true; R.enableSSAO = true; R.enableGodrays = true;
    switch (name) {
      case '01-arena': {
        this.poseCameraFP = false;
        clearEnemies();
        S.setSunFromAngles(11 * DEG, 288 * DEG, [1.0, 0.55, 0.3], 3.0);
        S.sky.night = 0.3; S.sky.turbidity = 1.0;
        S.fog.color = [0.36, 0.33, 0.4]; S.fog.density = 0.0058; S.fog.height = 3;
        R.envDirty = true;
        cam.setPosition(-46, 16, 44);
        cam.lookAt([0, 4, -8]);
        for (let i = 0; i < 9; i++) spawnAt(i % 3 === 0 ? 'sentinel' : 'crawler', -34 + i * 8, 6 - (i % 3) * 7);
        break;
      }
      case '02-combat': {
        this.poseCameraFP = true;
        clearEnemies();
        S.setSunFromAngles(9 * DEG, 284 * DEG, [1.0, 0.5, 0.26], 2.6);
        S.sky.night = 0.34; S.sky.turbidity = 1.1;
        R.envDirty = true;
        const p = [4, 2.6, 18];
        Player.pos = [p[0], World.heightAt(p[0], p[2]) + 0.4, p[2]];
        Player.yaw = 0.10; Player.pitch = -0.05;
        Player.camPos = [p[0], p[1], p[2]];
        Player.view.muzzle.material.emissiveIntensity = 6.5;
        for (let i = 0; i < 9; i++) spawnAt(i % 4 === 2 ? 'brute' : 'crawler', -7 + i * 2.6, 4 - (i % 3) * 3.4, 0);
        Player.pos[0] += 0.001;
        this.poseHold = () => {
          // keep firing for the still
          if (Engine.frame % 6 === 0) {
            const cam2 = Engine.camera;
            const o = cam2.getWorldPosition([0, 0, 0]);
            const f = cam2.getForward([0, 0, 0]);
            Game.fireHitscan(o, f, WEAPONS.plasma, [o[0] + f[0], o[1] + f[1], o[2] + f[2]]);
          }
          // enemies freeze mid-charge for a clean composition
          for (const e of this.enemies) {
            e.spawnTimer = Math.max(e.spawnTimer, 0.05);
            e.state = 'chase';
            e.attackTimer = Math.max(e.attackTimer, 0.35);
          }
        };
        break;
      }
      case '03-nova': {
        this.poseCameraFP = true;
        clearEnemies();
        const p = [0, World.heightAt(0, 8), 8];
        Player.pos = [p[0], p[1], p[2]];
        Player.yaw = 0.0; Player.pitch = -0.02;
        Player.camPos = [p[0], p[1] + 1.6, p[2]];
        for (let i = 0; i < 12; i++) {
          const a = (i / 12) * TAU;
          spawnAt(i % 3 === 0 ? 'brute' : 'crawler', p[0] + Math.cos(a) * 8, p[2] + Math.sin(a) * 8 - 3, 0);
        }
        this.poseHold = () => {
          if (Engine.frame % 90 === 30) {
            const c = [Player.pos[0], Player.pos[1] + 0.9, Player.pos[2]];
            Game.nova(c, 14, 120, Player);
            Engine.audio.nova(c);
          }
          for (const e of this.enemies) { e.attackTimer = 99; }
        };
        break;
      }
      case '04-warden': {
        this.poseCameraFP = true;
        clearEnemies();
        S.setSunFromAngles(7 * DEG, 292 * DEG, [1.0, 0.44, 0.22], 2.2);
        S.sky.night = 0.4; R.envDirty = true;
        const p = [-8, World.heightAt(-8, 14) + 0.4, 14];
        Player.pos = [p[0], p[1], p[2]];
        Player.yaw = 0.16; Player.pitch = 0.05;
        Player.camPos = [p[0], p[1] + 1.7, p[2]];
        const w = spawnAt('warden', -10, 2, 0);
        w.state = 'chase';
        const b = spawnAt('brute', 4, 4, 0);
        const b2 = spawnAt('brute', -20, 8, 0);
        this.poseHold = () => { for (const e of this.enemies) { e.attackTimer = 99; } };
        break;
      }
      case '05-crucible': {
        this.poseCameraFP = false;
        clearEnemies();
        S.setSunFromAngles(-9 * DEG, 300 * DEG, [0.28, 0.36, 0.62], 0.35);
        S.sky.night = 0.95; S.sky.turbidity = 0.24;
        S.fog.color = [0.07, 0.10, 0.16]; S.fog.density = 0.009; S.fog.height = 3;
        R.envDirty = true;
        cam.setPosition(13, 3.4, -6);
        cam.lookAt([CRUCIBLE.CRUCIBLE_POS[0], 9.6, CRUCIBLE.CRUCIBLE_POS[2]]);
        break;
      }
      case '06-dawn': {
        this.poseCameraFP = false;
        clearEnemies();
        S.setSunFromAngles(3.4 * DEG, 96 * DEG, [1.0, 0.62, 0.32], 3.4);
        S.sky.night = 0.1; S.sky.turbidity = 1.3; S.sky.exposure = 1.0;
        S.fog.color = [0.45, 0.38, 0.34]; S.fog.density = 0.0055;
        R.envDirty = true;
        cam.setPosition(74, 4.6, -4);
        cam.lookAt([118, 2, -42]);
        for (let i = 0; i < 3; i++) spawnAt('sentinel', 92 + i * 6, -22 + i * 8, 0);
        break;
      }
      case '07-gameplay': {
        this.poseCameraFP = true;
        clearEnemies();
        const p = [10, World.heightAt(10, 10) + 0.4, 10];
        Player.pos = [p[0], p[1], p[2]];
        Player.yaw = 0.35; Player.pitch = -0.02;
        Player.camPos = [p[0], p[1] + 1.6, p[2]];
        for (let i = 0; i < 6; i++) spawnAt(i === 0 ? 'warden' : (i % 3 === 0 ? 'sentinel' : 'crawler'), -4 + i * 3.4, 2 - (i % 2) * 6, 0);
        this.poseHold = () => { for (const e of this.enemies) e.attackTimer = 99; };
        break;
      }
      default:
        clearEnemies();
        break;
    }
    Player.grounded = true;
    this.applyPoseCamera();
  },

  applyPoseCamera() {
    const cam = Engine.camera;
    if (!Player.camPos || !this.poseMode) return;
    if (this.poseCameraFP === false) return;   // pose already placed the camera itself
    cam.setPosition(Player.camPos[0], Player.camPos[1], Player.camPos[2]);
    Quat.fromEuler(cam.quaternion, Player.pitch || 0, Player.yaw || 0, 0);
    cam.markWorldDirty();
    cam.updateWorldMatrix();
  },

  updatePose(dt) {
    // keep the scene alive for captures: enemies idle, camera fixed
    const p = Player;
    for (const e of this.enemies) {
      e.update(dt, { pos: [999, 999, 999], alive: false, height: 1.8, radius: 0.4 }, this.physics, CRUCIBLE.CRUCIBLE_POS);
      e.attackTimer = 99;
    }
    Projectiles.update(dt, p, this.physics, this.enemies);
    if (this.poseHold) this.poseHold();
  },
};

// --- upgrades ---------------------------------------------------------------
const UPGRADES = [
  {
    label: '+20% WEAPON DAMAGE', cost: 3,
    apply: () => { for (const k of Object.keys(WEAPONS)) { WEAPONS[k].damage *= 1.2; } },
  },
  {
    label: '+30 MAX HEALTH (HEAL)', cost: 3,
    apply: () => { Player.maxHealth += 30; Player.health = Player.maxHealth; },
  },
  {
    label: 'FAST NOVA + GRENADE', cost: 4,
    apply: () => { Player.novaMax = Math.max(4, Player.novaMax - 1.6); Player.grenades = Math.min(6, Player.grenades + 2); },
  },
  {
    label: 'OVERCHARGED MAGAZINES', cost: 3,
    apply: () => { for (const k of Object.keys(WEAPONS)) { WEAPONS[k].mag = Math.round(WEAPONS[k].mag * 1.3); } Player.weapons.forEach(w => { w.ammo = WEAPONS[w.key].mag; w.reserve += WEAPONS[w.key].mag * 2; }); },
  },
  {
    label: 'REINFORCED CRUCIBLE', cost: 5,
    apply: () => { Game.coreHealth = Math.min(Game.coreMax, Game.coreHealth + 400); },
  },
];
