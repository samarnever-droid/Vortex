// ===========================================================================
//  AGER · CRUCIBLE  ·  120-player  ·  first person controller + weapon rig
// ===========================================================================

const WEAPONS = {
  plasma: {
    name: 'PLASMA LANCE', key: '1', auto: true, rpm: 460, damage: 24, headMult: 2.2, spread: 0.012,
    mag: 100, reload: 1.55, pellets: 1, tracer: [0.35, 0.85, 1.0], recoil: 0.9, kick: 0.035,
    sound: 'plasma', shake: 0.12, tracerSpeed: 130, ammoPerShot: 1,
  },
  scatter: {
    name: 'SCATTERGUN', key: '2', auto: false, rpm: 78, damage: 12, headMult: 1.6, spread: 0.075,
    mag: 24, reload: 2.1, pellets: 11, tracer: [1.0, 0.55, 0.2], recoil: 3.2, kick: 0.16,
    sound: 'scatter', shake: 0.4, tracerSpeed: 90, ammoPerShot: 1,
  },
  needler: {
    name: 'NEEDLER', key: '3', auto: true, rpm: 720, damage: 9, headMult: 1.8, spread: 0.028,
    mag: 160, reload: 1.8, pellets: 1, tracer: [1.0, 0.3, 0.35], recoil: 0.5, kick: 0.02,
    sound: 'laser', shake: 0.07, tracerSpeed: 160, ammoPerShot: 1,
  },
};

const Player = {
  pos: [0, 0, 12],
  vel: [0, 0, 0],
  radius: 0.42, height: 1.78, eye: 1.62,
  yaw: 0, pitch: 0,
  health: 100, maxHealth: 100, shield: 100, maxShield: 100,
  grounded: false, sprinting: false, crouch: 0, dashCooldown: 0, dashTime: 0,
  lastDamage: -99, regen: 0,
  weaponIndex: 0, weapons: ['plasma', 'scatter', 'needler'].map(k => ({ key: k, ammo: WEAPONS[k].mag, reserve: WEAPONS[k].mag * 6, cooldown: 0, reloading: 0 })),
  grenades: 4, novaCooldown: 0, novaMax: 9,
  kills: 0, headshots: 0, damageDealt: 0,
  bob: 0, bobPhase: 0, recoil: 0, camShake: 0, shakeSeed: Math.random() * 100,
  viewOffset: [0, 0, 0],
  alive: true, respawnTimer: 0,
  invuln: 0, godmode: false,
  footsteps: 0,

  init(scene, physics) {
    this.scene = scene; this.physics = physics;
    const input = Engine.input;
    input.bindings.dash = ['KeyF'];
    input.bindings.grenade = ['KeyG'];
    input.bindings.nova = ['KeyQ'];
    input.bindings.slot1 = ['Digit1']; input.bindings.slot2 = ['Digit2']; input.bindings.slot3 = ['Digit3'];
    this.buildViewModel();
    this.rig = CRUCIBLE.lights.rim;
    this.pos = [0, World.heightAt(0, 14) + 0.1, 14];
    return this;
  },

  // ---- first person weapon rig -------------------------------------------
  buildViewModel() {
    const M = MaterialLib;
    const cam = Engine.camera;
    const root = new Node('viewmodel');
    const dark = M.get('metalDark').clone({ name: 'vm_dark', uvScale: [3, 3] });
    const body = new Mesh(Geometry.box(0.14, 0.13, 0.62, 1), dark);
    body.setPosition(0, 0, -0.08);
    const barrel = new Mesh(Geometry.cylinder(0.032, 0.042, 0.5, 14), M.get('metal'));
    barrel.setRotation(Math.PI / 2, 0, 0);
    barrel.setPosition(0, 0.012, -0.45);
    const coil = new Mesh(Geometry.torus(0.062, 0.017, 18, 8), M.get('glow').clone({ name: 'vm_glow', color: 0x59e6ff, emissive: 0x59e6ff, emissiveIntensity: 3.4 }));
    coil.setRotation(Math.PI / 2, 0, 0);
    coil.setPosition(0, 0.012, -0.3);
    const mag = new Mesh(Geometry.box(0.07, 0.2, 0.11, 1), M.get('crate'));
    mag.setPosition(0, -0.16, 0.02);
    const grip = new Mesh(Geometry.box(0.06, 0.17, 0.08, 1), dark);
    grip.setRotation(0.32, 0, 0);
    grip.setPosition(0, -0.14, 0.2);
    const muzzle = new Mesh(Geometry.disc(0.12, 12), M.get('glow').clone({ name: 'vm_muzzle', color: 0xffd08a, emissive: 0xffc070, emissiveIntensity: 0.0, transparent: true, blending: 'additive', depthWrite: false }));
    muzzle.setPosition(0, 0.012, -0.72);
    muzzle.setRotation(Math.PI / 2, 0, 0);
    root.add(body); root.add(barrel); root.add(coil); root.add(mag); root.add(grip); root.add(muzzle);
    // the viewmodel must never be frustum culled (it hugs the camera)
    root.traverse(n => { if (n.isMesh) { n.tag = 'viewmodel'; n.skipReflection = true; n.material = n.material.clone({ receiveShadow: false, castShadow: false }); } });
    root.setPosition(0.26, -0.24, -0.52);
    root.setRotation(0.02, -0.06, 0);
    root.scale.set(1, 1, 1);
    cam.add(root);
    this.view = {
      root, body, barrel, coil, mag, grip, muzzle,
      rest: [0.26, -0.24, -0.52], restRot: [0.02, -0.06, 0],
    };
    // hands: two simple gauntlet blocks
    const handMat = M.get('metalDark').clone({ name: 'vm_hand', color: 0x5a6470, metalness: 0.6 });
    const handR = new Mesh(Geometry.box(0.11, 0.13, 0.16, 1), handMat);
    handR.setPosition(0.02, -0.08, 0.16);
    root.add(handR);
    const handL = new Mesh(Geometry.box(0.1, 0.11, 0.2, 1), handMat);
    handL.setPosition(-0.11, -0.04, -0.18);
    root.add(handL);
  },

  get weapon() { return WEAPONS[this.weapons[this.weaponIndex].key]; },
  get wstate() { return this.weapons[this.weaponIndex]; },

  // ---- main sim step (120 Hz) ---------------------------------------------
  update(dt) {
    if (!this.alive) {
      this.respawnTimer -= dt;
      if (this.respawnTimer <= 0) this.respawn();
      return;
    }
    const input = Engine.input;
    const cam = Engine.camera;
    // look
    const [dx, dy] = input.consumeMouse();
    this.yaw -= dx;
    this.pitch = clamp(this.pitch - dy, -1.45, 1.45);
    // stick look
    const gp = input.gamepadState;
    this.yaw -= gp.look[0] * 2.4 * dt;
    this.pitch = clamp(this.pitch - gp.look[1] * 1.8 * dt, -1.45, 1.45);

    // wish direction
    let fx = 0, fz = 0;
    if (input.isDown('forward')) fz += 1;
    if (input.isDown('back')) fz -= 1;
    if (input.isDown('left')) fx -= 1;
    if (input.isDown('right')) fx += 1;
    fx += gp.move[0]; fz -= gp.move[1];
    const len = Math.hypot(fx, fz);
    if (len > 1) { fx /= len; fz /= len; }
    // camera basis: right = (cos, 0, -sin), forward = (-sin, 0, -cos)
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    const wx = fx * cos - fz * sin;
    const wz = -fx * sin - fz * cos;

    this.sprinting = input.isDown('sprint') && fz > 0.1 && this.grounded;
    const crouching = input.isDown('crouch');
    this.crouch = damp(this.crouch, crouching ? 1 : 0, 12, dt);
    const speed = (this.sprinting ? 9.2 : (crouching ? 3.4 : 6.3)) * (this.dashTime > 0 ? 3.0 : 1);
    const accel = this.grounded ? (this.dashTime > 0 ? 90 : 52) : 9;
    const targetVx = wx * speed, targetVz = wz * speed;
    this.vel[0] = damp(this.vel[0], targetVx, accel * 0.16, dt);
    this.vel[2] = damp(this.vel[2], targetVz, accel * 0.16, dt);

    // ground friction when idle
    if (len < 0.01 && this.grounded) { this.vel[0] = damp(this.vel[0], 0, 14, dt); this.vel[2] = damp(this.vel[2], 0, 14, dt); }

    // jump / dash
    if ((input.pressed('jump') || (gp.jump && !this._gpJump)) && this.grounded) {
      this.vel[1] = 8.4;
      Engine.audio.jump(this.pos);
      this.grounded = false;
      this.camShake = Math.max(this.camShake, 0.1);
    }
    this._gpJump = gp.jump;
    if (input.pressed('dash') && this.dashCooldown <= 0 && (wx || wz)) {
      this.dashTime = 0.22; this.dashCooldown = 2.6;
      this.vel[0] = wx * 30; this.vel[2] = wz * 30; this.vel[1] = Math.max(this.vel[1], 1.4);
      Engine.audio.teleport(this.pos);
      FX.burst([this.pos[0], this.pos[1] + 1, this.pos[2]], { count: 16, color: [0.5, 0.85, 1], speed: 5, life: 0.4, size: 0.18, gravity: 0.2 });
    }
    this.dashTime = Math.max(0, this.dashTime - dt);
    this.dashCooldown = Math.max(0, this.dashCooldown - dt);
    this.dashCooldownEff = this.dashCooldown;

    this.vel[1] += -24 * dt;
    if (this.vel[1] < -55) this.vel[1] = -55;

    const motion = [this.vel[0] * dt, this.vel[1] * dt, this.vel[2] * dt];
    const res = this.physics.moveCapsule(this.pos, this.radius, this.height - this.crouch * 0.55, motion, {});
    const wasGrounded = this.grounded;
    this.grounded = res.grounded;
    this.pos[0] = res.position[0]; this.pos[1] = res.position[1]; this.pos[2] = res.position[2];
    if (res.grounded) {
      if (this.vel[1] < 0) {
        if (!wasGrounded && this.vel[1] < -8) {
          Engine.audio.land(this.pos, Math.min(2, -this.vel[1] / 9));
          this.camShake = Math.max(this.camShake, Math.min(0.5, -this.vel[1] / 60));
        }
        this.vel[1] = 0;
      }
      if (res.groundCollider || res.groundY !== undefined) { /* standing on something */ }
    }
    if (res.hitCeiling && this.vel[1] > 0) this.vel[1] = 0;

    // keep the player inside the arena
    const dist = Math.hypot(this.pos[0], this.pos[2]);
    if (dist > CRUCIBLE.OUTER_RADIUS - 6) {
      const k = (CRUCIBLE.OUTER_RADIUS - 6) / dist;
      this.pos[0] *= k; this.pos[2] *= k;
    }

    // weapons
    for (const w of this.weapons) { w.cooldown = Math.max(0, w.cooldown - dt); if (w.reloading > 0) { w.reloading -= dt; if (w.reloading <= 0) this.finishReload(w); } }
    if (input.pressed('slot1')) this.switchWeapon(0);
    if (input.pressed('slot2')) this.switchWeapon(1);
    if (input.pressed('slot3')) this.switchWeapon(2);
    if (input.consumeWheel() !== 0) this.switchWeapon((this.weaponIndex + 1) % this.weapons.length);
    if (input.pressed('reload')) this.startReload();
    if (input.isDown('fire') || gp.fire) this.tryFire(dt);
    if (input.pressed('altFire') && this.grenades > 0) this.throwGrenade();
    if (input.pressed('grenade') && this.grenades > 0) this.throwGrenade();
    if (input.pressed('nova') && this.novaCooldown <= 0) this.pulseNova();
    this.novaCooldown = Math.max(0, this.novaCooldown - dt);

    // health regen
    if (Engine.time - this.lastDamage > 6 && this.health < this.maxHealth) {
      this.regen += dt;
      if (this.regen > 0.08) { this.regen = 0; this.health = Math.min(this.maxHealth, this.health + 1.6); }
    }
    if (this.shield < this.maxShield && Engine.time - this.lastDamage > 3.2) {
      this.shield = Math.min(this.maxShield, this.shield + 22 * dt);
    }
    this.invuln = Math.max(0, this.invuln - dt);
    this.camShake = Math.max(0, this.camShake - dt * 2.2);

    // footsteps
    const hspeed = Math.hypot(this.vel[0], this.vel[2]);
    if (this.grounded && hspeed > 1.2) {
      this.bobPhase += dt * hspeed * 0.9;
      this.footsteps += dt * hspeed;
      if (this.footsteps > 7.2) { this.footsteps = 0; Engine.audio.footstep(this.pos, this.sprinting ? 1.3 : 1, 'metal'); }
    } else this.bobPhase += dt * 1.2;

    // camera
    const bobAmp = Math.min(0.055, hspeed * 0.008);
    const bobY = Math.sin(this.bobPhase * 2) * bobAmp;
    const bobX = Math.cos(this.bobPhase) * bobAmp * 0.7;
    const eyeY = this.eye - this.crouch * 0.55;
    const shake = this.camShake;
    const st = Engine.time * 34 + this.shakeSeed;
    this.camPos = [
      this.pos[0] + bobX * 0.5 + Math.sin(st) * shake * 0.09,
      this.pos[1] + eyeY + bobY + Math.sin(st * 1.7) * shake * 0.12,
      this.pos[2] + Math.cos(this.bobPhase) * bobAmp * 0.2 + Math.cos(st * 1.3) * shake * 0.09,
    ];
    cam.setPosition(this.camPos[0], this.camPos[1], this.camPos[2]);
    cam.pitch = this.pitch; cam.yaw = this.yaw;
    Quat.fromEuler(cam.quaternion, this.pitch, this.yaw, Math.sin(st * 0.7) * shake * 0.05);
    cam.fov = (Engine.camera.fovBase || 68) * DEG + (this.sprinting ? 4 * DEG : 0) + (this.dashTime > 0 ? 6 * DEG : 0);

    this.updateViewModel(dt, hspeed);
  },

  updateViewModel(dt, hspeed) {
    const v = this.view;
    if (!v) return;
    const t = Engine.time;
    const swayX = Math.cos(this.bobPhase) * Math.min(0.02, hspeed * 0.0032);
    const swayY = Math.sin(this.bobPhase * 2) * Math.min(0.018, hspeed * 0.0028);
    const idle = Math.sin(t * 1.6) * 0.004;
    const kick = this.recoil;
    const reload = this.wstate.reloading > 0 ? Math.sin(clamp(1 - this.wstate.reloading / this.weapon.reload, 0, 1) * Math.PI) : 0;
    v.root.position[0] = damp(v.root.position[0], v.rest[0] + swayX, 14, dt);
    v.root.position[1] = damp(v.root.position[1], v.rest[1] + swayY + idle - reload * 0.16, 14, dt);
    v.root.position[2] = damp(v.root.position[2], v.rest[2] + kick * 0.42 * 0.5, 22, dt);
    v.root.quaternion.set(Quat.fromEuler(v.root.quaternion, v.restRot[0] - kick * 0.5 * 0.5 + reload * 0.5, v.restRot[1] + swayX * 1.6, v.restRot[2] + reload * 0.35));
    v.root.markWorldDirty();
    this.recoil = damp(this.recoil, 0, 9, dt);
    // muzzle flash decay
    const mz = v.muzzle.material;
    mz.emissiveIntensity = damp(mz.emissiveIntensity, 0, 26, dt);
    mz.opacity = clamp(mz.emissiveIntensity / 8, 0, 1);
    // coil glow follows weapon heat
    const heat = 1 - clamp(this.wstate.cooldown / 0.14, 0, 1);
    v.coil.material.emissiveIntensity = 2.4 + heat * 4.0;
    v.coil.material.emissive = [0.35 + heat * 0.6, 0.85, 1.0];
    // swap the model look per weapon
    const w = this.weapon;
    const scale = this.weaponIndex === 1 ? 1.25 : (this.weaponIndex === 2 ? 0.85 : 1);
    v.root.scale[0] = v.root.scale[1] = v.root.scale[2] = damp(v.root.scale[0], scale, 8, dt);
  },

  switchWeapon(i) {
    if (i === this.weaponIndex) return;
    this.weaponIndex = i;
    this.recoil = 0.5;
    Engine.audio.uiClick();
    HUD.log(`<b>${this.weapon.name}</b> equipped`);
  },

  startReload() {
    const w = this.wstate, def = this.weapon;
    if (w.reloading > 0 || w.ammo >= def.mag || w.reserve <= 0) return;
    w.reloading = def.reload;
    Engine.audio.pickup(this.pos, 0.7);
  },
  finishReload(w) {
    const def = WEAPONS[w.key];
    const need = def.mag - w.ammo;
    const take = Math.min(need, w.reserve);
    w.ammo += take; w.reserve -= take;
    Engine.audio.uiClick(true);
  },

  tryFire(dt) {
    const w = this.wstate, def = this.weapon;
    if (w.reloading > 0) return;
    if (w.cooldown > 0) return;
    if (w.ammo <= 0) { if (w.reserve > 0) this.startReload(); else { Engine.audio.uiClick(); w.cooldown = 0.4; HUD.log('<b>NO AMMO</b> — find a supply crate'); } return; }
    w.cooldown = 60 / def.rpm;
    w.ammo -= def.ammoPerShot;
    this.recoil = Math.min(2.4, this.recoil + def.recoil * 0.18);
    this.camShake = Math.max(this.camShake, def.shake);
    if (def.sound === 'scatter') Engine.audio.explosion(this.pos, 0.35);
    else if (def.sound === 'laser') Engine.audio.laserShot(this.pos, 1 + Math.random() * 0.1);
    else Engine.audio.plasmaShot(this.pos, 1 + Math.random() * 0.08);
    const cam = Engine.camera;
    const origin = cam.getWorldPosition([0, 0, 0]);
    const fwd = cam.getForward([0, 0, 0]);
    const right = cam.getRight([0, 0, 0]);
    const up = cam.getUp([0, 0, 0]);
    const muzzlePos = [origin[0] + right[0] * 0.2 + fwd[0] * 0.7, origin[1] + right[1] * 0.2 + fwd[1] * 0.7 - 0.12, origin[2] + right[2] * 0.2 + fwd[2] * 0.7];
    // muzzle flash
    this.view.muzzle.material.emissiveIntensity = 7;
    this.view.muzzle.material.opacity = 1;
    FX.burst(muzzlePos, { count: 3, dir: fwd, speed: 4, life: 0.12, size: 0.14, color: def.tracer, drag: 6, gravity: 0, collide: false, jitter: 0.05 });
    for (let p = 0; p < def.pellets; p++) {
      const spread = def.spread * (this.sprinting ? 1.6 : 1) * (this.crouch > 0.5 ? 0.5 : 1);
      const dir = [
        fwd[0] + (Math.random() - 0.5) * spread * 2 * (p === 0 && def.pellets === 1 ? 0.4 : 1) + right[0] * (Math.random() - 0.5) * spread,
        fwd[1] + (Math.random() - 0.5) * spread * 2 + up[1] * (Math.random() - 0.5) * spread,
        fwd[2] + (Math.random() - 0.5) * spread * 2 * (p === 0 && def.pellets === 1 ? 0.4 : 1) + right[2] * (Math.random() - 0.5) * spread,
      ];
      Vec3.normalize(dir, dir);
      Game.fireHitscan(origin, dir, def, muzzlePos);
    }
  },

  throwGrenade() {
    this.grenades--;
    const cam = Engine.camera;
    const fwd = cam.getForward([0, 0, 0]);
    const origin = cam.getWorldPosition([0, 0, 0]);
    Game.spawnGrenade([origin[0] + fwd[0], origin[1] + fwd[1] * 0.4, origin[2] + fwd[2]], [fwd[0] * 22, fwd[1] * 22 + 5, fwd[2] * 22]);
    Engine.audio.teleport(this.pos);
  },

  pulseNova() {
    this.novaCooldown = this.novaMax;
    const p = [this.pos[0], this.pos[1] + 0.9, this.pos[2]];
    Game.nova(p, 14, 120, this);
    Engine.audio.nova(p);
    this.camShake = Math.max(this.camShake, 0.9);
    FX.ring(p, [0.5, 0.9, 1.0], 44, 22, 0.7);
    HUD.log('<b>PULSE NOVA</b> discharged');
  },

  takeDamage(amount, from) {
    if (!this.alive || this.godmode) return;
    if (this.invuln > 0) return;
    const absorbed = Math.min(this.shield, amount * 0.7);
    this.shield -= absorbed;
    this.health -= (amount - absorbed);
    this.lastDamage = Engine.time;
    this.camShake = Math.max(this.camShake, Math.min(1.0, amount / 30));
    Engine.audio.hurt();
    HUD.damageFlash(Math.min(0.8, amount / 45));
    HUD.damageDirection(from);
    if (this.health <= 0) this.die();
  },

  die() {
    this.alive = false;
    this.respawnTimer = 3.4;
    this.health = 0;
    Engine.audio.explosion(this.pos, 0.8);
    FX.debris([this.pos[0], this.pos[1] + 1, this.pos[2]], 20, { color: [0.5, 0.2, 0.16] });
    HUD.log('<b style="color:#ff6b5e">YOU DIED</b> — reconstruction in progress');
    Game.onPlayerDeath();
  },

  respawn() {
    this.alive = true;
    this.health = this.maxHealth; this.shield = this.maxShield;
    this.pos = [0, World.heightAt(0, 16) + 1, 16];
    this.vel = [0, 0, 0];
    this.weapons.forEach((w, i) => { w.ammo = WEAPONS[w.key].mag; w.reserve = Math.max(w.reserve, WEAPONS[w.key].mag * 2); w.reloading = 0; });
    this.grenades = Math.max(this.grenades, 2);
    this.invuln = 2.0;
    HUD.log('<b style="color:#7ef7c8">RESPAWNED</b> — the Crucible still stands');
  },

  heal(v) {
    if (this.health >= this.maxHealth) { this.shield = Math.min(this.maxShield, this.shield + v * 0.5); return false; }
    this.health = Math.min(this.maxHealth, this.health + v);
    return true;
  },
  addShield(v) { this.shield = Math.min(this.maxShield, this.shield + v); },
  addAmmo(frac = 0.4) {
    for (const w of this.weapons) w.reserve += Math.round(WEAPONS[w.key].mag * frac);
    this.grenades = Math.min(6, this.grenades + 1);
  },
};
