// ===========================================================================
//  AGER · CRUCIBLE  ·  150-vfx  ·  impacts, tracers, beams, explosions
// ===========================================================================

const VFX = {
  tracers: [],
  beams: [],
  init(scene, physics) {
    this.scene = scene; this.physics = physics;
    this.tracerMat = MaterialLib.get('glow').clone({
      name: 'tracer', transparent: true, blending: 'additive', depthWrite: false, castShadow: false, receiveShadow: false,
    });
    this.beamMat = MaterialLib.get('glow').clone({
      name: 'beam', transparent: true, blending: 'additive', depthWrite: false, opacity: 0.5, castShadow: false, receiveShadow: false,
    });
    this.geo = Geometry.cylinder(0.035, 0.035, 1, 6);
    this.geoBeam = Geometry.cylinder(0.12, 0.22, 1, 8);
    this.pool = [];
    this.beamPool = [];
    return this;
  },
  _get(pool, geo, mat) {
    const m = pool.pop();
    if (m) { m.visible = true; return m; }
    const mesh = new Mesh(geo, mat, 'tracer');
    mesh.tag = 'transient';
    mesh.skipShadow = true;
    mesh.skipReflection = true;
    mesh.material = mesh.material.clone({ castShadow: false, receiveShadow: false });
    this.scene.add(mesh);
    return mesh;
  },
  tracer(from, to, color, thickness = 1) {
    const mesh = this._get(this.pool, this.geo, this.tracerMat);
    const dx = to[0] - from[0], dy = to[1] - from[1], dz = to[2] - from[2];
    const len = Math.hypot(dx, dy, dz) || 0.001;
    mesh.setPosition((from[0] + to[0]) / 2, (from[1] + to[1]) / 2, (from[2] + to[2]) / 2);
    const yaw = Math.atan2(dx, dz);
    const pitch = Math.acos(clamp(dy / len, -1, 1));
    mesh.setRotation(pitch, yaw, 0);
    const sc = [thickness, len, thickness];
    // cylinder is authored along Y: rotate then scale
    mesh.quaternion.set(Quat.fromEuler(mesh.quaternion, pitch, yaw, 0));
    mesh.markWorldDirty();
    mesh.setScale(sc[0], sc[1], sc[2]);
    mesh.material.emissive = [color[0], color[1], color[2]];
    mesh.material.emissiveIntensity = 3.4;
    mesh.material.opacity = 0.85;
    mesh.updateWorldMatrix();
    this.tracers.push({ mesh, life: 0.09, max: 0.09 });
  },
  beam(from, to, color, thickness = 1, life = 0.25) {
    const mesh = this._get(this.beamPool, this.geoBeam, this.beamMat);
    const dx = to[0] - from[0], dy = to[1] - from[1], dz = to[2] - from[2];
    const len = Math.hypot(dx, dy, dz) || 0.001;
    mesh.setPosition((from[0] + to[0]) / 2, (from[1] + to[1]) / 2, (from[2] + to[2]) / 2);
    const yaw = Math.atan2(dx, dz);
    const pitch = Math.acos(clamp(dy / len, -1, 1));
    mesh.quaternion.set(Quat.fromEuler(mesh.quaternion, pitch, yaw, 0));
    mesh.markWorldDirty();
    mesh.setScale(thickness, len, thickness);
    mesh.material.emissive = color;
    mesh.material.emissiveIntensity = 2.2;
    mesh.material.opacity = 0.7;
    mesh.updateWorldMatrix();
    this.beams.push({ mesh, life, max: life });
  },
  impact(point, normal, opts = {}) {
    const surface = opts.surface || 'concrete';
    const color = opts.color || [1, 0.8, 0.45];
    const n = normal || [0, 1, 0];
    this.scene && 0;
    // sparks fly back along the normal
    FX.burst(point, {
      count: opts.count || 10, dir: n, speed: opts.speed || 6, spread: 0.9, life: 0.4, size: 0.14,
      color, drag: 3.4, gravity: -6, jitter: 0.06, collide: true, bounce: 0.4,
    });
    if (opts.smoke !== false) FX.smoke(point, 2, { size: 0.22, life: 0.9, color: [0.35, 0.33, 0.3] });
    if (opts.decal && n[1] > 0.6) {
      FX.decal(point[0], point[1], point[2], 0.7 + Math.random() * 0.5, 16, Math.random() * TAU);
    }
    Engine.audio.impact(point, surface);
  },
  explosion(point, size = 1, color = [1, 0.62, 0.28]) {
    FX.burst(point, { count: Math.round(24 * size), speed: 12 * size, life: 0.7, size: 0.32 * size, color, gravity: 5, drag: 1.8, jitter: 0.5 });
    FX.smoke(point, Math.round(10 * size), { size: 0.7 * size, life: 2.2 });
    FX.ring(point, color, Math.round(20 * size), 12 * size, 0.5);
    FX.decal(point[0], World.heightAt(point[0], point[2]), point[2], 2.6 * size, 22, Math.random() * TAU);
    const flash = new Mesh(Geometry.icosphere(1.4 * size, 1), MaterialLib.get('glow').clone({
      name: 'blast', color: color[0] * 255, emissive: color[0] * 255, emissiveIntensity: 6, transparent: true, blending: 'additive', depthWrite: false,
    }));
    flash.setPosition(point[0], point[1], point[2]);
    flash.tag = 'transient';
    this.scene.add(flash);
    this.beams.push({ mesh: flash, life: 0.18, max: 0.18, scale: 1, blast: true });
  },
  update(dt) {
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const t = this.tracers[i];
      t.life -= dt;
      const k = t.life / t.max;
      t.mesh.material.opacity = 0.9 * k;
      t.mesh.material.emissiveIntensity = 3.4 * k;
      if (t.life <= 0) { t.mesh.visible = false; this.tracers.splice(i, 1); this.pool.push(t.mesh); }
    }
    for (let i = this.beams.length - 1; i >= 0; i--) {
      const b = this.beams[i];
      b.life -= dt;
      const k = clamp(b.life / b.max, 0, 1);
      if (b.blast) {
        b.mesh.setScale(1 + (1 - k) * 3, 1 + (1 - k) * 3, 1 + (1 - k) * 3);
        b.mesh.material.emissiveIntensity = 8 * k;
      } else {
        b.mesh.material.opacity = 0.7 * k;
        b.mesh.material.emissiveIntensity = 2.2 * k;
      }
      if (b.life <= 0) {
        this.scene.remove(b.mesh);
        if (!b.blast) this.beamPool.push(b.mesh);
        this.beams.splice(i, 1);
      }
    }
  },
};
