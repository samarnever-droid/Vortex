// ===========================================================================
//  AGER · CRUCIBLE  ·  100-main  ·  boot, loading, menu, session
// ===========================================================================

(function () {
  window.__AGER_ERRORS__ = [];
  const _err = console.error.bind(console);
  console.error = function (...a) { window.__AGER_ERRORS__.push(a.map(String).join(' ')); _err(...a); };
  addEventListener('error', (e) => window.__AGER_ERRORS__.push('window: ' + (e.message || e.error)));

  const params = new URLSearchParams(location.search);
  const bootBar = document.getElementById('ager-boot-bar');
  const bootSt = document.getElementById('ager-boot-st');
  const bootEl = document.getElementById('ager-boot');
  const setProgress = (p, msg) => {
    if (bootBar) bootBar.style.width = clamp(p, 0, 1) * 100 + '%';
    if (bootSt && msg) bootSt.textContent = msg;
  };

  Ager._boot = async function () {
    setProgress(0.04, 'initialising WebGL2 device');
    await frame();
    const created = Ager.create({ canvas: document.getElementById('ager-canvas') || undefined, fov: 74, far: 900 });
    const { engine, scene, camera, renderer, device } = created;
    Engine.camera.fovBase = 74;
    AgerAI.context.engine = engine;
    setProgress(0.1, 'compiling shaders · ' + device.renderer.slice(0, 42));
    await frame();
    // procedural texture generation on the main thread but in slices, so the
    // loading bar actually moves
    MaterialLib.build(device, 256, (p, name) => setProgress(0.1 + p * 0.55, 'synthesising material · ' + name));
    setProgress(0.68, 'forging the arena');
    await frame();
    const world = buildWorld(scene, engine.physics);
    setProgress(0.82, 'waking the hostiles');
    await frame();
    Game.init();
    setProgress(0.94, 'spooling audio synthesiser');
    await frame();
    // shader warm-up: compile the main programs before the first frame
    try { renderer.render(scene, camera, 0.016); } catch (e) { console.error('[warmup] ' + e.message); }
    setProgress(1, 'ready');
    await sleep(120);

    window.AGER_GAME = { Game, Player, Waves, HUD, World, CRUCIBLE, ENEMY_TYPES, WEAPONS, Pickups, Projectiles, VFX };
    window.__AGER_READY__ = true;
    window.__AGER_SHOT_LIST__ = ['01-arena', '02-combat', '03-nova', '04-warden', '05-crucible', '06-dawn', '07-gameplay'];
    window.__AGER_POSE__ = async (name) => {
      Engine.paused = false;
      Game.state = 'playing';
      HUD.root.style.display = params.get('hud') === '0' ? 'none' : '';
      Game.setPose(name);
      await new Promise(r => setTimeout(r, 420));
      return true;
    };
    // deep-link support for the capture harness
    const pose = params.get('pose');
    if (pose) {
      hideBoot();
      Engine.start();
      await window.__AGER_POSE__(pose);
    } else {
      showMenu();
    }
    Engine.start();
  };

  const frame = () => new Promise(r => requestAnimationFrame(() => r()));
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function hideBoot() {
    if (!bootEl) return;
    bootEl.style.opacity = '0';
    setTimeout(() => bootEl.remove(), 700);
  }

  function showMenu() {
    const el = document.createElement('div');
    el.id = 'mainmenu';
    el.style.cssText = `position:fixed;inset:0;z-index:20;display:flex;align-items:center;justify-content:space-between;
      flex-direction:column;font-family:ui-monospace,Menlo,Consolas,monospace;color:#dff6ff;
      background:radial-gradient(ellipse at 50% 120%, rgba(6,16,24,.55), rgba(2,5,9,.9) 70%);backdrop-filter:blur(2px)`;
    el.innerHTML = `
      <div style="height:8vh"></div>
      <div style="text-align:center">
        <div style="font-size:12px;letter-spacing:.6em;opacity:.55;margin-bottom:6px">AGER ENGINE ${AGER_VERSION.split('-')[0]}</div>
        <div style="font-size:clamp(46px,10vw,104px);letter-spacing:.22em;font-weight:600;text-shadow:0 0 40px rgba(70,200,255,.35);margin-left:.22em">CRUCIBLE</div>
        <div style="font-size:12px;letter-spacing:.32em;opacity:.6;margin-top:12px">DEFEND THE CORE · SURVIVE THE GATE</div>
        <div style="margin-top:38px">
          <button id="play" style="pointer-events:auto;background:linear-gradient(180deg,rgba(24,80,110,.95),rgba(8,30,44,.95));
            border:1px solid rgba(120,220,255,.6);color:#eafcff;font-family:inherit;font-size:15px;letter-spacing:.3em;padding:16px 54px;cursor:pointer;
            box-shadow:0 0 34px rgba(60,190,255,.25)">DEPLOY</button>
        </div>
        <div style="margin-top:16px;font-size:11px;opacity:.5;letter-spacing:.12em">click to capture the mouse · F3 stats · \` console</div>
      </div>
      <div style="display:flex;gap:52px;font-size:11.5px;opacity:.72;letter-spacing:.07em;max-width:1080px;padding:0 32px 26px;flex-wrap:wrap;justify-content:center">
        <div><div style="opacity:.5;letter-spacing:.24em;margin-bottom:5px">MOVE</div>WASD · SHIFT sprint<br>SPACE jump · F dash</div>
        <div><div style="opacity:.5;letter-spacing:.24em;margin-bottom:5px">FIGHT</div>MOUSE fire · RMB grenade<br>R reload · 1/2/3 weapons</div>
        <div><div style="opacity:.5;letter-spacing:.24em;margin-bottom:5px">POWERS</div>Q pulse nova<br>G grenade</div>
        <div><div style="opacity:.5;letter-spacing:.24em;margin-bottom:5px">THE ENGINE</div>\` console · 7/8/9 resupply<br>try "night" or "spawn 20 crawlers"</div>
      </div>`;
    document.body.appendChild(el);
    el.querySelector('#play').onclick = () => {
      el.remove();
      hideBoot();
      Engine.audio.init();
      Engine.audio.resume();
      Engine.input.requestLock();
      if (params.get('hud') === '0') HUD.root.style.display = 'none';
      Game.start();
      HUD.log('<b>Click</b> to capture the mouse. <b>`</b> opens the engine console.');
    };
    // subtle idle camera drift behind the menu
    Engine.on('lateUpdate', (dt) => {
      if (document.getElementById('mainmenu') && Game.state !== 'playing') {
        const t = Engine.time * 0.06;
        const cam = Engine.camera;
        cam.setPosition(Math.cos(t) * 58, 12 + Math.sin(t * 0.7) * 3, Math.sin(t) * 58);
        cam.lookAt([0, 6, 0]);
      }
    });
  }

  function boot() {
    const start = async () => {
      try {
        await Ager._boot();
      } catch (e) {
        console.error('[boot] ' + (e && e.stack || e));
        if (bootSt) bootSt.textContent = 'boot failed: ' + e.message;
      }
    };
    if (document.readyState === 'loading') addEventListener('DOMContentLoaded', start);
    else start();
  }
  window.__AGER_START__ = boot;
  boot();
})();
