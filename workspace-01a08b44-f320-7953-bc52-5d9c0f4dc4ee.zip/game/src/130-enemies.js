// ===========================================================================
//  AGER · CRUCIBLE  ·  130-enemies  ·  hostiles, projectiles, pickups
// ===========================================================================

const ENEMY_TYPES = {
  crawler: {
    name: 'CRAWLER', health: 74, speed: 7.4, radius: 0.55, height: 1.5, damage: 14, attackRange: 2.1,
    attackCooldown: 1.05, score: 100, mass: 1, color: 0xff4a3a, accent: 0xff8b3a, head: [0, 1.05, 0],
  },
  brute: {
    name: 'BRUTE', health: 240, speed: 4.1, radius: 0.85, height: 2.6, damage: 32, attackRange: 3.0,
    attackCooldown: 1.6, score: 260, mass: 3, color: 0xff2a1a, accent: 0xffb03a, head: [0, 2.1, 0],
  },
  sentinel: {
    name: 'SENTINEL', health: 92, speed: 5.2, radius: 0.7, height: 1.6, damage: 13, attackRange: 34,
    attackCooldown: 1.5, score: 190, mass: 1, flying: 3.4, color: 0x8a5cff, accent: 0x5ce1ff, head: [0, 0.2, 0],
  },
  warden: {
    name: 'WARDEN', health: 1500, speed: 3.2, radius: 1.5, height: 4.6, damage: 46, attackRange: 5.2,
    attackCooldown: 2.1, score: 1500, mass: 12, flying: 0, color: 0xff3a1a, accent: 0xffe24a, head: [0, 3.6, 0],
    boss: true, slam: true,
  },
  prime: {
    name: 'WARDEN PRIME', health: 3400, speed: 3.6, radius: 1.9, height: 6.2, damage: 58, attackRange: 6.5,
    attackCooldown: 1.8, score: 4000, mass: 20, color: 0xff0044, accent: 0xffe24a, head: [0, 4.9, 0],
    boss: true, slam: true, ranged: true,
  },
};

let _enemyId = 0;

class Enemy {
  constructor(kind, position) {
    this.id = ++_enemyId;
    this.kind = kind;
    const T = ENEMY_TYPES[kind];
    this.type = T;
    this.name = T.name;
    this.pos = Vec3.of(position);
    this.vel = Vec3.create();
    this.health = T.health; this.maxHealth = T.health;
    this.radius = T.radius; this.height = T.height;
    this.attackTimer = Math.random() * 0.6;
    this.stagger = 0;
    this.alive = true;
    this.deathTimer = 0;
    this.state = 'spawn';
    this.spawnTimer = 0.9;
    this.wobble = Math.random() * TAU;
    this.target = null;
    this.hitFlash = 0;
    this.speedMul = 1;
    this.build();
  }

  build() {
    const M = MaterialLib;
    const T = this.type;
    const root = new Node('enemy_' + this.kind);
    const shell = M.get('metalDark').clone({ name: 'e_shell_' + this.kind, color: T.color, roughness: 0.62, metalness: 0.75, uvScale: [2, 2] });
    const glowMat = M.get('glow').clone({ name: 'e_glow', color: T.accent, emissive: T.accent, emissiveIntensity: 3.2 });
    this.materials = [shell, glowMat];
    this.parts = { legs: [] };
    if (this.kind === 'crawler' || this.kind === 'brute') {
      const s = this.kind === 'brute' ? 1.9 : 1;
      const body = new Mesh(Geometry.box(0.8 * s, 0.62 * s, 1.5 * s, 1), shell);
      body.setPosition(0, 0.95 * s, 0);
      const headMesh = new Mesh(Geometry.box(0.52 * s, 0.42 * s, 0.6 * s, 1), shell);
      headMesh.setPosition(0, 1.2 * s, -1.0 * s);
      const eye = new Mesh(Geometry.icosphere(0.11 * s, 1), glowMat);
      eye.setPosition(0, 1.22 * s, -1.28 * s);
      const spine = new Mesh(Geometry.cone(0.3 * s, 0.9 * s, 8), shell);
      spine.setPosition(0, 1.35 * s, 0.5 * s);
      root.add(body); root.add(headMesh); root.add(eye); root.add(spine);
      for (let i = 0; i < 4; i++) {
        const side = i % 2 ? 1 : -1;
        const front = i < 2 ? -1 : 1;
        const leg = new Mesh(Geometry.cylinder(0.07 * s, 0.1 * s, 1.1 * s, 6), shell);
        leg.setPosition(side * 0.42 * s, 0.55 * s, front * 0.45 * s);
        const pivot = new Node('legpivot');
        pivot.setPosition(side * 0.42 * s, 0.85 * s, front * 0.45 * s);
        leg.setPosition(0, -0.45 * s, 0);
        leg.setRotation(0, 0, side * 0.35);
        pivot.add(leg);
        root.add(pivot);
        this.parts.legs.push({ pivot, leg, side, front });
      }
      this.parts.eye = eye;
      this.parts.head = headMesh;
    } else if (this.kind === 'sentinel') {
      const core = new Mesh(Geometry.icosphere(0.44, 2), shell);
      const eye = new Mesh(Geometry.icosphere(0.2, 2), glowMat);
      eye.setPosition(0, 0, -0.34);
      const ring1 = new Mesh(Geometry.torus(0.72, 0.075, 22, 8), shell);
      ring1.setRotation(Math.PI / 2.2, 0, 0);
      const ring2 = new Mesh(Geometry.torus(0.6, 0.06, 20, 8), shell);
      ring2.setRotation(0, 0, Math.PI / 2.5);
      root.add(core); root.add(eye); root.add(ring1); root.add(ring2);
      this.parts.rings = [ring1, ring2];
      this.parts.eye = eye;
    } else {
      // warden / prime: heavy biped
      const s = this.kind === 'prime' ? 1.35 : 1;
      const torso = new Mesh(Geometry.box(1.9 * s, 2.0 * s, 1.3 * s, 1), shell);
      torso.setPosition(0, 2.5 * s, 0);
      const shoulders = new Mesh(Geometry.box(2.9 * s, 0.7 * s, 1.1 * s, 1), shell);
      shoulders.setPosition(0, 3.3 * s, 0);
      const headMesh = new Mesh(Geometry.box(0.75 * s, 0.62 * s, 0.8 * s, 1), shell);
      headMesh.setPosition(0, 3.9 * s, -0.15 * s);
      const eye = new Mesh(Geometry.box(0.66 * s, 0.14 * s, 0.1 * s, 1), glowMat);
      eye.setPosition(0, 3.92 * s, -0.56 * s);
      const core = new Mesh(Geometry.icosphere(0.42 * s, 2), glowMat.clone({ name: 'e_core', color: this.type.accent, emissive: this.type.accent }));
      core.setPosition(0, 2.6 * s, -0.62 * s);
      root.add(torso); root.add(shoulders); root.add(headMesh); root.add(eye); root.add(core);
      for (let i = 0; i < 2; i++) {
        const side = i ? 1 : -1;
        const arm = new Mesh(Geometry.box(0.52 * s, 1.9 * s, 0.52 * s, 1), shell);
        const pivot = new Node('armpivot');
        pivot.setPosition(side * 1.35 * s, 3.2 * s, 0);
        arm.setPosition(0, -0.95 * s, 0);
        pivot.add(arm);
        root.add(pivot);
        const leg = new Mesh(Geometry.box(0.62 * s, 2.1 * s, 0.7 * s, 1), shell);
        leg.setPosition(side * 0.55 * s, 1.05 * s, 0);
        root.add(leg);
        this.parts.legs.push({ pivot, leg, side, front: 0 });
      }
      this.parts.eye = eye;
      this.parts.core = core;
      this.parts.torso = torso;
      this.parts.head = headMesh;
    }
    root.scale.set(1, 1, 1);
    Engine.scene.add(root);
    this.node = root;
    this.worldPos = Vec3.create();
    this.syncNode();
  }

  syncNode() {
    if (this.state === 'dying') return;
    const T = this.type;
    const y = this.pos[1] + (T.flying ? T.flying : 0);
    this.node.setPosition(this.pos[0], y, this.pos[2]);
    if (this.state === 'spawn') {
      const t = 1 - this.spawnTimer / 0.9;
      const s = Math.max(0.05, t);
      this.node.setScale(s, s, s);
      this.node.setRotation(0, this.wobble + Engine.time * 6, 0);
      this.node.markWorldDirty();
      // rise out of the ground
      this.node.position[1] = y - (1 - t) * 1.5;
    }
  }

  hitPosition(out = [0, 0, 0]) {
    out[0] = this.pos[0] + this.type.head[0];
    out[1] = this.pos[1] + this.type.head[1] + (this.type.flying || 0);
    out[2] = this.pos[2] + this.type.head[2];
    return out;
  }

  takeDamage(amount, point, isHead, source) {
    if (!this.alive || this.state === 'dying') return 0;
    const dealt = isHead ? amount * 1.0 : amount;
    this.health -= dealt;
    this.hitFlash = 0.12;
    this.stagger = Math.min(0.35, this.stagger + dealt / this.maxHealth * 0.5);
    for (const m of this.materials) if (m.emissiveIntensity !== undefined) m.emissiveIntensity = Math.min(9, m.emissiveIntensity + 2.5);
    if (this.health <= 0) this.die(point);
    return dealt;
  }

  die(point) {
    this.alive = false;
    this.state = 'dying';
    this.deathTimer = 0.4;
    const T = this.type;
    Engine.audio.explosion(this.pos, T.boss ? 2.4 : 0.8);
    FX.burst([this.pos[0], this.pos[1] + this.height * 0.5, this.pos[2]], {
      count: T.boss ? 90 : 26, speed: T.boss ? 16 : 8, life: T.boss ? 1.1 : 0.6,
      size: 0.3, color: [this.type.accent[0] / 255, this.type.accent[1] / 255, this.type.accent[2] / 255], gravity: 6, drag: 1.4,
    });
    FX.debris([this.pos[0], this.pos[1] + this.height * 0.5, this.pos[2]], T.boss ? 40 : 12, { color: [T.color[0] / 255, T.color[1] / 255, T.color[2] / 255] });
    FX.smoke([this.pos[0], this.pos[1] + 0.5, this.pos[2]], T.boss ? 24 : 6, { size: T.boss ? 1.2 : 0.5, life: T.boss ? 3 : 1.6 });
    if (T.boss) {
      FX.ring(this.pos, [1, 0.4, 0.2], 60, 30, 1.2);
      Engine.renderer.flash = 0.75;
      Engine.renderer.flashColor = [1, 0.5, 0.25];
      Game.slowmo(1.6);
    }
    HUD.banner(T.name + ' DOWN', T.boss ? 'the arena shakes' : '', T.boss ? 2600 : 900);
    Game.onEnemyKilled(this, point);
    if (this.node) this.node.visible = true;
  }

  // ---- AI ---------------------------------------------------------------
  update(dt, player, physics, objective) {
    if (!this.alive) {
      if (this.state === 'dying') {
        this.deathTimer -= dt;
        const t = clamp(1 - this.deathTimer / 0.4, 0, 1);
        if (this.node) {
          this.node.setRotation(t * 0.9, this.node.quaternion[1] || 0, t * 0.6);
          this.node.setScale(1 - t * 0.85, 1 - t * 0.85, 1 - t * 0.85);
        }
        if (this.deathTimer <= 0) { Engine.scene.remove(this.node); this.node = null; }
      }
      return;
    }
    const T = this.type;
    this.hitFlash = Math.max(0, this.hitFlash - dt);
    for (const m of this.materials) if (m.emissiveIntensity !== undefined) m.emissiveIntensity = damp(m.emissiveIntensity, 3.2, 6, dt);
    if (this.state === 'spawn') {
      this.spawnTimer -= dt;
      this.syncNode();
      if (this.spawnTimer <= 0) this.state = 'chase';
      return;
    }
    if (this.stagger > 0) { this.stagger -= dt; this.syncNode(); return; }

    // choose target: the player usually, the Crucible if it's closer or the player is dead
    const toPlayer = Vec3.sub([0, 0, 0], player.pos, this.pos);
    const playerDist = Vec3.len(toPlayer);
    const corePos = [CRUCIBLE.CRUCIBLE_POS[0], 0.6, CRUCIBLE.CRUCIBLE_POS[2]];
    const toCore = Vec3.sub([0, 0, 0], corePos, this.pos);
    const coreDist = Vec3.len(toCore);
    const engagePlayer = player.alive && playerDist < coreDist + 8;
    const targetVec = engagePlayer ? toPlayer : toCore;
    const targetDist = engagePlayer ? playerDist : coreDist;
    Vec3.normalize(targetVec, targetVec);

    const speed = T.speed * this.speedMul;
    const attackRange = engagePlayer ? T.attackRange : Math.max(3.4, T.attackRange * 0.6);

    if (targetDist > attackRange) {
      // move toward the target, with a little strafing wobble
      this.wobble += dt * 2.6;
      const strafe = Math.sin(this.wobble) * 0.35;
      const dx = targetVec[0] + -targetVec[2] * strafe;
      const dz = targetVec[2] + targetVec[0] * strafe;
      this.vel[0] = damp(this.vel[0], dx * speed, 6, dt);
      this.vel[2] = damp(this.vel[2], dz * speed, 6, dt);
      // ranged enemies keep their distance
      if (T.ranged && targetDist < T.attackRange * 0.55) { this.vel[0] *= -0.7; this.vel[2] *= -0.7; }
    } else {
      this.vel[0] = damp(this.vel[0], 0, 8, dt);
      this.vel[2] = damp(this.vel[2], 0, 8, dt);
      this.attackTimer -= dt;
      if (this.attackTimer <= 0) {
        this.attackTimer = T.attackCooldown;
        this.attack(engagePlayer, player, corePos);
      }
    }

    // gravity / flight
    if (T.flying) {
      const targetY = World.heightAt(this.pos[0], this.pos[2]) + T.flying + Math.sin(Engine.time * 1.6 + this.wobble) * 0.45;
      this.vel[1] = damp(this.vel[1], (targetY - this.pos[1]) * 3.4, 6, dt);
    } else {
      this.vel[1] += -24 * dt;
      if (this.vel[1] < -40) this.vel[1] = -40;
    }

    const motion = [this.vel[0] * dt, this.vel[1] * dt, this.vel[2] * dt];
    const res = physics.moveCapsule(this.pos, this.radius, this.height, motion, {});
    this.pos[0] = res.position[0]; this.pos[1] = res.position[1]; this.pos[2] = res.position[2];
    if (res.grounded && this.vel[1] < 0) this.vel[1] = 0;
    if (T.flying && res.grounded) this.vel[1] = Math.max(this.vel[1], 2.5);

    // face the target
    this.node.setRotation(0, Math.atan2(targetVec[0], targetVec[2]) + Math.PI, 0);
    this.syncNode();

    // animation
    const t = Engine.time * 8 + this.wobble;
    const moveAmt = clamp(Math.hypot(this.vel[0], this.vel[2]) / Math.max(1, T.speed), 0, 1);
    if (this.parts.legs) {
      for (const L of this.parts.legs) {
        L.pivot.quaternion = Quat.fromEuler(L.pivot.quaternion, Math.sin(t + (L.front > 0 ? Math.PI : 0) + (L.side > 0 ? 0.6 : 0)) * 0.5 * moveAmt, 0, 0);
        L.pivot.markWorldDirty();
      }
    }
    if (this.parts.rings) {
      this.parts.rings[0].setRotation(Engine.time * 1.4, Engine.time * 0.6, 0);
      this.parts.rings[1].setRotation(0, 0, Engine.time * 1.9);
    }
    if (this.parts.eye) {
      const pulse = 2.6 + Math.sin(Engine.time * 9 + this.wobble) * 1.4 + this.hitFlash * 40;
      this.parts.eye.material.emissiveIntensity = pulse;
    }
  }

  attack(engagePlayer, player, corePos) {
    const T = this.type;
    if (T.ranged) {
      const origin = [this.pos[0], this.pos[1] + T.flying + 0.2, this.pos[2]];
      const target = engagePlayer ? [player.pos[0], player.pos[1] + 1.2, player.pos[2]] : corePos;
      const dir = Vec3.normalize([0, 0, 0], Vec3.sub([0, 0, 0], target, origin));
      const spread = 0.03;
      dir[0] += (Math.random() - 0.5) * spread; dir[1] += (Math.random() - 0.5) * spread; dir[2] += (Math.random() - 0.5) * spread;
      Game.spawnProjectile({
        pos: origin, dir: Vec3.normalize(dir, dir), speed: 42, damage: T.damage, radius: 0.34, color: T.accent,
        owner: 'enemy', life: 3.2, splash: T.boss ? 3.2 : 0,
      });
      Engine.audio.laserShot(origin, 0.7);
      return;
    }
    if (engagePlayer) {
      const dist = Vec3.dist(this.pos, player.pos);
      if (dist < T.attackRange + 0.8) {
        player.takeDamage(T.damage, this.pos);
        HUD.log(`<span style="color:#ff8b7a">${T.name}</span> hit you for ${Math.round(T.damage)}`);
      }
      if (T.slam) {
        Game.slam([this.pos[0], this.pos[1], this.pos[2]], T.damage * 0.6, 6.5, this);
        Engine.audio.explosion(this.pos, 1.2);
        FX.ring(this.pos, [1, 0.5, 0.2], 26, 16, 0.5);
      }
    } else {
      Game.damageCrucible(T.damage * (T.boss ? 3.4 : 1.0), this);
      Engine.audio.impact([this.pos[0], this.pos[1] + 1, this.pos[2]], 'metal');
    }
    FX.burst([this.pos[0], this.pos[1] + this.height * 0.6, this.pos[2]], { count: 8, color: [1, 0.4, 0.25], speed: 4, life: 0.3, size: 0.2 });
  }
}

// --- wave director ---------------------------------------------------------
const Waves = {
  wave: 0,
  queue: [],
  spawnTimer: 0,
  betweenWaves: 8,
  state: 'idle',
  active: [],
  totalKilled: 0,
  composition(w) {
    const list = [];
    const crawlers = Math.min(26, 4 + Math.floor(w * 1.9));
    for (let i = 0; i < crawlers; i++) list.push('crawler');
    if (w >= 2) for (let i = 0; i < Math.min(10, Math.floor(w * 0.8)); i++) list.push('sentinel');
    if (w >= 3) for (let i = 0; i < Math.min(8, Math.floor((w - 1) * 0.6)); i++) list.push('brute');
    if (w % 5 === 0) list.push(w % 15 === 0 ? 'prime' : 'warden');
    return list;
  },
  start(w) {
    this.wave = w;
    this.queue = this.composition(w);
    this.spawnTimer = 0;
    this.state = 'spawning';
    const boss = this.queue.includes('warden') || this.queue.includes('prime');
    HUD.banner(`WAVE ${w}`, boss ? 'heavy signature detected' : `${this.queue.length} hostiles inbound`, boss ? 3000 : 2200);
    Engine.audio.alarm(CRUCIBLE.gate.position);
    Engine.music.setIntensity(boss ? 1.0 : Math.min(0.85, 0.3 + w * 0.06));
    if (boss) { Engine.renderer.flash = 0.4; Engine.renderer.flashColor = [1, 0.35, 0.2]; }
    CRUCIBLE.gate.glow.material.opacity = 0.85;
  },
  update(dt, enemies) {
    if (this.state === 'spawning') {
      this.spawnTimer -= dt;
      const perSpawn = Math.max(0.16, 0.75 - this.wave * 0.04);
      if (this.spawnTimer <= 0 && this.queue.length) {
        // spawn in bursts at the gate, spread over the arena edge
        const n = Math.min(this.queue.length, 1 + Math.floor(this.wave / 3));
        for (let i = 0; i < n; i++) {
          const kind = this.queue.shift();
          const a = (Math.random() - 0.5) * 1.5 + Math.PI / 2;
          const r = CRUCIBLE.ARENA_RADIUS + 4;
          const px = Math.cos(a) * r * (0.4 + Math.random() * 0.6);
          const pz = Math.sin(a) * r * (0.6 + Math.random() * 0.6);
          const spawnPos = [px, World.heightAt(px, pz) + 0.4, pz];
          const e = new Enemy(kind, spawnPos);
          enemies.push(e);
          FX.burst([spawnPos[0], spawnPos[1] + 1, spawnPos[2]], { count: 14, color: [1, 0.4, 0.2], speed: 7, life: 0.5, size: 0.3, gravity: 2 });
          Engine.audio.teleport(spawnPos);
        }
        this.spawnTimer = perSpawn;
      }
      if (!this.queue.length) this.state = 'active';
    }
    if (this.state === 'active') {
      const alive = enemies.filter(e => e.alive);
      if (!alive.length) {
        this.state = 'between';
        this.betweenWaves = 9;
        const bonus = 250 + this.wave * 90;
        Game.score += bonus;
        Game.credits += 2 + Math.floor(this.wave / 2);
        HUD.banner(`WAVE ${this.wave} CLEARED`, `+${bonus} pts · +${2 + Math.floor(this.wave / 2)} cores — resupplying`, 3000);
        Game.spawnPickupBatch(this.wave);
        Engine.music.setIntensity(0.18);
        CRUCIBLE.gate.glow.material.opacity = 0.3;
      }
    }
    if (this.state === 'between') {
      this.betweenWaves -= dt;
      if (this.betweenWaves <= 0) this.start(this.wave + 1);
    }
  },
  progress() {
    if (this.state === 'spawning') return `${this.queue.length} inbound`;
    return '';
  },
};

// --- projectiles / grenades -------------------------------------------------
const Projectiles = {
  list: [],
  init(scene) {
    this.scene = scene;
    this.pool = [];
    this.mats = {
      enemy: MaterialLib.get('glow').clone({ name: 'proj_enemy', color: 0xb06cff, emissive: 0xb06cff, emissiveIntensity: 5 }),
      player: MaterialLib.get('glow').clone({ name: 'proj_player', color: 0x66e6ff, emissive: 0x66e6ff, emissiveIntensity: 5 }),
      grenade: MaterialLib.get('metalDark').clone({ name: 'grenade', color: 0x4a5240 }),
    };
    return this;
  },
  spawn(o) {
    let mesh;
    if (o.owner === 'grenade') {
      mesh = new Mesh(Geometry.icosphere(o.radius, 1), this.mats.grenade);
    } else {
      mesh = new Mesh(Geometry.icosphere(o.radius, 2), o.owner === 'player' ? this.mats.player : this.mats.enemy);
      this.scene.add(mesh);
      const light = Ager.light('point', { position: o.pos, color: o.color || [0.7, 0.4, 1.0], intensity: 22, range: 14, name: 'proj_light' });
      o.light = light;
    }
    mesh.tag = 'transient';
    mesh.skipShadow = true;
    if (!mesh.parent) this.scene.add(mesh);
    o.mesh = mesh;
    o.life = o.life || 3.4;
    o.start = Vec3.of(o.pos);
    o.trailTimer = 0;
    this.list.push(o);
    return o;
  },
  update(dt, player, physics, enemies) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i];
      p.life -= dt;
      if (p.life <= 0) { this.explode(p, player, enemies); this.list.splice(i, 1); continue; }
      const step = p.speed * dt;
      const next = [p.pos[0] + p.dir[0] * step, p.pos[1] + p.dir[1] * step, p.pos[2] + p.dir[2] * step];
      let hit = null;
      // vs player
      if (p.owner === 'enemy' && player.alive) {
        const d = Vec3.dist(next, [player.pos[0], player.pos[1] + player.height * 0.5, player.pos[2]]);
        if (d < player.radius + p.radius) hit = { point: next, player: true };
      }
      // vs world
      if (!hit) {
        const r = physics.raycast(p.pos, p.dir, step + p.radius, c => c.tag !== 'prop');
        if (r) hit = { point: r.point, normal: r.normal, world: true };
        else {
          const h = World.heightAt(next[0], next[2]);
          if (next[1] <= h) hit = { point: next, normal: World.normalAt(next[0], next[2]), world: true };
        }
      }
      if (hit) {
        this.explode(p, player, enemies);
        this.list.splice(i, 1);
        continue;
      }
      p.pos[0] = next[0]; p.pos[1] = next[1]; p.pos[2] = next[2];
      p.mesh.setPosition(p.pos[0], p.pos[1], p.pos[2]);
      if (p.light) p.light.setPosition(p.pos[0], p.pos[1], p.pos[2]);
      p.trailTimer -= dt;
      if (p.trailTimer <= 0 && p.owner !== 'grenade') { p.trailTimer = 0.02; FX.trail(p.pos, p.color || [0.8, 0.4, 1.0], p.radius * 3); }
      if (p.owner === 'grenade') {
        p.dir[1] -= 22 * dt;
        if (p.pos[1] < World.heightAt(p.pos[0], p.pos[2]) + p.radius) {
          p.pos[1] = World.heightAt(p.pos[0], p.pos[2]) + p.radius;
          p.dir[1] = Math.abs(p.dir[1]) * 0.4; p.dir[0] *= 0.7; p.dir[2] *= 0.7;
        }
      }
    }
  },
  explode(p, player, enemies) {
    if (p.owner === 'grenade') {
      Game.areaDamage(p.pos, 7.0, 110, null, enemies);
      Engine.audio.explosion(p.pos, 1.1);
      FX.ring(p.pos, [1, 0.7, 0.3], 30, 18, 0.5);
      FX.burst(p.pos, { count: 40, speed: 14, life: 0.6, size: 0.3, color: [1, 0.7, 0.3], gravity: 8 });
      FX.smoke(p.pos, 12, { size: 0.8 });
      Engine.renderer.flash = 0.28;
      Engine.renderer.flashColor = [1, 0.7, 0.35];
      Game.cameraShake(0.5, 16);
    } else {
      FX.burst(p.pos, { count: 10, speed: 6, life: 0.4, size: 0.18, color: p.color || [0.8, 0.4, 1.0] });
      if (p.owner === 'enemy') {
        if (p.splash) {
          Game.areaDamage(p.pos, p.splash, p.damage, null, enemies, true);
        } else if (Vec3.dist(p.pos, [player.pos[0], player.pos[1] + 1, player.pos[2]]) < 1.6 && player.alive) {
          player.takeDamage(p.damage, p.pos);
        }
        Engine.audio.impact(p.pos, 'metal');
      }
    }
    if (p.mesh) Engine.scene.remove(p.mesh);
    if (p.light) Engine.scene.removeLight(p.light);
  },
};

// --- pickups ----------------------------------------------------------------
const Pickups = {
  list: [],
  init(scene) {
    this.scene = scene;
    this.mats = {
      health: MaterialLib.get('glowGreen').clone({ name: 'pick_health', color: 0x6dff9a, emissive: 0x4dff8a }),
      ammo: MaterialLib.get('glowWarm').clone({ name: 'pick_ammo', color: 0xffc46a, emissive: 0xffa63a }),
      shield: MaterialLib.get('glow').clone({ name: 'pick_shield', color: 0x6ad8ff, emissive: 0x4ac8ff }),
    };
    return this;
  },
  spawn(kind, pos) {
    const mat = this.mats[kind] || this.mats.health;
    const mesh = new Mesh(kind === 'ammo' ? Geometry.box(0.34, 0.34, 0.34) : Geometry.octahedron ? Geometry.icosphere(0.24, 1) : Geometry.icosphere(0.24, 1), mat);
    mesh.setPosition(pos[0], pos[1], pos[2]);
    mesh.tag = 'pickup';
    mesh.skipShadow = true;
    this.scene.add(mesh);
    const light = Ager.light('point', { position: [pos[0], pos[1] + 0.2, pos[2]], color: kind === 'health' ? [0.4, 1, 0.6] : (kind === 'ammo' ? [1, 0.7, 0.3] : [0.4, 0.8, 1]), intensity: 8, range: 8, name: 'pick_light' });
    const o = { kind, mesh, light, pos: Vec3.of(pos), life: 34, age: 0, spin: Math.random() * TAU };
    this.list.push(o);
    return o;
  },
  update(dt, player) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i];
      p.age += dt;
      const bobY = Math.sin(p.age * 2.4) * 0.16;
      p.mesh.setPosition(p.pos[0], p.pos[1] + bobY, p.pos[2]);
      p.mesh.setRotation(p.age * 1.1, p.age * 1.8, 0);
      p.light.setPosition(p.pos[0], p.pos[1] + bobY + 0.2, p.pos[2]);
      if (player.alive && Vec3.dist(p.pos, [player.pos[0], player.pos[1] + 0.9, player.pos[2]]) < 2.2) {
        let ok = false;
        if (p.kind === 'health') ok = player.heal(35);
        else if (p.kind === 'shield') { player.addShield(45); ok = true; }
        else { player.addAmmo(0.5); ok = true; }
        Engine.audio.pickup(p.pos, 1);
        FX.burst(p.pos, { count: 12, color: p.kind === 'health' ? [0.4, 1, 0.6] : [1, 0.75, 0.35], speed: 5, life: 0.4, size: 0.15 });
        HUD.log(p.kind === 'health' ? '<b style="color:#7dff9a">+35 HEALTH</b>' : (p.kind === 'shield' ? '<b style="color:#6ad8ff">+45 SHIELD</b>' : '<b style="color:#ffc46a">AMMO RESUPPLY</b>'));
        this.remove(i);
        continue;
      }
      if (p.age > p.life) this.remove(i);
    }
  },
  remove(i) {
    const p = this.list[i];
    Engine.scene.remove(p.mesh);
    Engine.scene.removeLight(p.light);
    this.list.splice(i, 1);
  },
};
