// ===========================================================================
//  AGER · CRUCIBLE  ·  160-audio  ·  ambience beds + adaptive music wiring
// ===========================================================================

const GameAudio = {
  init(audio) {
    this.audio = audio;
    this.started = false;
    this.wind = null;
    this.hum = null;
    this.rumble = null;
    return this;
  },
  start() {
    const a = this.audio;
    if (!a.ready || this.started) return;
    this.started = true;
    const ctx = a.ctx;
    // wind bed
    const wind = ctx.createBufferSource();
    wind.buffer = a._noiseBuffer(4); wind.loop = true;
    const windF = ctx.createBiquadFilter(); windF.type = 'bandpass'; windF.frequency.value = 420; windF.Q.value = 0.7;
    const windG = ctx.createGain(); windG.gain.value = 0.075;
    // slow filter sweep so the wind breathes
    const lfo = ctx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 0.07;
    const lfoG = ctx.createGain(); lfoG.gain.value = 0.045;
    lfo.connect(lfoG); lfoG.connect(windG.gain);
    wind.connect(windF); windF.connect(windG); windG.connect(a.sfx);
    wind.start(); lfo.start();
    this.wind = windG;
    // reactor hum (the Crucible)
    const hum = ctx.createOscillator(); hum.type = 'sawtooth'; hum.frequency.value = 46;
    const hum2 = ctx.createOscillator(); hum2.type = 'sine'; hum2.frequency.value = 92.5;
    const humF = ctx.createBiquadFilter(); humF.type = 'lowpass'; humF.frequency.value = 240; humF.Q.value = 4;
    const humG = ctx.createGain(); humG.gain.value = 0.045;
    const trem = ctx.createOscillator(); trem.type = 'sine'; trem.frequency.value = 3.2;
    const tremG = ctx.createGain(); tremG.gain.value = 0.02;
    trem.connect(tremG); tremG.connect(humG.gain);
    hum.connect(humF); hum2.connect(humF); humF.connect(humG); humG.connect(a.sfx);
    hum.start(); hum2.start(); trem.start();
    this.hum = humG;
    Engine.music.menu = false;
    Engine.music.start();
  },
  setCombatIntensity(v) {
    if (!this.started) return;
    this.audio.musicVolume && 0;
    Engine.music.setIntensity(v);
    if (this.hum) this.hum.gain.value = 0.03 + (1 - v) * 0.03;
    if (this.wind) this.wind.gain.value = 0.05 + (1 - v) * 0.05;
  },
};
