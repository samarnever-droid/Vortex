// ===========================================================================
//  AGER · CRUCIBLE  ·  140-hud  ·  diegetic-ish HUD, kill feed, damage numbers
// ===========================================================================

const HUD = {
  init() {
    const css = `
      #hud{position:fixed;inset:0;pointer-events:none;font-family:ui-monospace,Menlo,Consolas,monospace;
        color:#e8fbff;text-shadow:0 1px 3px rgba(0,0,0,.85);z-index:5;user-select:none}
      #hud .panel{background:linear-gradient(180deg,rgba(6,16,24,.55),rgba(6,16,24,.28));
        border:1px solid rgba(120,220,255,.22);backdrop-filter:blur(3px)}
      #hud .lbl{font-size:9.5px;letter-spacing:.22em;opacity:.6}
      #hud .big{font-size:26px;font-weight:600;letter-spacing:.04em}
      #crosshair{position:absolute;left:50%;top:50%;width:0;height:0}
      #crosshair i{position:absolute;background:#d8fbff;box-shadow:0 0 6px rgba(120,240,255,.9);opacity:.92}
      #hitmark{position:absolute;left:50%;top:50%;width:0;height:0;opacity:0;transition:opacity .08s}
      #hitmark i{position:absolute;width:13px;height:2.4px;background:#ff6a5a;box-shadow:0 0 8px rgba(255,90,60,.9)}
      .dmgNum{position:absolute;font-size:15px;font-weight:700;color:#ffe9a8;text-shadow:0 2px 6px #000;will-change:transform,opacity}
      .enemyBar{position:absolute;width:76px;height:5px;background:rgba(0,0,0,.55);border:1px solid rgba(255,120,90,.6);will-change:transform}
      .enemyBar i{display:block;height:100%;background:linear-gradient(90deg,#ff8a3a,#ff3a2a)}
      #banner{position:absolute;left:50%;top:19%;transform:translateX(-50%);text-align:center;opacity:0;transition:opacity .35s}
      #banner .t{font-size:38px;letter-spacing:.24em;font-weight:700;color:#eafcff}
      #banner .s{font-size:12px;letter-spacing:.3em;opacity:.75;margin-top:6px;text-transform:uppercase}
      .feedLine{margin:2px 0;font-size:11.5px;opacity:.92;text-align:right}
      #log{position:absolute;left:22px;bottom:132px;font-size:11.5px;line-height:1.65;max-width:460px;opacity:.85}
      #log div{opacity:1;transition:opacity .4s}
      #resupply{position:absolute;left:50%;bottom:120px;transform:translateX(-50%);display:none;text-align:center;pointer-events:auto}
      #resupply button{pointer-events:auto;background:rgba(8,20,28,.88);border:1px solid rgba(120,220,255,.4);color:#dff6ff;
        font-family:inherit;font-size:12px;letter-spacing:.1em;padding:9px 14px;margin:0 5px;cursor:pointer;transition:all .15s}
      #resupply button:hover{background:rgba(40,140,180,.5);border-color:#7de3ff;transform:translateY(-1px)}
      #resupply button b{color:#7de3ff}
    `;
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
    const root = document.createElement('div');
    root.id = 'hud';
    root.innerHTML = `
      <div id="crosshair"></div>
      <div id="hitmark"><i style="transform:rotate(45deg) translate(6px,6px)"></i><i style="transform:rotate(45deg) translate(-6px,-6px)"></i>
        <i style="transform:rotate(-45deg) translate(6px,6px)"></i><i style="transform:rotate(-45deg) translate(-6px,-6px)"></i></div>
      <div id="banner"><div class="t"></div><div class="s"></div></div>
      <div id="feed" style="position:absolute;right:20px;top:88px;max-width:340px"></div>
      <div id="log"></div>
      <div id="resupply"></div>
      <div id="obj" class="panel" style="position:absolute;left:50%;top:14px;transform:translateX(-50%);padding:8px 16px;text-align:center;min-width:340px">
        <div class="lbl" style="text-align:center">CRUCIBLE INTEGRITY</div>
        <div style="height:5px;background:rgba(0,0,0,.5);margin:5px 0 6px;position:relative;overflow:hidden">
          <div id="coreBar" style="position:absolute;inset:0;width:100%;background:linear-gradient(90deg,#39e2ff,#7dffd0);transition:width .3s"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:11px;letter-spacing:.12em">
          <span id="waveTxt">WAVE 1</span><span id="enemyTxt">0 HOSTILES</span><span id="scoreTxt">0 PTS</span>
        </div>
      </div>
      <div id="vitals" class="panel" style="position:absolute;left:22px;bottom:24px;padding:10px 14px;width:290px">
        <div style="display:flex;justify-content:space-between;align-items:baseline">
          <span class="lbl">HEALTH</span><span id="hpNum" class="big" style="font-size:20px">100</span>
        </div>
        <div style="height:7px;background:rgba(0,0,0,.55);margin:3px 0 7px;position:relative"><div id="hpBar" style="position:absolute;inset:0;width:100%;background:linear-gradient(90deg,#ff5b4a,#ff9d6a)"></div></div>
        <div style="display:flex;justify-content:space-between;align-items:baseline">
          <span class="lbl">SHIELD</span><span id="shNum" class="big" style="font-size:20px">100</span>
        </div>
        <div style="height:7px;background:rgba(0,0,0,.55);margin:3px 0 2px;position:relative"><div id="shBar" style="position:absolute;inset:0;width:100%;background:linear-gradient(90deg,#4ac8ff,#9be8ff)"></div></div>
      </div>
      <div id="weapon" class="panel" style="position:absolute;right:22px;bottom:24px;padding:10px 14px;min-width:250px;text-align:right">
        <div class="lbl" id="wName">PLASMA LANCE</div>
        <div class="big" id="wAmmo" style="font-size:30px">100<span style="font-size:14px;opacity:.6"> / 600</span></div>
        <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:6px;font-size:11px;letter-spacing:.1em">
          <span id="novaTxt">NOVA READY</span><span id="nadeTxt">GRENADES 4</span>
        </div>
      </div>
      <div id="dash" style="position:absolute;left:50%;bottom:44px;transform:translateX(-50%);height:3px;width:120px;background:rgba(255,255,255,.14)">
        <div id="dashBar" style="height:100%;width:100%;background:#8fe6ff"></div>
      </div>`;
    document.body.appendChild(root);
    this.root = root;
    this.el = {
      crosshair: root.querySelector('#crosshair'), hitmark: root.querySelector('#hitmark'),
      banner: root.querySelector('#banner'), bannerT: root.querySelector('#banner .t'), bannerS: root.querySelector('#banner .s'),
      feed: root.querySelector('#feed'), log: root.querySelector('#log'), resupply: root.querySelector('#resupply'),
      hpBar: root.querySelector('#hpBar'), hpNum: root.querySelector('#hpNum'), shBar: root.querySelector('#shBar'), shNum: root.querySelector('#shNum'),
      coreBar: root.querySelector('#coreBar'), waveTxt: root.querySelector('#waveTxt'), enemyTxt: root.querySelector('#enemyTxt'),
      scoreTxt: root.querySelector('#scoreTxt'), wName: root.querySelector('#wName'), wAmmo: root.querySelector('#wAmmo'),
      novaTxt: root.querySelector('#novaTxt'), nadeTxt: root.querySelector('#nadeTxt'), dashBar: root.querySelector('#dashBar'),
    };
    // dynamic crosshair: four ticks that spread with weapon state
    this.cross = [];
    for (let i = 0; i < 4; i++) {
      const t = document.createElement('i');
      const h = i % 2 === 0 ? 9 : 2.4, w = i % 2 === 0 ? 2.4 : 9;
      t.style.width = w + 'px'; t.style.height = h + 'px';
      this.el.crosshair.appendChild(t);
      this.cross.push({ el: t, dir: i });
    }
    this.damageNums = [];
    this.poolDmg = [];
    this.bars = [];
    this.feedLines = [];
    this.logLines = [];
    this.bannerTimer = 0;
    this.flashEl = document.createElement('div');
    this.flashEl.style.cssText = 'position:fixed;inset:0;pointer-events:none;opacity:0;z-index:6;background:radial-gradient(circle at 50% 55%, transparent 30%, rgba(255,30,20,.75) 120%)';
    document.body.appendChild(this.flashEl);
    this.dirEl = document.createElement('div');
    this.dirEl.style.cssText = 'position:fixed;inset:0;pointer-events:none;opacity:0;z-index:6';
    this.dirEl.innerHTML = '<div style="position:absolute;left:50%;top:50%;width:340px;height:340px;margin:-170px 0 0 -170px;border-radius:50%;background:conic-gradient(from -30deg, rgba(255,60,40,.55), transparent 40%, transparent 320deg, rgba(255,60,40,.55))"></div>';
    document.body.appendChild(this.dirEl);
    this.hitTimer = 0;
    return this;
  },

  // --- static feedback ----------------------------------------------------
  banner(title, sub = '', ms = 2200) {
    this.el.bannerT.textContent = title;
    this.el.bannerS.textContent = sub;
    this.el.banner.style.opacity = '1';
    this.bannerTimer = ms / 1000;
  },
  log(html) {
    const d = document.createElement('div');
    d.innerHTML = html;
    this.el.log.appendChild(d);
    this.logLines.push(d);
    while (this.logLines.length > 6) { const o = this.logLines.shift(); o.remove(); }
    setTimeout(() => { d.style.opacity = '0'; }, 5200);
    setTimeout(() => d.remove(), 6000);
  },
  feed(html, color = '#ffd7a8') {
    const d = document.createElement('div');
    d.className = 'feedLine';
    d.style.color = color;
    d.innerHTML = html;
    this.el.feed.appendChild(d);
    while (this.el.feed.childNodes.length > 6) this.el.feed.removeChild(this.el.feed.firstChild);
    setTimeout(() => d.remove(), 6000);
  },
  damageFlash(amount) {
    this.flashEl.style.opacity = String(Math.min(0.85, amount));
    clearTimeout(this._flashT);
    this._flashT = setTimeout(() => { this.flashEl.style.opacity = '0'; }, 130);
  },
  damageDirection(fromPos) {
    const cam = Engine.camera;
    const p = cam.getWorldPosition([0, 0, 0]);
    const fwd = cam.getForward([0, 0, 0]);
    const to = Vec3.normalize([0, 0, 0], [fromPos[0] - p[0], 0, fromPos[2] - p[2]]);
    const f2 = Vec3.normalize([0, 0, 0], [fwd[0], 0, fwd[2]]);
    const ang = Math.atan2(to[0] * f2[2] - to[2] * f2[0], to[0] * f2[0] + to[2] * f2[2]);
    this.dirEl.style.transform = `rotate(${(-ang * RAD).toFixed(1)}deg)`;
    this.dirEl.style.opacity = '0.8';
    clearTimeout(this._dirT);
    this._dirT = setTimeout(() => { this.dirEl.style.opacity = '0'; }, 220);
  },
  hitmarker(kill = false, head = false) {
    const h = this.el.hitmark;
    h.style.opacity = '1';
    h.style.transform = `translate(${Math.random() * 4 - 2}px, ${Math.random() * 4 - 2}px) scale(${kill ? 1.5 : 1})`;
    for (const i of h.children) i.style.background = head ? '#ffd45a' : (kill ? '#ff4a3a' : '#ffffff');
    this.hitTimer = 0.12;
  },
  damageNumber(worldPos, amount, head = false) {
    let d = this.poolDmg.find(x => x.dead);
    if (!d) {
      const el = document.createElement('div');
      el.className = 'dmgNum';
      document.body.appendChild(el);
      d = { el, dead: true, life: 0, pos: [0, 0, 0], vel: [0, 0] };
      this.poolDmg.push(d);
    }
    d.dead = false; d.life = 1.0;
    d.pos = [worldPos[0] + (Math.random() - .5) * .5, worldPos[1] + (Math.random() - .5) * .5 + 0.2, worldPos[2]];
    d.vel = [(Math.random() - 0.5) * 40, -60 - Math.random() * 40];
    d.el.textContent = (head ? '✦' : '') + Math.round(amount);
    d.el.style.color = head ? '#ffd45a' : '#ffe9a8';
    d.el.style.fontSize = head ? '19px' : '15px';
    d.el.style.opacity = '1';
    this.damageNums.push(d);
  },

  // --- per frame ----------------------------------------------------------
  update(dt, game) {
    const p = Player;
    // crosshair spread
    const speed = Math.hypot(p.vel[0], p.vel[2]);
    const spread = 6 + speed * 0.9 + p.recoil * 9 + (p.sprinting ? 6 : 0);
    for (const c of this.cross) {
      const d = spread;
      const x = c.dir === 0 ? 0 : (c.dir === 2 ? 0 : (c.dir === 1 ? d : -d));
      const y = c.dir === 0 ? -d : (c.dir === 2 ? d : 0);
      c.el.style.transform = `translate(${x}px, ${y}px)`;
    }
    if (this.hitTimer > 0) { this.hitTimer -= dt; if (this.hitTimer <= 0) this.el.hitmark.style.opacity = '0'; }

    // vitals
    this.el.hpBar.style.width = (p.health / p.maxHealth * 100) + '%';
    this.el.shNum.textContent = Math.round(p.shield);
    this.el.shBar.style.width = (p.shield / p.maxShield * 100) + '%';
    this.el.hpNum.textContent = Math.round(p.health);
    this.el.hpNum.style.color = p.health < 30 ? '#ff6a5a' : '#e8fbff';
    this.el.coreBar.style.width = clamp(game.coreHealth / game.coreMax, 0, 1) * 100 + '%';
    this.el.coreBar.style.background = game.coreHealth / game.coreMax < 0.34
      ? 'linear-gradient(90deg,#ff4a3a,#ffa04a)' : 'linear-gradient(90deg,#39e2ff,#7dffd0)';
    this.el.waveTxt.textContent = 'WAVE ' + Waves.wave + (Waves.state === 'between' ? ` · NEXT ${Math.ceil(Waves.betweenWaves)}s` : '');
    this.el.enemyTxt.textContent = game.enemyCount + ' HOSTILES' + (Waves.progress() ? ' · ' + Waves.progress() : '');
    this.el.scoreTxt.textContent = game.score.toLocaleString() + ' PTS';
    const w = p.wstate, def = p.weapon;
    this.el.wName.textContent = def.name + (w.reloading > 0 ? '  · RELOADING' : '');
    this.el.wAmmo.innerHTML = `${w.ammo}<span style="font-size:14px;opacity:.6"> / ${w.reserve}</span>`;
    this.el.wAmmo.style.color = w.ammo === 0 ? '#ff6a5a' : (w.ammo < def.mag * 0.25 ? '#ffc46a' : '#e8fbff');
    this.el.novaTxt.textContent = p.novaCooldown > 0 ? `NOVA ${p.novaCooldown.toFixed(1)}s` : 'NOVA READY';
    this.el.novaTxt.style.color = p.novaCooldown > 0 ? 'rgba(230,250,255,.45)' : '#7de3ff';
    this.el.nadeTxt.textContent = 'GRENADES ' + p.grenades;
    this.el.dashBar.style.width = (100 - clamp(p.dashCooldownEff / 2.6, 0, 1) * 100) + '%';
    this.el.dashBar.style.background = p.dashCooldownEff <= 0 ? '#8fe6ff' : 'rgba(143,230,255,.35)';

    // banner fade
    if (this.bannerTimer > 0) {
      this.bannerTimer -= dt;
      if (this.bannerTimer <= 0) this.el.banner.style.opacity = '0';
    }

    // damage numbers
    const cam = Engine.camera;
    const vp = cam.viewProjection;
    for (const d of this.damageNums) {
      d.life -= dt * 1.5;
      const t = 1 - d.life;
      d.pos[1] += dt * 1.2;
      const w = vp[3] * d.pos[0] + vp[7] * d.pos[1] + vp[11] * d.pos[2] + vp[15];
      if (w <= 0.01 || d.life <= 0) { d.el.style.opacity = '0'; if (d.life <= 0) d.dead = true; continue; }
      const cx = (vp[0] * d.pos[0] + vp[4] * d.pos[1] + vp[8] * d.pos[2] + vp[12]) / w;
      const cy = (vp[1] * d.pos[0] + vp[5] * d.pos[1] + vp[9] * d.pos[2] + vp[13]) / w;
      const sx = (cx * 0.5 + 0.5) * innerWidth, sy = (-cy * 0.5 + 0.5) * innerHeight;
      d.el.style.transform = `translate(${sx.toFixed(1)}px, ${(sy - (1 - d.life) * 26).toFixed(1)}px) translate(-50%,-50%)`;
      d.el.style.opacity = String(clamp(d.life * 1.6, 0, 1));
    }
    this.damageNums = this.damageNums.filter(d => !d.dead);

    // enemy health bars (only for damaged / nearby / boss enemies)
    const list = game.enemies.filter(e => e.alive);
    while (this.bars.length < list.length) {
      const el = document.createElement('div');
      el.className = 'enemyBar';
      el.innerHTML = '<i></i>';
      document.body.appendChild(el);
      this.bars.push({ el, fill: el.querySelector('i') });
    }
    for (let i = 0; i < this.bars.length; i++) {
      const b = this.bars[i], e = list[i];
      if (!e || !e.alive) { b.el.style.display = 'none'; continue; }
      const wp = e.hitPosition([0, 0, 0]);
      wp[1] += e.height * 0.35;
      const w = vp[3] * wp[0] + vp[7] * wp[1] + vp[11] * wp[2] + vp[15];
      const dist = Vec3.dist(wp, cam.getWorldPosition([0, 0, 0]));
      const show = w > 0.01 && dist < 90 && (e.health < e.maxHealth || e.type.boss || dist < 34);
      if (!show) { b.el.style.display = 'none'; continue; }
      const cx = (vp[0] * wp[0] + vp[4] * wp[1] + vp[8] * wp[2] + vp[12]) / w;
      const cy = (vp[1] * wp[0] + vp[5] * wp[1] + vp[9] * wp[2] + vp[13]) / w;
      b.el.style.display = 'block';
      const scale = e.type.boss ? 1.9 : 1;
      b.el.style.width = (76 * scale) + 'px';
      b.el.style.transform = `translate(${((cx * 0.5 + 0.5) * innerWidth - 38 * scale).toFixed(1)}px, ${((-cy * 0.5 + 0.5) * innerHeight).toFixed(1)}px)`;
      b.fill.style.width = clamp(e.health / e.maxHealth, 0, 1) * 100 + '%';
      b.fill.style.background = e.type.boss ? 'linear-gradient(90deg,#ff2a4a,#ffd24a)' : 'linear-gradient(90deg,#ff8a3a,#ff3a2a)';
    }
  },

  resupply(show, options) {
    const el = this.el.resupply;
    if (!show) { el.style.display = 'none'; return; }
    el.style.display = 'block';
    el.innerHTML = `<div class="lbl" style="margin-bottom:7px">RESUPPLY — SPEND CORES (${Game.credits})</div>` +
      options.map((o, i) => `<button data-i="${i}"><b>${i + 7}</b> ${o.label}<div style="font-size:10px;opacity:.65;margin-top:2px">${o.cost} cores</div></button>`).join('');
    for (const b of el.querySelectorAll('button')) {
      b.onclick = () => Game.buyUpgrade(parseInt(b.dataset.i, 10));
    }
  },
};
