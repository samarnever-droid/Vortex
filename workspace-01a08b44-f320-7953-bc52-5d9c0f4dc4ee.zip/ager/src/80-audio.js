// ===========================================================================
//  AGER ENGINE  ·  80-audio  ·  procedural audio synthesiser + adaptive music
//  No audio files. Every gunshot, footstep and chord is generated live.
// ===========================================================================

class AudioEngine {
  constructor() {
    this.ctx = null;
    this.ready = false;
    this.muted = false;
    this.volume = 0.85;
    this.musicVolume = 0.42;
    this.listener = { position: [0, 0, 0], forward: [0, 0, -1], up: [0, 1, 0] };
    this._noise = new Map();
    this.intensity = 0;      // 0..1 drives the music arrangement
    this.lastPlay = new Map();
  }
  init() {
    if (this.ready) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC({ latencyHint: 'interactive' });
    const ctx = this.ctx;
    this.master = ctx.createGain(); this.master.gain.value = this.volume;
    this.limiter = ctx.createDynamicsCompressor();
    this.limiter.threshold.value = -8; this.limiter.knee.value = 6; this.limiter.ratio.value = 12;
    this.limiter.attack.value = 0.003; this.limiter.release.value = 0.18;
    this.master.connect(this.limiter); this.limiter.connect(ctx.destination);
    this.sfx = ctx.createGain(); this.sfx.gain.value = 1.0; this.sfx.connect(this.master);
    this.music = ctx.createGain(); this.music.gain.value = this.musicVolume; this.music.connect(this.master);
    // procedural plate/room reverb
    this.reverb = ctx.createConvolver();
    this.reverb.buffer = this._makeIR(2.6, 2.2);
    this.reverbGain = ctx.createGain(); this.reverbGain.gain.value = 0.32;
    this.reverb.connect(this.reverbGain); this.reverbGain.connect(this.master);
    // subtle master EQ shaping
    const shelf = ctx.createBiquadFilter();
    shelf.type = 'highshelf'; shelf.frequency.value = 5200; shelf.gain.value = -2.0;
    this.master.disconnect(); this.master.connect(shelf); shelf.connect(this.limiter);
    this.ready = true;
    if (this.musicStart) this.musicStart();
  }
  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }
  _makeIR(seconds = 2, decay = 2) {
    const ctx = this.ctx;
    const rate = ctx.sampleRate, len = Math.floor(rate * seconds);
    const buf = ctx.createBuffer(2, len, rate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) {
        const t = i / len;
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, decay) * (1 - Math.exp(-i / (rate * 0.01)));
      }
    }
    return buf;
  }
  _noiseBuffer(seconds = 1) {
    const key = 'n' + seconds;
    if (this._noise.has(key)) return this._noise.get(key);
    const ctx = this.ctx;
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this._noise.set(key, buf);
    return buf;
  }
  _now() { return this.ctx ? this.ctx.currentTime : 0; }
  // grab a mono/stereo output node placed in 3D (if a position is given)
  _out(position, volume = 1, sendReverb = 0.3) {
    const ctx = this.ctx;
    const g = ctx.createGain(); g.gain.value = volume;
    let node = g;
    if (position) {
      const pan = ctx.createPanner ? ctx.createPanner() : null;
      if (pan) {
        pan.panningModel = 'HRTF';
        pan.distanceModel = 'inverse';
        pan.refDistance = 6; pan.maxDistance = 240; pan.rolloffFactor = 1.1;
        if (pan.positionX) { pan.positionX.value = position[0]; pan.positionY.value = position[1]; pan.positionZ.value = position[2]; }
        else pan.setPosition(position[0], position[1], position[2]);
        g.connect(pan); pan.connect(this.sfx);
        if (sendReverb > 0) { const s = ctx.createGain(); s.gain.value = sendReverb; pan.connect(s); s.connect(this.reverb); }
        return g;
      }
    }
    g.connect(this.sfx);
    if (sendReverb > 0) { const s = ctx.createGain(); s.gain.value = sendReverb; g.connect(s); s.connect(this.reverb); }
    return g;
  }
  _env(gainNode, t0, attack, decay, peak, sustain = 0) {
    const g = gainNode.gain;
    g.cancelScheduledValues(t0);
    g.setValueAtTime(0.0001, t0);
    g.exponentialRampToValueAtTime(Math.max(0.0002, peak), t0 + attack);
    g.exponentialRampToValueAtTime(Math.max(0.0001, sustain || 0.0001), t0 + attack + decay);
    return gainNode;
  }
  _noiseSource(seconds = 0.4) {
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(seconds);
    src.loop = true;
    return src;
  }
  // --- weapons ------------------------------------------------------------
  plasmaShot(position, pitch = 1) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.5, 0.5);
    // body: saw down-sweep
    const o = ctx.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(680 * pitch, t);
    o.frequency.exponentialRampToValueAtTime(90 * pitch, t + 0.16);
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(1700, t); bp.frequency.exponentialRampToValueAtTime(320, t + 0.18);
    const g = this._env(ctx.createGain(), t, 0.004, 0.18, 0.85);
    o.connect(bp); bp.connect(g); g.connect(out); o.start(t); o.stop(t + 0.3);
    // noise crack
    const n = this._noiseSource(0.2);
    const nf = ctx.createBiquadFilter(); nf.type = 'highpass'; nf.frequency.value = 900;
    const ng = this._env(ctx.createGain(), t, 0.001, 0.1, 0.5);
    n.connect(nf); nf.connect(ng); ng.connect(out); n.start(t); n.stop(t + 0.2);
    // sub thump
    const so = ctx.createOscillator(); so.type = 'sine';
    so.frequency.setValueAtTime(150, t); so.frequency.exponentialRampToValueAtTime(42, t + 0.12);
    const sg = this._env(ctx.createGain(), t, 0.002, 0.14, 0.55);
    so.connect(sg); sg.connect(out); so.start(t); so.stop(t + 0.2);
  }
  laserShot(position, pitch = 1) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.35, 0.4);
    const o = ctx.createOscillator(); o.type = 'square';
    o.frequency.setValueAtTime(1400 * pitch, t);
    o.frequency.exponentialRampToValueAtTime(180 * pitch, t + 0.22);
    const g = this._env(ctx.createGain(), t, 0.003, 0.22, 0.35);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2600;
    o.connect(lp); lp.connect(g); g.connect(out); o.start(t); o.stop(t + 0.3);
  }
  impact(position, surface = 'concrete') {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.3, 0.4);
    const n = this._noiseSource(0.14);
    const f = ctx.createBiquadFilter();
    if (surface === 'metal') { f.type = 'bandpass'; f.frequency.value = 2400; f.Q.value = 6; }
    else if (surface === 'flesh') { f.type = 'lowpass'; f.frequency.value = 700; }
    else { f.type = 'bandpass'; f.frequency.value = 1400; f.Q.value = 1.6; }
    const g = this._env(ctx.createGain(), t, 0.001, surface === 'metal' ? 0.28 : 0.09, 0.35);
    n.connect(f); f.connect(g); g.connect(out); n.start(t); n.stop(t + 0.3);
    if (surface === 'metal') {
      const r = ctx.createOscillator(); r.type = 'triangle';
      r.frequency.setValueAtTime(1800 + Math.random() * 900, t);
      const rg = this._env(ctx.createGain(), t, 0.002, 0.4, 0.12);
      r.connect(rg); rg.connect(out); r.start(t); r.stop(t + 0.5);
    }
  }
  explosion(position, size = 1) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.7 * Math.min(2, size), 0.7);
    const n = this._noiseSource(1.2);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass';
    lp.frequency.setValueAtTime(1800, t); lp.frequency.exponentialRampToValueAtTime(140, t + 0.6 * size);
    const g = this._env(ctx.createGain(), t, 0.005, 0.75 * size, 0.9);
    n.connect(lp); lp.connect(g); g.connect(out); n.start(t); n.stop(t + 1.4 * size);
    const so = ctx.createOscillator(); so.type = 'sine';
    so.frequency.setValueAtTime(120 * (1 / size), t); so.frequency.exponentialRampToValueAtTime(28, t + 0.5 * size);
    const sg = this._env(ctx.createGain(), t, 0.006, 0.6 * size, 0.8);
    so.connect(sg); sg.connect(out); so.start(t); so.stop(t + 1.2 * size);
  }
  nova(position) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.85, 0.85);
    // rising sweep then blast
    const o = ctx.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(80, t); o.frequency.exponentialRampToValueAtTime(2200, t + 0.28);
    o.frequency.exponentialRampToValueAtTime(60, t + 0.9);
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 0.9;
    bp.frequency.setValueAtTime(300, t); bp.frequency.exponentialRampToValueAtTime(3200, t + 0.3);
    bp.frequency.exponentialRampToValueAtTime(200, t + 0.9);
    const g = this._env(ctx.createGain(), t, 0.02, 0.9, 0.75);
    o.connect(bp); bp.connect(g); g.connect(out); o.start(t); o.stop(t + 1.1);
    const n = this._noiseSource(1.0);
    const nf = ctx.createBiquadFilter(); nf.type = 'highpass'; nf.frequency.value = 300;
    const ng = this._env(ctx.createGain(), t + 0.24, 0.008, 0.7, 0.6);
    n.connect(nf); nf.connect(ng); ng.connect(out); n.start(t + 0.24); n.stop(t + 1.2);
    const sub = ctx.createOscillator(); sub.type = 'sine';
    sub.frequency.setValueAtTime(180, t + 0.26); sub.frequency.exponentialRampToValueAtTime(24, t + 1.0);
    const sg = this._env(ctx.createGain(), t + 0.26, 0.01, 0.8, 0.9);
    sub.connect(sg); sg.connect(out); sub.start(t + 0.26); sub.stop(t + 1.2);
  }
  hurt() {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(null, 0.35, 0.2);
    const o = ctx.createOscillator(); o.type = 'triangle';
    o.frequency.setValueAtTime(320, t); o.frequency.exponentialRampToValueAtTime(160, t + 0.18);
    const g = this._env(ctx.createGain(), t, 0.004, 0.3, 0.5);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.4);
    const n = this._noiseSource(0.2);
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 700; f.Q.value = 1.2;
    const ng = this._env(ctx.createGain(), t, 0.001, 0.12, 0.25);
    n.connect(f); f.connect(ng); ng.connect(out); n.start(t); n.stop(t + 0.2);
  }
  hitMarker(headshot = false) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(null, 0.3, 0.15);
    const o = ctx.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(headshot ? 2400 : 1500, t);
    o.frequency.exponentialRampToValueAtTime(headshot ? 3600 : 2100, t + 0.06);
    const g = this._env(ctx.createGain(), t, 0.001, 0.09, 0.4);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.12);
  }
  kill() {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(null, 0.4, 0.4);
    [520, 780, 1170].forEach((f, i) => {
      const o = ctx.createOscillator(); o.type = 'triangle';
      o.frequency.setValueAtTime(f, t + i * 0.05);
      const g = this._env(ctx.createGain(), t + i * 0.05, 0.004, 0.4, 0.25);
      o.connect(g); g.connect(out); o.start(t + i * 0.05); o.stop(t + i * 0.05 + 0.5);
    });
  }
  footstep(position, speed = 1, surface = 'metal') {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.22, 0.25);
    const n = this._noiseSource(0.12);
    const f = ctx.createBiquadFilter();
    if (surface === 'metal') { f.type = 'bandpass'; f.frequency.value = 1500 + Math.random() * 600; f.Q.value = 2.2; }
    else { f.type = 'lowpass'; f.frequency.value = 900 + Math.random() * 400; }
    const g = this._env(ctx.createGain(), t, 0.001, 0.07 / speed, 0.3);
    n.connect(f); f.connect(g); g.connect(out); n.start(t); n.stop(t + 0.15);
  }
  jump(position) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.2, 0.2);
    const o = ctx.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(220, t); o.frequency.exponentialRampToValueAtTime(420, t + 0.12);
    const g = this._env(ctx.createGain(), t, 0.003, 0.12, 0.22);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.2);
  }
  land(position, force = 1) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.3 * Math.min(1.6, force), 0.3);
    const n = this._noiseSource(0.22);
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 500;
    const g = this._env(ctx.createGain(), t, 0.002, 0.2, 0.4);
    n.connect(f); f.connect(g); g.connect(out); n.start(t); n.stop(t + 0.3);
  }
  pickup(position, pitch = 1) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.3, 0.35);
    [660, 990, 1320].forEach((f, i) => {
      const o = ctx.createOscillator(); o.type = 'sine';
      o.frequency.setValueAtTime(f * pitch, t + i * 0.06);
      const g = this._env(ctx.createGain(), t + i * 0.06, 0.003, 0.25, 0.2);
      o.connect(g); g.connect(out); o.start(t + i * 0.06); o.stop(t + i * 0.06 + 0.35);
    });
  }
  uiClick(up = false) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(null, 0.25, 0.1);
    const o = ctx.createOscillator(); o.type = 'square';
    o.frequency.setValueAtTime(up ? 900 : 520, t);
    const g = this._env(ctx.createGain(), t, 0.001, 0.07, 0.16);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.1);
  }
  alarm(position) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.3, 0.6);
    for (let i = 0; i < 2; i++) {
      const o = ctx.createOscillator(); o.type = 'sawtooth';
      o.frequency.setValueAtTime(180, t + i * 0.42);
      o.frequency.exponentialRampToValueAtTime(560, t + i * 0.42 + 0.22);
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1400;
      const g = this._env(ctx.createGain(), t + i * 0.42, 0.02, 0.34, 0.22);
      o.connect(lp); lp.connect(g); g.connect(out); o.start(t + i * 0.42); o.stop(t + i * 0.42 + 0.42);
    }
  }
  teleport(position) {
    if (!this.ready) return;
    const ctx = this.ctx, t = this._now();
    const out = this._out(position, 0.3, 0.6);
    const n = this._noiseSource(0.5);
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 3;
    f.frequency.setValueAtTime(300, t); f.frequency.exponentialRampToValueAtTime(4200, t + 0.3);
    const g = this._env(ctx.createGain(), t, 0.01, 0.4, 0.3);
    n.connect(f); f.connect(g); g.connect(out); n.start(t); n.stop(t + 0.6);
  }
  updateListener(camera) {
    if (!this.ready || !this.ctx.listener) return;
    const l = this.ctx.listener;
    const p = camera.getWorldPosition([0, 0, 0]);
    const f = camera.getForward([0, 0, 0]);
    if (l.positionX) {
      l.positionX.value = p[0]; l.positionY.value = p[1]; l.positionZ.value = p[2];
      l.forwardX.value = f[0]; l.forwardY.value = f[1]; l.forwardZ.value = f[2];
      l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0;
    } else if (l.setPosition) {
      l.setPosition(p[0], p[1], p[2]);
      l.setOrientation(f[0], f[1], f[2], 0, 1, 0);
    }
  }
}

// --- adaptive generative score ---------------------------------------------
class MusicDirector {
  constructor(audio) {
    this.audio = audio;
    this.playing = false;
    this.intensity = 0;
    this.targetIntensity = 0;
    this.bpm = 84;
    this.step = 0;
    this.nextTime = 0;
    this.menu = false;
    this.key = 0; // transposition
  }
  start() {
    if (!this.audio.ready || this.playing) return;
    this.playing = true;
    this.nextTime = this.audio.ctx.currentTime + 0.1;
    this._loop();
  }
  setIntensity(v) { this.targetIntensity = clamp(v, 0, 1); }
  _loop() {
    if (!this.playing) return;
    const ctx = this.audio.ctx;
    const ahead = 0.25;
    while (this.nextTime < ctx.currentTime + ahead) {
      this._schedule(this.nextTime);
      const spb = 60 / this.bpm / 4; // 16th notes
      this.nextTime += spb;
      this.step = (this.step + 1) % 64;
    }
    setTimeout(() => this._loop(), 60);
  }
  _schedule(t) {
    const a = this.audio;
    this.intensity = damp(this.intensity, this.targetIntensity, 2.0, 0.06);
    const I = this.intensity;
    const s = this.step;
    const out = a.music;
    const scale = [0, 3, 5, 7, 10];           // minor pentatonic
    const root = 55 * Math.pow(2, this.key / 12);
    // pad on bar boundaries
    if (s % 16 === 0) {
      const chord = this.menu ? [0, 7, 12, 15] : [0, 3, 7, 10 + (s >= 32 ? 3 : 0)];
      chord.forEach((semi, i) => {
        const o = ctx_createOsc(a, 'sawtooth', root * 2 * Math.pow(2, semi / 12), t, 4.2);
        const f = a.ctx.createBiquadFilter(); f.type = 'lowpass';
        f.frequency.setValueAtTime(320 + I * 900, t);
        f.Q.value = 3 + I * 4;
        const g = a.ctx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.05 + I * 0.05, t + 0.8);
        g.gain.linearRampToValueAtTime(0.0001, t + 4.2);
        o.connect(f); f.connect(g); g.connect(out);
        o.start(t); o.stop(t + 4.4);
      });
    }
    // bass pulse
    if (s % 4 === 0 && I > 0.12) {
      const note = scale[(s / 4) % scale.length];
      const o = ctx_createOsc(a, 'square', root * Math.pow(2, note / 12), t, 0.32);
      const f = a.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 180 + I * 400; f.Q.value = 6;
      const g = a.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.09 + I * 0.06, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
      o.connect(f); f.connect(g); g.connect(out); o.start(t); o.stop(t + 0.35);
    }
    // kick
    if ((s % 8 === 0 || (I > 0.6 && s % 8 === 6))) {
      const o = ctx_createOsc(a, 'sine', 140, t, 0.2);
      o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(44, t + 0.12);
      const g = a.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.22 + I * 0.15, t + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
      o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.25);
    }
    // hats
    if (I > 0.25 && s % 2 === 1) {
      const n = a._noiseSource(0.06);
      const f = a.ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 6500;
      const g = a.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.03 + I * 0.05, t + 0.002);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
      n.connect(f); f.connect(g); g.connect(out); n.start(t); n.stop(t + 0.08);
    }
    // arp lead in combat
    if (I > 0.55 && s % 4 === 2) {
      const note = scale[(s * 3) % scale.length] + 24;
      const o = ctx_createOsc(a, 'triangle', root * Math.pow(2, note / 12), t, 0.3);
      const g = a.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.035 + I * 0.03, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
      o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.32);
    }
  }
}
function ctx_createOsc(audio, type, freq, t, dur) {
  const o = audio.ctx.createOscillator();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  return o;
}
