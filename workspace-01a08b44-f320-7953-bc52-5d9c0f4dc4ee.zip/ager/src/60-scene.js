// ===========================================================================
//  AGER ENGINE  ·  60-scene  ·  scene graph, nodes, camera, lights, culling
// ===========================================================================

class Node {
  constructor(name = 'node') {
    this.name = name;
    this.position = Vec3.create(0, 0, 0);
    this.quaternion = Quat.create();
    this.scale = Vec3.create(1, 1, 1);
    this.parent = null;
    this.children = [];
    this.worldMatrix = Mat4.create();
    this.visible = true;
    this._worldDirty = true;
    this._selfDirty = true;
    this.userData = {};
    this.tag = '';
  }
  add(child) {
    child.parent = this;
    this.children.push(child);
    child.markWorldDirty();
    return child;
  }
  remove(child) {
    const i = this.children.indexOf(child);
    if (i >= 0) { this.children.splice(i, 1); child.parent = null; }
    return this;
  }
  removeAll() { for (const c of this.children.slice()) this.remove(c); return this; }
  markWorldDirty() {
    this._worldDirty = true;
    for (const c of this.children) c.markWorldDirty();
  }
  setPosition(x, y, z) { Vec3.set(this.position, x, y, z); this._selfDirty = true; this.markWorldDirty(); return this; }
  setScale(x, y = x, z = x) { Vec3.set(this.scale, x, y, z); this._selfDirty = true; this.markWorldDirty(); return this; }
  setRotation(x, y, z) { Quat.fromEuler(this.quaternion, x, y, z); this._selfDirty = true; this.markWorldDirty(); return this; }
  setQuaternion(q) { Quat.copy ? Quat.copy(this.quaternion, q) : this.quaternion.set(q); this._selfDirty = true; this.markWorldDirty(); return this; }
  lookAt(target, up = [0, 1, 0]) {
    // use an up-to-date world position even if the matrix hasn't been rebuilt
    let p;
    if (this._selfDirty || this._worldDirty) {
      const m = Mat4.fromTRS(_lookAtTmp, this.position, this.quaternion, this.scale);
      if (this.parent) Mat4.mul(m, this.parent.worldMatrix, m);
      p = [m[12], m[13], m[14]];
    } else p = this.getWorldPosition([0, 0, 0]);
    const fwd = Vec3.normalize([0, 0, 0], [target[0] - p[0], target[1] - p[1], target[2] - p[2]]);
    Quat.lookRotation(this.quaternion, fwd, up);
    this._selfDirty = true; this.markWorldDirty();
    if (!this.parent) this.updateWorldMatrix();
    return this;
  }
  getWorldPosition(out = [0, 0, 0]) { out[0] = this.worldMatrix[12]; out[1] = this.worldMatrix[13]; out[2] = this.worldMatrix[14]; return out; }
  getForward(out = [0, 0, 0]) {
    out[0] = -this.worldMatrix[8]; out[1] = -this.worldMatrix[9]; out[2] = -this.worldMatrix[10];
    const l = Math.hypot(out[0], out[1], out[2]) || 1;
    out[0] /= l; out[1] /= l; out[2] /= l;
    return out;
  }
  getRight(out = [0, 0, 0]) { out[0] = this.worldMatrix[0]; out[1] = this.worldMatrix[1]; out[2] = this.worldMatrix[2]; return Vec3.normalize(out, out); }
  getUp(out = [0, 0, 0]) { out[0] = this.worldMatrix[4]; out[1] = this.worldMatrix[5]; out[2] = this.worldMatrix[6]; return Vec3.normalize(out, out); }
  updateWorldMatrix(parentMatrix = null) {
    if (this._selfDirty || this._worldDirty) {
      Mat4.fromTRS(this.worldMatrix, this.position, this.quaternion, this.scale);
      if (parentMatrix) Mat4.mul(this.worldMatrix, parentMatrix, this.worldMatrix);
      this._selfDirty = false; this._worldDirty = false;
    }
    for (const c of this.children) c.updateWorldMatrix(this.worldMatrix);
  }
  traverse(fn) { fn(this); for (const c of this.children) c.traverse(fn); }
  findByName(name, out = []) {
    this.traverse(n => { if (n.name === name) out.push(n); });
    return out;
  }
  findByTag(tag, out = []) {
    this.traverse(n => { if (n.tag === tag) out.push(n); });
    return out;
  }
}

class Mesh extends Node {
  constructor(geometry, material, name) {
    super(name || 'mesh');
    this.isMesh = true;
    this.mesh = geometry instanceof GPUMesh ? geometry : new GPUMesh(Engine.device, geometry);
    this.geometry = this.mesh.geometry;
    this.material = material || MaterialLib.default;
    this.opacity = 1;
    this.skipShadow = false;
    this.skipReflection = false;
    this.worldBounds = new AABB();
    this._boundsCenter = [0, 0, 0];
    this._boundsRadius = 1;
    this.updateBounds();
  }
  updateBounds() {
    const b = this.mesh.bounds;
    this._boundsCenter = [(b.min[0] + b.max[0]) / 2, (b.min[1] + b.max[1]) / 2, (b.min[2] + b.max[2]) / 2];
    this._boundsRadius = Math.hypot(b.max[0] - b.min[0], b.max[1] - b.min[1], b.max[2] - b.min[2]) / 2;
    this._localBounds = b;
  }
  computeWorldBounds() {
    const m = this.worldMatrix;
    const sx = Math.hypot(m[0], m[1], m[2]), sy = Math.hypot(m[4], m[5], m[6]), sz = Math.hypot(m[8], m[9], m[10]);
    const r = this._boundsRadius * Math.max(sx, sy, sz);
    const c = this._boundsCenter;
    const cx = m[0] * c[0] + m[4] * c[1] + m[8] * c[2] + m[12];
    const cy = m[1] * c[0] + m[5] * c[1] + m[9] * c[2] + m[13];
    const cz = m[2] * c[0] + m[6] * c[1] + m[10] * c[2] + m[14];
    this._worldCenter = this._worldCenter || [0, 0, 0];
    this._worldCenter[0] = cx; this._worldCenter[1] = cy; this._worldCenter[2] = cz;
    this._worldRadius = r;
    this.worldBounds.set([cx - r, cy - r, cz - r], [cx + r, cy + r, cz + r]);
    return this.worldBounds;
  }
}

// A single GPU mesh drawn many times from an instance matrix buffer.
class InstancedMesh extends Node {
  constructor(geometry, material, capacity = 512, name) {
    super(name || 'instanced');
    this.isInstanced = true;
    this.mesh = new GPUMesh(Engine.device, geometry);
    this.geometry = this.mesh.geometry;
    this.material = material;
    this.instances = new InstanceBuffer(Engine.device, capacity, 20);
    this.count = 0;
    this.opacity = 1;
    this.skipShadow = false;
    this.skipReflection = false;
    this.worldBounds = new AABB();
    const b = this.mesh.bounds;
    this._boundsRadius = Math.hypot(b.max[0] - b.min[0], b.max[1] - b.min[1], b.max[2] - b.min[2]) / 2;
    this._localBounds = b;
    this._worldCenter = [0, 0, 0];
    this._worldRadius = 1e9;
    this._mat = Mat4.create();
  }
  begin() { this.instances.clear(); this.count = 0; this.worldBounds.set([1e9, 1e9, 1e9], [-1e9, -1e9, -1e9]); return this; }
  push(position, quaternion = null, scale = 1, data = null) {
    const s = typeof scale === 'number' ? [scale, scale, scale] : scale;
    Mat4.fromTRS(this._mat, position, quaternion || IDENTITY_Q, s);
    this.instances.pushMat(this._mat, data);
    this.count++;
    // conservative bounds growth
    this.worldBounds.expand(position, this._boundsRadius * Math.max(s[0], s[1], s[2]));
    return this;
  }
  computeWorldBounds() {
    // instanced bounds are already in world space
    this._worldCenter = this.worldBounds.center(this._worldCenter);
    this._worldRadius = Math.max(0.001, Math.hypot(this.worldBounds.max[0] - this.worldBounds.min[0], this.worldBounds.max[1] - this.worldBounds.min[1], this.worldBounds.max[2] - this.worldBounds.min[2]) / 2);
    return this.worldBounds;
  }
}
const IDENTITY_Q = Quat.create();
const _lookAtTmp = Mat4.create();

class Camera extends Node {
  constructor(fov = 68, aspect = 16 / 9, near = 0.08, far = 600) {
    super('camera');
    this.isCamera = true;
    this.fov = fov * DEG;
    this.aspect = aspect;
    this.near = near;
    this.far = far;
    this.projection = Mat4.create();
    this.view = Mat4.create();
    this.frustum = new Frustum();
    this.viewProjection = Mat4.create();
    this.shakeOffset = [0, 0, 0];
    this.shakeRot = [0, 0, 0];
    this.roll = 0;
  }
  updateMatrices() {
    Mat4.perspective(this.projection, this.fov, this.aspect, this.near, this.far);
    const eye = [this.worldMatrix[12], this.worldMatrix[13], this.worldMatrix[14]];
    const fwd = this.getForward([0, 0, 0]);
    const up = [0, 1, 0];
    Mat4.lookAt(this.view, eye, [eye[0] + fwd[0], eye[1] + fwd[1], eye[2] + fwd[2]], up);
    Mat4.mul(this.viewProjection, this.projection, this.view);
    this.frustum.fromMatrix(this.viewProjection);
    return this;
  }
  screenToRay(nx, ny, out = { origin: [0, 0, 0], dir: [0, 0, 1] }) {
    const inv = Mat4.invert(Mat4.create(), this.viewProjection);
    const p0 = Mat4.transformPoint([0, 0, 0], inv, [nx, ny, -1]);
    const p1 = Mat4.transformPoint([0, 0, 0], inv, [nx, ny, 1]);
    out.origin = p0;
    out.dir = Vec3.normalize([0, 0, 0], [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]]);
    return out;
  }
}

class Light extends Node {
  constructor(type = 'point', opts = {}) {
    super(opts.name || ('light_' + type));
    this.isLight = true;
    this.type = type;
    this.color = opts.color || [1, 1, 1];
    this.intensity = opts.intensity !== undefined ? opts.intensity : 1;
    this.range = opts.range !== undefined ? opts.range : 10;
    this.innerAngle = (opts.innerAngle !== undefined ? opts.innerAngle : 20) * DEG;
    this.outerAngle = (opts.outerAngle !== undefined ? opts.outerAngle : 32) * DEG;
    this.cosInner = Math.cos(this.innerAngle);
    this.cosOuter = Math.cos(this.outerAngle);
    this.castShadow = !!opts.castShadow;
    this.direction = opts.direction ? Vec3.of(opts.direction) : Vec3.create(0, -1, 0);
    this.angularSize = opts.angularSize || 0.0035;
    this.shadowStrength = opts.shadowStrength !== undefined ? opts.shadowStrength : 1;
    this.flicker = opts.flicker || 0;
    this.baseIntensity = this.intensity;
    this.flickerSpeed = opts.flickerSpeed || 8;
    this.time = Math.random() * 100;
  }
  getColor() {
    const f = this.flicker ? 1 - this.flicker * (0.5 + 0.5 * Math.sin(this.time * this.flickerSpeed) * Math.sin(this.time * this.flickerSpeed * 2.7)) : 1;
    return [this.color[0] * f, this.color[1] * f, this.color[2] * f];
  }
  update(dt) {
    this.time += dt;
    if (this.flicker) this.intensity = this.baseIntensity;
    if (this.type === 'sun') {
      const w = this.worldMatrix;
      Vec3.set(this.direction, -w[8], -w[9], -w[10]);
      Vec3.normalize(this.direction, this.direction);
    }
  }
}

class Scene extends Node {
  constructor(name = 'scene') {
    super(name);
    this.isScene = true;
    this.meshes = [];
    this.pointLights = [];
    this.spotLights = [];
    this.renderList = [];
    this.sun = {
      direction: Vec3.normalize(Vec3.create(), [-0.42, 0.62, 0.66]),
      color: [1.0, 0.96, 0.9],
      intensity: 3.2,
      castShadow: true,
      shadowStrength: 1.0,
      angularSize: 0.0035,
      elevation: 40 * DEG,
      azimuth: 140 * DEG,
    };
    this.sky = { turbidity: 0.45, exposure: 1.0, night: 0, intensity: 1.0, ambientBoost: 1.0 };
    this.fog = { color: [0.36, 0.44, 0.56], density: 0.0055, height: 0.0, falloff: 0.045, sunAmount: 0.5, enabled: true };
    this.water = null;
    this.waterNormalMap = null;
    this.time = 0;
    this.environmentIntensity = 1.0;
    this.gravity = -22;
    this.shadowCasters = [];
  }
  add(node) { super.add(node); return node; }
  addMesh(mesh) { this.add(mesh); this.meshes.push(mesh); return mesh; }
  makeMesh(geometry, material, name) { return this.addMesh(new Mesh(geometry, material, name)); }
  makeInstanced(geometry, material, capacity, name) {
    const m = new InstancedMesh(geometry, material, capacity, name);
    this.add(m);
    this.meshes.push(m);
    return m;
  }
  addLight(light) {
    this.add(light);
    if (light.type === 'point') this.pointLights.push(light);
    else if (light.type === 'spot') this.spotLights.push(light);
    return light;
  }
  removeLight(light) {
    const arr = light.type === 'point' ? this.pointLights : this.spotLights;
    const i = arr.indexOf(light);
    if (i >= 0) arr.splice(i, 1);
    this.remove(light);
    return this;
  }
  remove(node) {
    super.remove(node);
    const i = this.meshes.indexOf(node);
    if (i >= 0) this.meshes.splice(i, 1);
    if (node.isLight) {
      const a = node.type === 'point' ? this.pointLights : this.spotLights;
      const j = a.indexOf(node);
      if (j >= 0) a.splice(j, 1);
    }
    return this;
  }
  update(dt) {
    this.time += dt;
    for (const l of this.pointLights) l.update(dt);
    for (const l of this.spotLights) l.update(dt);
  }
  setSunFromAngles(elevation, azimuth, color = null, intensity = null) {
    this.sun.elevation = elevation;
    this.sun.azimuth = azimuth;
    const ce = Math.cos(elevation), se = Math.sin(elevation);
    Vec3.set(this.sun.direction, Math.cos(azimuth) * ce, se, Math.sin(azimuth) * ce);
    Vec3.normalize(this.sun.direction, this.sun.direction);
    if (color) this.sun.color = color;
    if (intensity !== null) this.sun.intensity = intensity;
    return this;
  }
  getShadowSpots(max) {
    return this.spotLights.filter(s => s.castShadow).slice(0, max);
  }
  // The render list walks the scene graph (that's the only source of truth) so
  // anything parented to a node — enemies, weapons, projectiles — is drawn.
  _collect(node, out) {
    if (!node.visible) return;
    if (node.isMesh || node.isInstanced) out.push(node);
    for (const c of node.children) this._collect(c, out);
  }
  buildRenderList(camera) {
    const list = this.renderList;
    list.length = 0;
    const frustum = camera.frustum;
    this._meshScratch = this._meshScratch || [];
    const scratch = this._meshScratch;
    scratch.length = 0;
    for (const root of this.children) this._collect(root, scratch);
    const camPos = [camera.worldMatrix[12], camera.worldMatrix[13], camera.worldMatrix[14]];
    for (const m of scratch) {
      if (!m.material || m.opacity <= 0.001) continue;
      if (m.isInstanced && (!m.count || m.count === 0)) continue;
      if (m === camera) continue;
      // the camera's own children (the weapon) are drawn last, on top
      m.computeWorldBounds();
      // viewmodels ride the camera: never cull them
      const isVM = m.tag === 'viewmodel';
      if (!isVM) {
        if (m.isInstanced) {
          if (m._worldRadius < 1e8 && !frustum.intersectsSphere(m._worldCenter, m._worldRadius)) continue;
        } else if (!frustum.intersectsSphere(m._worldCenter, m._worldRadius)) continue;
      }
      list.push(m);
    }
    list.sort((a, b) => {
      // viewmodel first in its category so it lands on top of the depth buffer
      const va = a.tag === 'viewmodel' ? 1 : 0, vb = b.tag === 'viewmodel' ? 1 : 0;
      if (va !== vb) return va - vb;
      const ta = a.material.transparent ? 1 : 0, tb = b.material.transparent ? 1 : 0;
      if (ta !== tb) return ta - tb;
      const da = ta ? -Vec3.dist2(a._worldCenter, camPos) : Vec3.dist2(a._worldCenter, camPos);
      const db = tb ? -Vec3.dist2(b._worldCenter, camPos) : Vec3.dist2(b._worldCenter, camPos);
      return da - db;
    });
    return list;
  }
}
