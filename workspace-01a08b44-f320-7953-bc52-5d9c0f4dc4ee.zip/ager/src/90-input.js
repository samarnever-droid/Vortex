// ===========================================================================
//  AGER ENGINE  ·  90-input  ·  keyboard, mouse, pointer lock, gamepad
// ===========================================================================

const DEFAULT_BINDINGS = {
  forward: ['KeyW', 'ArrowUp'], back: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
  jump: ['Space'], sprint: ['ShiftLeft', 'ShiftRight'], crouch: ['ControlLeft', 'KeyC'],
  fire: ['Mouse0'], altFire: ['Mouse2'], reload: ['KeyR'], use: ['KeyE'],
  ability1: ['KeyQ'], ability2: ['KeyF'], dash: ['ShiftLeft'],
  map: ['Tab'], pause: ['Escape'], interact: ['KeyE'], console: ['Backquote'],
};

class Input {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.bindings = Object.assign({}, DEFAULT_BINDINGS, opts.bindings || {});
    this.keys = new Map();
    this.mouse = { x: 0, y: 0, dx: 0, dy: 0, wheel: 0, locked: false };
    this.actions = new Map();
    this.mouseButtons = [false, false, false, false, false];
    this.sensitivity = opts.sensitivity || 0.0022;
    this.invertY = !!opts.invertY;
    this.enabled = true;
    this.gamepadIndex = null;
    this.gamepadState = { move: [0, 0], look: [0, 0], fire: false, jump: false };
    this.onLockChange = new Signal();
    this.onResize = new Signal();
    this._bindEvents();
  }
  _bindEvents() {
    const c = this.canvas;
    addEventListener('keydown', (e) => {
      if (e.code === 'Tab') e.preventDefault();
      this.keys.set(e.code, true);
      if (e.code === 'Escape') document.exitPointerLock && document.exitPointerLock();
    });
    addEventListener('keyup', (e) => this.keys.set(e.code, false));
    addEventListener('blur', () => { this.keys.clear(); this.mouseButtons.fill(false); });
    c.addEventListener('mousedown', (e) => {
      this.mouseButtons[e.button] = true;
      if (!this.mouse.locked && this.requestLockOnClick !== false) this.requestLock();
    });
    addEventListener('mouseup', (e) => { this.mouseButtons[e.button] = false; });
    addEventListener('mousemove', (e) => {
      if (this.mouse.locked) {
        this.mouse.dx += e.movementX || 0;
        this.mouse.dy += e.movementY || 0;
      }
      this.mouse.x = e.clientX; this.mouse.y = e.clientY;
    });
    addEventListener('wheel', (e) => { this.mouse.wheel += Math.sign(e.deltaY); }, { passive: true });
    document.addEventListener('pointerlockchange', () => {
      this.mouse.locked = document.pointerLockElement === this.canvas;
      this.onLockChange.emit(this.mouse.locked);
    });
    addEventListener('gamepadconnected', (e) => { this.gamepadIndex = e.gamepad.index; });
    addEventListener('resize', () => this.onResize.emit());
  }
  requestLock() {
    if (this.canvas.requestPointerLock) this.canvas.requestPointerLock();
  }
  exitLock() { document.exitPointerLock && document.exitPointerLock(); }
  keyDown(code) { return !!this.keys.get(code); }
  isDown(action) {
    const b = this.bindings[action];
    if (!b) return false;
    for (const k of b) {
      if (k.startsWith('Mouse')) { if (this.mouseButtons[parseInt(k.slice(5), 10)]) return true; }
      else if (this.keys.get(k)) return true;
    }
    const gp = this.gamepadState;
    if (action === 'jump' && gp.jump) return true;
    if (action === 'fire' && gp.fire) return true;
    return false;
  }
  // edge detection per frame
  beginFrame() {
    this._prev = this._prev || new Map();
    if (!this._curr) this._curr = new Map();
    this._curr.clear();
    for (const [k, v] of this.keys) if (v) this._curr.set(k, true);
    for (let i = 0; i < 5; i++) if (this.mouseButtons[i]) this._curr.set('Mouse' + i, true);
    this._pressedCache = null;
  }
  pressed(action) {
    const b = this.bindings[action];
    if (!b) return false;
    for (const k of b) {
      if (this._curr.get(k) && !this._prev.get(k)) return true;
    }
    return false;
  }
  released(action) {
    const b = this.bindings[action];
    if (!b) return false;
    for (const k of b) {
      if (!this._curr.get(k) && this._prev.get(k)) return true;
    }
    return false;
  }
  endFrame() {
    const tmp = this._prev;
    this._prev = this._curr;
    this._curr = tmp;
  }
  consumeMouse() {
    const d = [this.mouse.dx * this.sensitivity, (this.invertY ? -1 : 1) * this.mouse.dy * this.sensitivity];
    this.mouse.dx = 0; this.mouse.dy = 0;
    return d;
  }
  consumeWheel() { const w = this.mouse.wheel; this.mouse.wheel = 0; return w; }
  pollGamepad() {
    if (!navigator.getGamepads) return;
    const pads = navigator.getGamepads();
    const gp = this.gamepadIndex !== null ? pads[this.gamepadIndex] : pads[0];
    if (!gp) return;
    const dz = (v) => Math.abs(v) < 0.16 ? 0 : v;
    this.gamepadState.move = [dz(gp.axes[0] || 0), dz(gp.axes[1] || 0)];
    this.gamepadState.look = [dz(gp.axes[2] || 0), dz(gp.axes[3] || 0)];
    this.gamepadState.fire = !!(gp.buttons[7] && gp.buttons[7].pressed) || !!(gp.buttons[5] && gp.buttons[5].pressed);
    this.gamepadState.jump = !!(gp.buttons[0] && gp.buttons[0].pressed);
  }
}
