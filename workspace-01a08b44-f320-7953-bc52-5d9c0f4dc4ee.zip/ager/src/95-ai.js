// ===========================================================================
//  AGER ENGINE  ·  95-ai  ·  the agent layer
//
//  Ager is designed to be driven by a human *or* by a model:
//    ager.describe()        -> machine readable map of the whole engine
//    ager.spawn(op)         -> structured, validated world edits
//    ager.query(filter)     -> read the world back as JSON
//    ager.say("...")        -> natural language -> ops (rule based, offline)
//    ager.serialize()       -> whole scene <-> JSON, round trippable
// ===========================================================================

class CommandRouter {
  constructor() {
    this.handlers = new Map();
    this.log = [];
    this.onLog = new Signal();
  }
  register(name, fn, help = '') { this.handlers.set(name, { fn, help }); return this; }
  run(name, args = {}) {
    const h = this.handlers.get(name);
    if (!h) {
      const msg = `unknown command: ${name}. try: ${[...this.handlers.keys()].slice(0, 12).join(', ')}`;
      this._push({ ok: false, name, message: msg });
      return { ok: false, error: msg };
    }
    try {
      const result = h.fn(args) || {};
      this._push({ ok: true, name, args, result });
      return Object.assign({ ok: true }, result);
    } catch (e) {
      this._push({ ok: false, name, args, error: String(e && e.message || e) });
      return { ok: false, error: String(e && e.message || e) };
    }
  }
  _push(entry) { entry.time = performance.now() / 1000; this.log.push(entry); if (this.log.length > 200) this.log.shift(); this.onLog.emit(entry); }
  help() {
    const out = [];
    for (const [k, v] of this.handlers) out.push({ command: k, help: v.help });
    return out;
  }
}

const AgerAI = {
  router: new CommandRouter(),
  context: { engine: null, scene: null, camera: null, world: null },

  // ---- introspection ------------------------------------------------------
  describe() {
    const e = this.context.engine;
    const scene = this.context.scene;
    return {
      engine: {
        name: 'Ager', version: AGER_VERSION, backend: 'WebGL2',
        renderer: e ? e.device.renderer : 'not booted',
        features: [
          'pbr-cook-torrance', 'cascaded-shadow-maps', 'spot-shadows', 'sh9-ibl', 'atmospheric-sky',
          'procedural-textures', 'screen-space-ambient-occlusion', 'bloom', 'god-rays', 'aces-tonemap',
          'planar-water-reflections', 'gerstner-waves', 'height-fog', 'instancing', 'particles',
          'capsule-character-controller', 'spatial-hash-physics', 'procedural-audio', 'adaptive-music',
        ],
        quality: e ? e.renderer.quality : null,
        stats: e ? e.stats() : null,
      },
      api: {
        boot: 'Ager.create({ canvas, quality })',
        primitives: Object.keys(PRIMITIVES),
        materials: Object.keys(MaterialLib.registry),
        commands: this.router.help(),
        spec: 'Ager.loadSpec(spec) — declarative world description',
      },
      scene: scene ? {
        entities: scene.meshes.length,
        lights: scene.pointLights.length + scene.spotLights.length,
        sun: { direction: Array.from(scene.sun.direction), intensity: scene.sun.intensity },
        named: scene.meshes.filter(m => m.name && !m.name.startsWith('mesh')).slice(0, 40).map(m => m.name),
      } : null,
    };
  },
  describeText() {
    const d = this.describe();
    const lines = [];
    lines.push(`AGER v${d.engine.version} — ${d.engine.features.length} subsystems live on ${d.engine.renderer}`);
    lines.push(`commands: ${d.api.commands.map(c => c.command).join(', ')}`);
    lines.push(`primitives: ${d.api.primitives.join(', ')}`);
    lines.push(`materials: ${d.api.materials.join(', ')}`);
    if (d.scene) lines.push(`scene: ${d.scene.entities} entities, ${d.scene.lights} dynamic lights`);
    return lines.join('\n');
  },

  // ---- structured ops -----------------------------------------------------
  op(name, args) { return this.router.run(name, args); },

  applyOps(ops) {
    const results = [];
    for (const o of ops) results.push(this.router.run(o.op || o.command, o.args || o.args === undefined ? (o.args || o) : o));
    return results;
  },

  // ---- natural language ---------------------------------------------------
  // Deliberately small, deterministic and offline: a rules engine that maps
  // the kinds of sentences a player (or a model) writes into real commands.
  say(text) {
    const t = String(text || '').toLowerCase().trim();
    if (!t) return 'nothing to do';
    const num = (def) => {
      const m = t.match(/(\d+(\.\d+)?)/);
      return m ? parseFloat(m[1]) : def;
    };
    const rules = [
      { re: /^(help|\?|commands)$/, fn: () => 'commands: ' + this.router.help().map(c => c.command).join(', ') },
      { re: /night|dark|midnight/, fn: () => this.op('time', { preset: 'night' }).result || 'set to night' },
      { re: /sunset|dusk|evening/, fn: () => this.op('time', { preset: 'dusk' }).result || 'set to dusk' },
      { re: /sunrise|dawn|morning/, fn: () => this.op('time', { preset: 'dawn' }).result || 'set to dawn' },
      { re: /noon|daytime|bright|day\b/, fn: () => this.op('time', { preset: 'noon' }).result || 'set to noon' },
      { re: /(\w+)\s+storm|storm/, fn: () => this.op('weather', { type: 'storm' }).result || 'storm incoming' },
      { re: /rain/, fn: () => this.op('weather', { type: 'rain' }).result || 'rain incoming' },
      { re: /clear\s*(weather|sky)?/, fn: () => this.op('weather', { type: 'clear' }).result || 'skies cleared' },
      {
        re: /(spawn|add|drop|place)\s+(\d+)?\s*([a-z_]+)s?/, fn: () => {
          const count = num(1);
          const m = t.match(/(?:spawn|add|drop|place)\s+(?:(\d+)\s+)?([a-z_]+)s?\b/);
          const type = m ? m[2] : 'crate';
          const at = t.match(/near\s+([a-z_]+)/);
          const target = at ? at[1] : (t.match(/at\s+(me|player)/) ? 'player' : 'ahead');
          return this.op('spawn', { type, count, near: target }).result || `spawned ${count} ${type} ${target}`;
        }
      },
      { re: /(kill|clear|remove|delete)\s+(all\s+)?(enemies|enemy|mobs)/, fn: () => this.op('clearEnemies', {}).result || 'enemies cleared' },
      { re: /(clear|remove|delete)\s+(all\s+)?(props|crates|debris)/, fn: () => this.op('clearProps', {}).result || 'props cleared' },
      { re: /(next|start)\s*wave/, fn: () => this.op('nextWave', {}).result || 'wave starting' },
      { re: /(god\s*mode|invuln|invincible)/, fn: () => this.op('godmode', {}).result || 'god mode' },
      { re: /heal|repair\s+crucible/, fn: () => this.op('heal', {}).result || 'repaired' },
      { re: /(more|less|increase|decrease)\s+bloom/, fn: () => this.op('bloom', { value: /less|decrease/.test(t) ? -0.03 : 0.03 }).result || 'bloom adjusted' },
      { re: /(more|less)\s+fog|fog\s*(on|off)/, fn: () => this.op('fog', { mode: /less|off/.test(t) ? 'less' : 'more' }).result || 'fog adjusted' },
      { re: /(slow|fast|speed\s*up)\s*(time|motion|mo)?/, fn: () => this.op('timescale', { value: /slow/.test(t) ? 0.35 : 2.2 }).result || 'time scaled' },
      { re: /explode|bomb|blast/, fn: () => this.op('boom', {}).result || 'boom' },
      { re: /frame\s*(rate|s)?|fps|perf/, fn: () => this.op('stats', {}).result || 'stats' },
      { re: /(rebuild|reload)\s*textures/, fn: () => this.op('regenTextures', {}).result || 'textures regenerated' },
      { re: /wireframe/, fn: () => this.op('wireframe', {}).result || 'toggled' },
      { re: /(screenshot|photo)/, fn: () => this.op('screenshot', {}).result || 'captured' },
      { re: /(spawn|summon)\s+(a\s+)?(boss|warden prime|prime)/, fn: () => this.op('spawnBoss', {}).result || 'boss inbound' },
      { re: /(rain|storm)\s+of\s+(lasers|plasma)/, fn: () => this.op('laserRain', {}).result || 'pew pew' },
      { re: /make\s+it\s+(brighter|darker)/, fn: () => this.op('exposure', { value: /brighter/.test(t) ? 0.35 : -0.35 }).result || 'exposure changed' },
      { re: /(slower|faster)\s+(enemies|mobs)/, fn: () => this.op('enemySpeed', { value: /slower/.test(t) ? 0.6 : 1.6 }).result || 'enemy speed changed' },
      { re: /(rain|spawn)\s+hundred\s+(of\s+)?(crates|boxes|barrels)/, fn: () => this.op('spawn', { type: 'barrel', count: 60, near: 'ahead', scatter: 24 }).result || 'barrels' },
    ];
    for (const r of rules) {
      if (r.re.test(t)) {
        const out = r.fn();
        return typeof out === 'string' ? out : JSON.stringify(out);
      }
    }
    return `I don't know how to "${text}" yet — try "help"`;
  },

  // ---- scene <-> JSON ------------------------------------------------------
  serialize(scene, opts = {}) {
    const out = { version: AGER_VERSION, sun: { direction: Array.from(scene.sun.direction), color: scene.sun.color, intensity: scene.sun.intensity }, sky: scene.sky, fog: scene.fog, entities: [], lights: [] };
    for (const m of scene.meshes) {
      if (m.tag === 'transient') continue;
      out.entities.push({
        name: m.name, tag: m.tag,
        position: Array.from(m.position).map(v => +v.toFixed(3)),
        rotation: Array.from(m.quaternion).map(v => +v.toFixed(3)),
        scale: Array.from(m.scale).map(v => +v.toFixed(3)),
        material: m.material ? m.material.name : null,
        geometry: m.geometryKey || 'mesh',
        instanced: !!m.isInstanced, count: m.count || 0,
      });
    }
    for (const l of scene.pointLights) out.lights.push({ type: 'point', position: Array.from(l.position), color: l.color, intensity: l.intensity, range: l.range });
    for (const l of scene.spotLights) out.lights.push({ type: 'spot', position: Array.from(l.position), color: l.color, intensity: l.intensity, range: l.range, castShadow: l.castShadow });
    return out;
  },
};
