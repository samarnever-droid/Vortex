// ===========================================================================
//  AGER ENGINE  ·  50-render  ·  the renderer
//
//  Frame graph:
//    shadow pass (sun cascades + spot lights, one depth array, 3x3 PCF)
//    sky -> env cubemap (mip chain = prefiltered specular)
//    main pass (opaque -> transparent -> water) into RGBA16F
//    post: SSAO -> bloom -> god rays -> ACES tonemap + grade + FXAA
// ===========================================================================

// --- SkyModel: CPU twin of GLSL skyColor (drives SH irradiance) -------------
const SkyModel = {
  params: { sunDir: [0.3, 0.4, 0.6], sunColor: [1, 0.95, 0.88], sunSize: 0.0035, turbidity: 0.5, exposure: 1.0, night: 0 },
  sample(rd, p = this.params) {
    const Rg = 6360000, Ra = 6420000, Hr = 8000, Hm = 1200;
    const betaR = [5.8e-6, 13.5e-6, 33.1e-6], betaM = 21e-6, G = 0.76;
    const ro = [0, Rg + 300, 0];
    const sd = p.sunDir;
    // ray-sphere: a
    const b = ro[0] * rd[0] + ro[1] * rd[1] + ro[2] * rd[2];
    const c = (ro[0] * ro[0] + ro[1] * ro[1] + ro[2] * ro[2]) - Ra * Ra;
    let d = b * b - c;
    if (d < 0) return [0.02, 0.02, 0.03];
    d = Math.sqrt(d);
    const aNear = -b - d, aFar = -b + d;
    // ground hit
    const cg = (ro[0] * ro[0] + ro[1] * ro[1] + ro[2] * ro[2]) - Rg * Rg;
    let dg = b * b - cg;
    let tEnd = aFar;
    if (dg >= 0) { const s = Math.sqrt(dg); const gNear = -b - s; if (gNear > 0) tEnd = Math.min(tEnd, gNear); }
    const mu = rd[0] * sd[0] + rd[1] * sd[1] + rd[2] * sd[2];
    const g2 = G * G;
    const phaseR = 3 / (16 * Math.PI) * (1 + mu * mu);
    const phaseM = 3 / (8 * Math.PI) * ((1 - g2) * (1 + mu * mu)) / ((2 + g2) * Math.pow(Math.max(1e-3, 1 + g2 - 2 * G * mu), 1.5));
    const mieF = lerp(0.4, 1.6, clamp(p.turbidity, 0, 1.5));
    const STEPS = 14, step = tEnd / STEPS;
    let sR = [0, 0, 0], sM = [0, 0, 0], odR = 0, odM = 0;
    for (let i = 0; i < STEPS; i++) {
      const t = (i + 0.5) * step;
      const px = ro[0] + rd[0] * t, py = ro[1] + rd[1] * t, pz = ro[2] + rd[2] * t;
      const h = Math.max(0, Math.hypot(px, py, pz) - Rg);
      const dR = Math.exp(-h / Hr) * step, dM = Math.exp(-h / Hm) * step;
      odR += dR; odM += dM;
      const t0 = betaR[0] * (odR + odM * 0.3) + betaM * 1.1 * odM;
      const t1 = betaR[1] * (odR + odM * 0.3) + betaM * 1.1 * odM;
      const t2 = betaR[2] * (odR + odM * 0.3) + betaM * 1.1 * odM;
      const a0 = Math.exp(-t0), a1 = Math.exp(-t1), a2 = Math.exp(-t2);
      sR[0] += a0 * dR; sR[1] += a1 * dR; sR[2] += a2 * dR;
      sM[0] += a0 * dM; sM[1] += a1 * dM; sM[2] += a2 * dM;
    }
    const col = [0, 0, 0];
    for (let k = 0; k < 3; k++) {
      col[k] = (sR[k] * betaR[k] * phaseR + sM[k] * betaM * phaseM * mieF) * p.sunColor[k] * 8 * p.exposure;
    }
    const cosAng = mu, ang = Math.acos(clamp(cosAng, -1, 1));
    const disk = 1 - smoothstep(p.sunSize, p.sunSize * 1.5, ang);
    const glow = Math.pow(Math.max(0, cosAng), 300) * 0.5 + Math.pow(Math.max(0, cosAng), 14) * 0.06;
    for (let k = 0; k < 3; k++) col[k] += (disk * 140 + glow * 3) * p.sunColor[k] * p.exposure;
    const hz = Math.exp(-Math.max(0, rd[1]) * 8);
    for (let k = 0; k < 3; k++) col[k] += p.sunColor[k] * hz * 0.02 * clamp(p.sunDir[1] + 0.35, 0, 1) * p.exposure;
    const tint = [lerp(0.7, 1, clamp(p.sunDir[1] * 4 + 0.6, 0, 1)), lerp(0.78, 1, clamp(p.sunDir[1] * 4 + 0.6, 0, 1)), lerp(0.95, 1, clamp(p.sunDir[1] * 4 + 0.6, 0, 1))];
    for (let k = 0; k < 3; k++) col[k] *= tint[k];
    return col;
  },
  // project sky into 9 SH coefficients (L2 irradiance)
  computeSH(p = this.params) {
    const SH = new Float32Array(27);
    const N = 12; // lat
    const M = 24; // lon
    const Y = (l, m, x, y, z) => {
      if (l === 0) return 0.282095;
      if (l === 1) return m === -1 ? 0.488603 * y : (m === 0 ? 0.488603 * z : 0.488603 * x);
      if (l === 2) {
        if (m === -2) return 1.092548 * x * y;
        if (m === -1) return 1.092548 * y * z;
        if (m === 0) return 0.315392 * (3 * z * z - 1);
        if (m === 1) return 1.092548 * x * z;
        return 0.546274 * (x * x - y * y);
      }
      return 0;
    };
    // index map for our uniform layout: [0]=L0, [1]=Y1-1(y), [2]=Y10(z), [3]=Y11(x),
    // [4]=Y2-2(xy), [5]=Y2-1(yz), [6]=Y21(xz), [7]=Y2-2?(x2-y2), [8]=Y20
    const idx = { '0': 0, '1:-1': 1, '1:0': 2, '1:1': 3, '2:-2': 4, '2:-1': 5, '2:1': 6, '2:2': 7, '2:0': 8 };
    let weight = 0;
    for (let j = 0; j < N; j++) {
      const theta = (j + 0.5) / N * Math.PI;
      const sy = Math.cos(theta);
      const st = Math.sin(theta);
      for (let i = 0; i < M; i++) {
        const phi = (i + 0.5) / M * TAU;
        const x = st * Math.cos(phi), z = st * Math.sin(phi);
        const c = this.sample([x, sy, z], p);
        const dw = Math.sin(theta) * Math.PI / N * TAU / M;
        weight += dw;
        SH[0] += c[0] * 0.282095 * dw; SH[1] += c[1] * 0.282095 * dw; SH[2] += c[2] * 0.282095 * dw;
        const set = (key, y) => {
          const o = idx[key] * 3;
          SH[o] += c[0] * y * dw; SH[o + 1] += c[1] * y * dw; SH[o + 2] += c[2] * y * dw;
        };
        set('1:-1', 0.488603 * sy); set('1:0', 0.488603 * z); set('1:1', 0.488603 * x);
        set('2:-2', 1.092548 * x * sy); set('2:-1', 1.092548 * sy * z); set('2:1', 1.092548 * x * z);
        set('2:2', 0.546274 * (x * x - sy * sy)); set('2:0', 0.315392 * (3 * sy * sy - 1));
      }
    }
    return SH;
  }
};

// --- post-process shaders ---------------------------------------------------
const COPY_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform float uExposure;
layout(location=0) out vec4 outColor;
void main(){ vec4 c = texture(uTex, vUV); outColor = vec4(c.rgb * uExposure, c.a); }`;

const BLOOM_PREFILTER_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uTexel;
uniform float uThreshold;
uniform float uSoftKnee;
uniform float uExposure;
layout(location=0) out vec4 outColor;
void main(){
  vec2 t = uTexel;
  vec3 c = texture(uTex, vUV).rgb * uExposure;
  c += texture(uTex, vUV + vec2(t.x,0.0)).rgb * uExposure;
  c += texture(uTex, vUV + vec2(-t.x,0.0)).rgb * uExposure;
  c += texture(uTex, vUV + vec2(0.0,t.y)).rgb * uExposure;
  c += texture(uTex, vUV + vec2(0.0,-t.y)).rgb * uExposure;
  c *= 0.2;
  float br = max(c.r, max(c.g, c.b));
  float knee = uThreshold * uSoftKnee + 1e-5;
  float soft = clamp(br - uThreshold + knee, 0.0, 2.0*knee);
  soft = soft*soft/(4.0*knee);
  float contrib = max(soft, br - uThreshold) / max(br, 1e-5);
  outColor = vec4(c * contrib, 1.0);
}`;

const BLOOM_DOWN_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uTexel;
layout(location=0) out vec4 outColor;
void main(){
  vec2 t = uTexel;
  vec3 a = texture(uTex, vUV + vec2(-t.x, -t.y)).rgb;
  vec3 b = texture(uTex, vUV + vec2( t.x, -t.y)).rgb;
  vec3 c = texture(uTex, vUV + vec2(-t.x,  t.y)).rgb;
  vec3 d = texture(uTex, vUV + vec2( t.x,  t.y)).rgb;
  vec3 e = texture(uTex, vUV).rgb;
  vec3 f = texture(uTex, vUV + vec2(-t.x*2.0, 0.0)).rgb;
  vec3 g = texture(uTex, vUV + vec2( t.x*2.0, 0.0)).rgb;
  vec3 h = texture(uTex, vUV + vec2(0.0, -t.y*2.0)).rgb;
  vec3 i = texture(uTex, vUV + vec2(0.0,  t.y*2.0)).rgb;
  vec3 o = (a+b+c+d) * 0.5 + e * 0.5 + (f+g+h+i) * 0.125;
  outColor = vec4(o * 0.25, 1.0);
}`;

const BLOOM_UP_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uTexel;
uniform float uRadius;
layout(location=0) out vec4 outColor;
void main(){
  vec2 t = uTexel * uRadius;
  vec3 o = texture(uTex, vUV + vec2(-t.x, -t.y)).rgb * 1.0;
  o += texture(uTex, vUV + vec2( 0.0, -t.y)).rgb * 2.0;
  o += texture(uTex, vUV + vec2( t.x, -t.y)).rgb * 1.0;
  o += texture(uTex, vUV + vec2(-t.x,  0.0)).rgb * 2.0;
  o += texture(uTex, vUV).rgb * 4.0;
  o += texture(uTex, vUV + vec2( t.x,  0.0)).rgb * 2.0;
  o += texture(uTex, vUV + vec2(-t.x,  t.y)).rgb * 1.0;
  o += texture(uTex, vUV + vec2( 0.0,  t.y)).rgb * 2.0;
  o += texture(uTex, vUV + vec2( t.x,  t.y)).rgb * 1.0;
  outColor = vec4(o * (1.0/16.0), 1.0);
}`;

const SSAO_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uDepth;
uniform vec2 uTexel;
uniform mat4 uProj;
uniform mat4 uInvProj;
uniform vec3 uKernel[16];
uniform float uRadius;
uniform float uBias;
uniform float uIntensity;
uniform float uNear;
uniform float uFar;
layout(location=0) out vec4 outColor;

float linearDepth(float d){
  float ndc = d * 2.0 - 1.0;
  return (2.0 * uNear * uFar) / (uFar + uNear - ndc * (uFar - uNear));
}
vec3 viewPos(vec2 uv, float d){
  vec4 clip = vec4(uv*2.0-1.0, d*2.0-1.0, 1.0);
  vec4 v = uInvProj * clip;
  return v.xyz / v.w;
}
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx)*0.1031); p3 += dot(p3, p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
void main(){
  float d = texture(uDepth, vUV).r;
  if (d >= 0.99999){ outColor = vec4(1.0); return; }
  vec3 P = viewPos(vUV, d);
  float ang = hash12(vUV * 1024.0) * 6.2831;
  float ca = cos(ang), sa = sin(ang);
  vec3 n = normalize(cross(dFdx(P), dFdy(P)));
  float occ = 0.0;
  float rnd = hash12(vUV * 71.13);
  for (int i = 0; i < 16; i++){
    vec3 k = uKernel[i];
    vec3 kx = vec3(k.x*ca - k.y*sa, k.x*sa + k.y*ca, k.z);
    if (dot(kx, n) < 0.0) kx = -kx;
    vec3 sp = P + kx * uRadius * (1.0 + rnd*0.6);
    vec4 clip = uProj * vec4(sp, 1.0);
    vec2 suv = clip.xy / clip.w * 0.5 + 0.5;
    if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;
    float sampleD = texture(uDepth, suv).r;
    if (sampleD >= 0.99999) continue;
    vec3 spv = viewPos(suv, sampleD);
    float dz = spv.z - sp.z;
    float rangeCheck = smoothstep(0.0, 1.0, uRadius / max(1e-4, abs(P.z - spv.z)));
    if (dz >= uBias) occ += rangeCheck;
  }
  float ao = clamp(1.0 - occ / 16.0 * uIntensity, 0.0, 1.0);
  outColor = vec4(ao, ao, ao, 1.0);
}`;

const SSAO_BLUR_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uTexel;
layout(location=0) out vec4 outColor;
void main(){
  float s = 0.0;
  vec2 t = uTexel * 2.0;
  for (int y=-2;y<=2;y++) for (int x=-2;x<=2;x++){
    s += texture(uTex, vUV + vec2(float(x),float(y))*t).r;
  }
  outColor = vec4(vec3(s/25.0), 1.0);
}`;

const GODRAY_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform sampler2D uDepth;
uniform vec2 uSunUV;
uniform float uDensity;
uniform float uDecay;
uniform float uWeight;
layout(location=0) out vec4 outColor;
void main(){
  vec2 dir = (uSunUV - vUV) * uDensity / 24.0;
  vec2 uv = vUV;
  float illum = 1.0, sum = 0.0;
  for (int i=0;i<24;i++){
    vec2 suv = uv;
    vec3 c = texture(uTex, suv).rgb;
    float d = texture(uDepth, suv).r;
    float sky = (d >= 0.9999) ? 1.0 : 0.0;
    float br = max(c.r, max(c.g, c.b));
    sum += max(br - 1.6, 0.0) * illum * mix(0.25, 1.0, sky);
    illum *= uDecay;
    uv += dir;
  }
  outColor = vec4(vec3(sum) * uWeight, 1.0);
}`;

const COMPOSITE_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uColor;
uniform sampler2D uBloom;
uniform sampler2D uAO;
uniform sampler2D uGodray;
uniform sampler2D uNoise;
uniform vec2 uTexel;
uniform vec2 uResolution;
uniform vec3 uCameraForward;
uniform float uBloomStrength;
uniform float uAOStrength;
uniform float uGodrayStrength;
uniform float uVignette;
uniform float uChroma;
uniform float uGrain;
uniform float uSaturation;
uniform float uContrast;
uniform float uLift;
uniform float uTime;
uniform float uDamage;
uniform float uFlash;
uniform vec3 uFlashColor;
uniform float uFade;
uniform float uUnderwater;
uniform float uFxaa;
uniform float uExposure;
layout(location=0) out vec4 outColor;

${GLSL_COMMON}

vec3 fetch(vec2 uv){ return texture(uColor, uv).rgb; }

// small FXAA pass (luma based, 4 taps)
vec3 fxaa(vec2 uv){
  vec3 rgbM = fetch(uv);
  vec3 rgbNW = fetch(uv + vec2(-uTexel.x, -uTexel.y));
  vec3 rgbNE = fetch(uv + vec2( uTexel.x, -uTexel.y));
  vec3 rgbSW = fetch(uv + vec2(-uTexel.x,  uTexel.y));
  vec3 rgbSE = fetch(uv + vec2( uTexel.x,  uTexel.y));
  vec3 lw = vec3(0.299, 0.587, 0.114);
  float lNW = dot(rgbNW, lw), lNE = dot(rgbNE, lw), lSW = dot(rgbSW, lw), lSE = dot(rgbSE, lw), lM = dot(rgbM, lw);
  float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
  float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
  vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
  float dirReduce = max((lNW + lNE + lSW + lSE) * 0.25 * (1.0/8.0), 1.0/128.0);
  float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
  dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * uTexel;
  vec3 rgbA = 0.5 * (fetch(uv + dir * (1.0/3.0 - 0.5)) + fetch(uv + dir * (2.0/3.0 - 0.5)));
  vec3 rgbB = rgbA * 0.5 + 0.25 * (fetch(uv + dir * -0.5) + fetch(uv + dir * 0.5));
  float lB = dot(rgbB, lw);
  if (lB < lMin || lB > lMax) return rgbA;
  return rgbB;
}

void main(){
  vec2 uv = vUV;
  // chromatic aberration (radial)
  vec2 c = uv - 0.5;
  float r2 = dot(c,c);
  float ca = uChroma * r2;
  vec3 col;
  if (uChroma > 0.0){
    col.r = fetch(uv + c * ca * 1.0).r;
    col.g = fetch(uv).g;
    col.b = fetch(uv - c * ca * 1.0).b;
  } else {
    col = fetch(uv);
  }
  col *= uExposure;
  // bloom + godrays (added in HDR before tonemap so they roll off naturally)
  col += texture(uBloom, uv).rgb * uBloomStrength;
  col += texture(uGodray, uv).rgb * uGodrayStrength * vec3(1.0, 0.92, 0.78);
  // ambient occlusion
  float ao = texture(uAO, uv).r;
  col *= mix(1.0, ao, uAOStrength);
  // exposure + tonemap
  col = acesFilm(col);
  // colour grade
  col = mix(vec3(dot(col, vec3(0.2126, 0.7152, 0.0722))), col, uSaturation);
  col = (col - 0.5) * uContrast + 0.5;
  col = pow(max(col, vec3(0.0)), vec3(1.0/2.2));
  col = col * (1.0 - uLift) + uLift;
  // underwater tint
  if (uUnderwater > 0.0){
    col = mix(col, col * vec3(0.35,0.72,1.0) + vec3(0.0,0.05,0.12), uUnderwater);
    col += vec3(0.02,0.05,0.08) * uUnderwater;
  }
  // damage vignette + hit flash
  float vig = smoothstep(1.3, 0.25, length(c)*1.7);
  col *= mix(1.0, vig, uVignette);
  col = mix(col, vec3(1.0, 0.12, 0.06), uDamage * (0.35 + 0.3*sin(uTime*6.0)));
  col = mix(col, uFlashColor, uFlash);
  // vignette edges of the lens
  if (uFxaa > 0.5) col = fxaa(uv);
  // film grain (animated, blue-noise-ish)
  float g = texture(uNoise, uv * uResolution / 512.0 + vec2(uTime*0.37, uTime*0.29)).r - 0.5;
  col += g * uGrain;
  col = mix(col, vec3(0.0), uFade);
  outColor = vec4(col, 1.0);
}`;

const WATER_VS = `#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
layout(location=3) in vec4 aTangent;
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProj;
uniform float uTime;
uniform vec2 uWaveDirA;
uniform vec2 uWaveDirB;
out vec3 vWorld;
out vec2 vUV;
out vec3 vNormalW;
vec3 gerstner(vec2 p, out vec3 tangent, out vec3 binormal){
  vec3 disp = vec3(0.0);
  tangent = vec3(1.0,0.0,0.0);
  binormal = vec3(0.0,0.0,1.0);
  float t = uTime;
  vec2 d0 = normalize(uWaveDirA);
  vec2 d1 = normalize(uWaveDirB);
  vec2 d2 = normalize(uWaveDirA + uWaveDirB*0.6);
  for (int i=0;i<3;i++){
    vec2 d = d0;
    float amp = 0.42, len = 14.0, spd = 0.7;
    if (i == 1){ d = d1; amp = 0.22; len = 7.5; spd = 1.0; }
    else if (i == 2){ d = d2; amp = 0.10; len = 3.6; spd = 1.5; }
    float k = 6.28318/len;
    float f = k*(dot(d,p) - spd*t);
    disp.x += d.x * amp * cos(f);
    disp.z += d.y * amp * cos(f);
    disp.y += amp * sin(f);
    float da = amp * k * sin(f);
    tangent += vec3(-d.x*d.x*da, d.x*da, -d.x*d.y*da);
    binormal += vec3(-d.x*d.y*da, d.y*da, -d.y*d.y*da);
  }
  return disp;
}
void main(){
  vec3 world = (uModel * vec4(aPosition,1.0)).xyz;
  vec3 tangent, binormal;
  vec3 disp = gerstner(world.xz, tangent, binormal);
  world += disp;
  vNormalW = normalize(cross(binormal, tangent));
  if (vNormalW.y < 0.0) vNormalW = -vNormalW;
  vWorld = world;
  vUV = world.xz;
  gl_Position = uProj * uView * vec4(world,1.0);
}`;

const WATER_FS = `#version 300 es
precision highp float;
in vec3 vWorld;
in vec2 vUV;
in vec3 vNormalW;
uniform vec3 uCameraPos;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunIntensity;
uniform float uTime;
uniform sampler2D uReflection;
uniform sampler2D uRefraction;
uniform sampler2D uNormalMap;
uniform sampler2D uDepth;
uniform vec2 uResolution;
uniform float uNear;
uniform float uFar;
uniform vec3 uShallowColor;
uniform vec3 uDeepColor;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform float uFoam;
layout(location=0) out vec4 outColor;
${GLSL_COMMON}

float linearDepth(float d){
  float ndc = d*2.0-1.0;
  return (2.0*uNear*uFar)/(uFar+uNear - ndc*(uFar-uNear));
}
vec3 ripples(vec2 uv, float scale){
  vec3 n = texture(uNormalMap, uv*scale + vec2(uTime*0.007, uTime*0.005)).xyz * 2.0 - 1.0;
  n += texture(uNormalMap, uv*scale*1.7 - vec2(uTime*0.011, uTime*0.013)).xyz * 2.0 - 1.0;
  return normalize(vec3(n.x, n.y*0.6, n.z));
}
void main(){
  vec3 N = normalize(vNormalW);
  vec3 rn = ripples(vUV, 0.35);
  vec3 rn2 = ripples(vUV, 0.09);
  N = normalize(N + vec3(rn.x*0.5 + rn2.x*0.4, 0.0, rn.z*0.5 + rn2.z*0.4));
  vec3 V = normalize(uCameraPos - vWorld);
  float NoV = saturate(dot(N,V));
  vec2 suv = gl_FragCoord.xy / uResolution;
  float depth = texture(uDepth, suv).r;
  float sceneZ = linearDepth(depth);
  float surfaceZ = linearDepth(saturate(gl_FragCoord.z * 0.5 + 0.5));
  float waterDepth = max(0.0, sceneZ - surfaceZ);
  float depthFade = saturate(waterDepth / 6.0);
  // refraction
  vec2 distort = (rn.xz + rn2.xz * 0.6) * 0.035 * saturate(waterDepth*0.4);
  vec3 refr = texture(uRefraction, suv + distort).rgb;
  vec3 shallow = mix(uShallowColor, refr, saturate(depthFade*1.6));
  // reflection: planar RT (mirrored camera), falls back to fresnel-blended sky at grazing
  vec2 ruv = vec2(suv.x, suv.y);
  vec3 refl = texture(uReflection, ruv + distort*2.0).rgb;
  float fres = 0.02 + 0.98 * pow(1.0 - NoV, 5.0);
  vec3 color = mix(shallow, refl, fres);
  // sun specular
  vec3 H = normalize(V + normalize(uSunDir));
  float spec = pow(saturate(dot(N,H)), 320.0) * 3.0 + pow(saturate(dot(N,H)), 32.0) * 0.25;
  color += uSunColor * uSunIntensity * spec;
  // subsurface scattering on wave crests
  float sss = pow(saturate(1.0 - NoV), 3.0) * saturate(vWorld.y*0.1+0.4);
  color += uDeepColor * sss * 0.35 * uSunIntensity;
  // foam on crests and shore
  float crest = smoothstep(0.34, 0.5, vWorld.y - 0.0);
  float foam = saturate(crest * uFoam + smoothstep(0.6, 0.05, waterDepth) * uFoam * 0.8);
  float fn = texture(uNormalMap, vUV*0.7 + vec2(uTime*0.02)).r;
  color = mix(color, vec3(0.85,0.9,0.95) * (0.6 + fn*0.6), saturate(foam*0.55));
  // fog
  float dist = length(uCameraPos - vWorld);
  color = mix(color, uFogColor, saturate(1.0 - exp(-uFogDensity * dist * 1.3)));
  outColor = vec4(color, 1.0);
}`;

const SKY_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform mat4 uInvViewProj;
uniform vec3 uCameraPos;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunSize;
uniform float uTurbidity;
uniform float uSkyExposure;
uniform float uNight;
layout(location=0) out vec4 outColor;
${GLSL_HASH13}
${GLSL_COMMON}
${GLSL_SKY}
void main(){
  vec4 clip = vec4(vUV*2.0-1.0, 1.0, 1.0);
  vec4 world = uInvViewProj * clip;
  vec3 dir = normalize(world.xyz/world.w - uCameraPos);
  vec3 col = skyColor(dir, normalize(uSunDir), uSunColor, uSunSize, uTurbidity, uSkyExposure, uNight);
  outColor = vec4(col, 1.0);
}`;

const CUBE_SKY_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform mat4 uFaceViewProj;
uniform samplerCube uPrev;
uniform float uRoughness;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunSize;
uniform float uTurbidity;
uniform float uSkyExposure;
uniform float uNight;
uniform int uUseSky;
layout(location=0) out vec4 outColor;
${GLSL_HASH13}
${GLSL_COMMON}
${GLSL_SKY}
void main(){
  vec4 clip = vec4(vUV*2.0-1.0, 1.0, 1.0);
  vec4 w = uFaceViewProj * clip;
  vec3 dir = normalize(w.xyz / w.w);
  vec3 col;
  if (uUseSky == 1){
    col = skyColor(dir, normalize(uSunDir), uSunColor, uSunSize, uTurbidity, uSkyExposure, uNight);
  } else {
    // roughness prefilter: cone sampling of the source cube
    vec3 N = dir;
    vec3 up = abs(N.y) < 0.99 ? vec3(0.0,1.0,0.0) : vec3(1.0,0.0,0.0);
    vec3 T = normalize(cross(up, N));
    vec3 B = cross(N, T);
    float lod = uRoughness;
    float sa = 0.35 + uRoughness * 1.2;
    vec3 sum = vec3(0.0);
    const int NS = 24;
    for (int i=0;i<NS;i++){
      float a = (float(i)+0.5)/float(NS);
      float phi = a * 6.2831853 * 3.0;
      float theta = a * sa;
      vec3 d = normalize(N*cos(theta) + (T*cos(phi) + B*sin(phi))*sin(theta));
      float w = 1.0 - a*0.5;
      sum += textureLod(uPrev, d, lod + uRoughness*2.0).rgb * w;
    }
    col = sum / (float(NS) * 0.75);
  }
  outColor = vec4(col, 1.0);
}`;

// ---------------------------------------------------------------------------
//  Renderer
// ---------------------------------------------------------------------------
class Renderer {
  constructor(device, opts = {}) {
    this.device = device;
    this.quality = opts.quality || 'high';
    this.pixelRatio = opts.pixelRatio || 1;
    this.resScale = opts.resScale !== undefined ? opts.resScale : (this.quality === 'low' ? 0.62 : (this.quality === 'medium' ? 0.8 : 1.0));
    this.shadowMapSize = opts.shadowMapSize || (this.quality === 'low' ? 512 : (this.quality === 'medium' ? 1024 : 1536));
    this.shadowLayers = 7;      // 3 sun cascades + 4 spot lights
    this.maxPointLights = 12;
    this.maxSpotLights = 6;
    this.cascadeCount = this.quality === 'low' ? 2 : 3;
    this.enableSSAO = this.quality !== 'low';
    this.enableBloom = this.quality !== 'low';
    this.enableGodrays = true;
    this.enableWater = true;
    this.enableFXAA = true;
    this.bloomLevels = 5;
    this.exposure = 1.0;
    this.fs = new FullScreen(device);
    this.frame = 0;
    this._initShadows();
    this._initPrograms();
    this._initEnv();
    this.time = 0;
    this.stats = { drawCalls: 0, triangles: 0, shadowDraws: 0, lights: 0 };
    this._tmpMat = Mat4.create();
    this._tmpMat2 = Mat4.create();
    this._camPos = [0, 0, 0];
    this._dirs = { sun: [0, 1, 0] };
    this.lightOverrides = {};
    this.debugView = 0;
  }

  _initShadows() {
    const d = this.device, gl = d.gl;
    const size = this.shadowMapSize;
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, tex);
    gl.texImage3D(gl.TEXTURE_2D_ARRAY, 0, gl.DEPTH_COMPONENT24, size, size, this.shadowLayers, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
    const fbo = gl.createFramebuffer();
    this.shadowRT = {
      texture: tex, fbo, size, layers: this.shadowLayers, isCube: false, target: gl.TEXTURE_2D_ARRAY, isArray: true,
      shadowMatrix: new Float32Array(8 * 16), shadowTile: new Float32Array(8 * 4), texel: 1 / size,
    };
    this.shadowMatrices = [];
    for (let i = 0; i < 8; i++) this.shadowMatrices.push(Mat4.create());
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, null);
  }

  _initPrograms() {
    const d = this.device;
    this.skyProgram = new Program(d, FS_TRI_VS, SKY_FS, 'sky');
    this.cubeSkyProgram = new Program(d, FS_TRI_VS, CUBE_SKY_FS, 'cubepref');
    this.waterProgram = new Program(d, WATER_VS, WATER_FS, 'water');
    this.copyProgram = new Program(d, FS_TRI_VS, COPY_FS, 'copy');
    this.bloomPre = new Program(d, FS_TRI_VS, BLOOM_PREFILTER_FS, 'bloompre');
    this.bloomDown = new Program(d, FS_TRI_VS, BLOOM_DOWN_FS, 'bloomdown');
    this.bloomUp = new Program(d, FS_TRI_VS, BLOOM_UP_FS, 'bloomup');
    this.ssaoProgram = new Program(d, FS_TRI_VS, SSAO_FS, 'ssao');
    this.ssaoBlurProgram = new Program(d, FS_TRI_VS, SSAO_BLUR_FS, 'ssaoblur');
    this.godrayProgram = new Program(d, FS_TRI_VS, GODRAY_FS, 'godray');
    this.compositeProgram = new Program(d, FS_TRI_VS, COMPOSITE_FS, 'composite');
    // ssao kernel
    this.ssaoKernel = new Float32Array(16 * 3);
    for (let i = 0; i < 16; i++) {
      let x = Math.random() * 2 - 1, y = Math.random() * 2 - 1, z = Math.random();
      const l = Math.hypot(x, y, z) || 1;
      let scale = i / 16;
      scale = lerp(0.1, 1.0, scale * scale);
      this.ssaoKernel[i * 3] = x / l * scale;
      this.ssaoKernel[i * 3 + 1] = y / l * scale;
      this.ssaoKernel[i * 3 + 2] = z / l * scale;
    }
  }

  _initNoise() {
    const d = this.device, gl = d.gl, S = 64;
    const data = new Uint8Array(S * S * 4);
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const i = (y * S + x) * 4;
      const v = Math.random() * 255;
      data[i] = data[i + 1] = data[i + 2] = v; data[i + 3] = 255;
    }
    this.blueNoise = fromImageData(d, { width: S, height: S, data }, { mips: false, wrap: gl.REPEAT, aniso: 0 });
  }

  _initEnv() {
    const d = this.device;
    this._initNoise();
    this.envSize = 64;
    this.envSource = new CubeTarget(d, this.envSize, { hdr: true });
    this.envCube = new CubeTarget(d, this.envSize, { hdr: true });
    this.envCube.mipmap();
    this.envDirty = true;
    this.ambientSH = new Float32Array(27);
    this.ambientSHTarget = new Float32Array(27);
    this.envBlend = 1;
    this.fogDensity = 0.008;
  }

  resize(w, h) {
    const d = this.device;
    this.width = Math.max(2, Math.floor(w * this.resScale));
    this.height = Math.max(2, Math.floor(h * this.resScale));
    if (this.hdrRT) {
      this.hdrRT.resize(this.width, this.height);
      this.sceneCopy.resize(this.width, this.height);
      this.reflection.resize(Math.max(2, this.width >> 1), Math.max(2, this.height >> 1));
      for (let i = 0; i < this.bloomChain.length; i++) this.bloomChain[i].resize(Math.max(2, this.width >> (i + 1)), Math.max(2, this.height >> (i + 1)));
      this.aoRT.resize(Math.max(2, this.width >> 1), Math.max(2, this.height >> 1));
      this.aoBlurRT.resize(Math.max(2, this.width >> 1), Math.max(2, this.height >> 1));
      this.godrayRT.resize(Math.max(2, this.width >> 2), Math.max(2, this.height >> 2));
      return;
    }
    const d2 = d;
    this.hdrRT = new RenderTarget(d2, { width: this.width, height: this.height, hdr: true, depthTexture: true });
    this.sceneCopy = new RenderTarget(d2, { width: this.width, height: this.height, hdr: true, depth: true, depthTexture: true });
    this.reflection = new RenderTarget(d2, { width: Math.max(2, this.width >> 1), height: Math.max(2, this.height >> 1), hdr: true, depthTexture: true });
    this.aoRT = new RenderTarget(d2, { width: Math.max(2, this.width >> 1), height: Math.max(2, this.height >> 1), hdr: false, depth: false, filter: d2.gl.LINEAR });
    this.aoBlurRT = new RenderTarget(d2, { width: Math.max(2, this.width >> 1), height: Math.max(2, this.height >> 1), hdr: false, depth: false, filter: d2.gl.LINEAR });
    this.godrayRT = new RenderTarget(d2, { width: Math.max(2, this.width >> 2), height: Math.max(2, this.height >> 2), hdr: true, depth: false });
    this.bloomChain = [];
    for (let i = 0; i < this.bloomLevels; i++) {
      this.bloomChain.push(new RenderTarget(d2, { width: Math.max(2, this.width >> (i + 1)), height: Math.max(2, this.height >> (i + 1)), hdr: true, depth: false }));
    }
  }

  // ---- shadow map fitting -------------------------------------------------
  _cascadeSplit(distances, near, far, count) {
    const splits = [];
    const lambda = 0.6;
    for (let i = 1; i <= count; i++) {
      const p = i / count;
      const log = near * Math.pow(far / near, p);
      const lin = near + (far - near) * p;
      splits.push(lerp(lin, log, lambda));
    }
    return splits;
  }

  _fitCascade(cam, near, far, sunDir, out) {
    const corners = this._frustumCorners(cam, near, far);
    let cx = 0, cy = 0, cz = 0;
    for (const c of corners) { cx += c[0]; cy += c[1]; cz += c[2]; }
    cx /= 8; cy /= 8; cz /= 8;
    const center = [cx, cy, cz];
    // rotation-only view looking down the sun
    const up = Math.abs(sunDir[1]) > 0.98 ? [0, 0, 1] : [0, 1, 0];
    const eye = [cx + sunDir[0] * 100, cy + sunDir[1] * 100, cz + sunDir[2] * 100];
    Mat4.lookAt(this._tmpMat2, eye, center, up);
    let radius = 0;
    for (const c of corners) {
      const d = Math.hypot(c[0] - cx, c[1] - cy, c[2] - cz);
      radius = Math.max(radius, d);
    }
    radius = Math.ceil(radius * 16) / 16;
    const texelsPerUnit = this.shadowMapSize / (radius * 2);
    // snap the center to shadow texel grid
    const world = Mat4.create();
    Mat4.lookAt(world, [sunDir[0], sunDir[1], sunDir[2]], [0, 0, 0], up);
    const xz = [center[0] * world[0] + center[1] * world[4] + center[2] * world[8],
      center[0] * world[1] + center[1] * world[5] + center[2] * world[9]];
    const sx = Math.round(xz[0] * texelsPerUnit) / texelsPerUnit;
    const sy = Math.round(xz[1] * texelsPerUnit) / texelsPerUnit;
    const offX = sx - xz[0], offY = sy - xz[1];
    const snappedCenter = [
      center[0] + world[0] * offX + world[1] * offY,
      center[1] + world[4] * offX + world[5] * offY,
      center[2] + world[8] * offX + world[9] * offY,
    ];
    const depth = radius * 2 + 120;
    const eye2 = [snappedCenter[0] + sunDir[0] * depth * 0.5, snappedCenter[1] + sunDir[1] * depth * 0.5, snappedCenter[2] + sunDir[2] * depth * 0.5];
    Mat4.lookAt(out.view, eye2, snappedCenter, up);
    Mat4.ortho(out.proj, -radius, radius, -radius, radius, 1, depth);
    Mat4.mul(out.vp, out.proj, out.view);
    out.radius = radius;
    return out;
  }

  _frustumCorners(cam, near, far) {
    const inv = Mat4.invert(Mat4.create(), Mat4.mul(Mat4.create(), cam.projection, cam.view));
    const pts = [];
    for (let i = 0; i < 8; i++) {
      const ndc = [(i & 1) ? 1 : -1, (i & 2) ? 1 : -1, (i & 4) ? 1 : -1];
      const p = [0, 0, 0];
      Mat4.transformPoint(p, inv, ndc);
      pts.push(p);
    }
    return pts;
  }

  renderShadows(scene, camera) {
    const d = this.device, gl = d.gl;
    d.resetUnits();
    const sun = scene.sun;
    const layers = [];
    const cascadeSplits = this._cascadeSplit(null, camera.near, Math.min(camera.far, 220), this.cascadeCount);
    const frustumCorners = [];
    let prevSplit = camera.near;
    this.shadowCam = this.shadowCam || [];
    if (sun && sun.intensity > 0.01 && sun.castShadow !== false) {
      for (let i = 0; i < this.cascadeCount; i++) {
        const near = prevSplit, far = cascadeSplits[i];
        const c = this.shadowCam[i] || (this.shadowCam[i] = { view: Mat4.create(), proj: Mat4.create(), vp: Mat4.create() });
        this._fitCascade(camera, near, far, sun.direction, c);
        layers.push({ index: i, vp: c.vp });
        const f = new Frustum().fromMatrix(c.vp);
        c.frustum = f;
        c.far = far;
        prevSplit = far;
      }
    }
    this.cascadeSplits = cascadeSplits;
    // invalidate unused layers so the shader's range check rejects them
    for (let i = layers.length; i < 8; i++) this.shadowRT.shadowMatrix.fill(0, i * 16, i * 16 + 16);
    // spot lights with shadows
    const spots = scene.getShadowSpots(this.maxSpotLights);
    let layerIdx = this.cascadeCount;
    this.spotShadowLayers = new Map();
    for (const sp of spots) {
      if (layerIdx >= this.shadowLayers) break;
      const c = { view: Mat4.create(), proj: Mat4.create(), vp: Mat4.create() };
      const dir = sp.getForward([0, 0, 0]);
      const pos = sp.getWorldPosition([0, 0, 0]);
      const up = Math.abs(dir[1]) > 0.98 ? [0, 0, 1] : [0, 1, 0];
      Mat4.lookAt(c.view, pos, [pos[0] + dir[0], pos[1] + dir[1], pos[2] + dir[2]], up);
      const fov = Math.acos(clamp(sp.cosOuter, -1, 1)) * 2 * 1.25;
      Mat4.perspective(c.proj, clamp(fov, 0.1, 2.4), 1, 0.15, sp.range);
      Mat4.mul(c.vp, c.proj, c.view);
      c.frustum = new Frustum().fromMatrix(c.vp);
      layers.push({ index: layerIdx, vp: c.vp, spot: sp });
      this.spotShadowLayers.set(sp, layerIdx);
      layerIdx++;
    }
    // render each layer
    const shadowScale = 1 / Math.max(1, Math.floor(Math.sqrt(this.shadowLayers)));
    const tiles = [];
    for (let i = 0; i < 8; i++) { tiles.push([0, 0, 1, 1]); }
    // uniform 1x depth array: each layer is its own full tile
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowRT.fbo);
    gl.disable(gl.CULL_FACE);
    this.stats.shadowDraws = 0;
    for (const layer of layers) {
      gl.framebufferTextureLayer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, this.shadowRT.texture, 0, layer.index);
      gl.viewport(0, 0, this.shadowMapSize, this.shadowMapSize);
      gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.colorMask(false, false, false, false);
      this._renderDepthPass(scene, layer);
      gl.colorMask(true, true, true, true);
      // upload the mat4 for this layer into the shadow uniform block
      this.shadowRT.shadowMatrix.set(layer.vp, layer.index * 16);
      const t = this.shadowRT.shadowTile;
      t[layer.index * 4] = 0;
      t[layer.index * 4 + 1] = 0;
      t[layer.index * 4 + 2] = 1;
      t[layer.index * 4 + 3] = 1;
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.enable(gl.CULL_FACE);
  }

  _renderDepthPass(scene, layer) {
    const d = this.device, gl = d.gl;
    const casters = this._collectShadowCasters(scene, layer.frustum);
    for (const item of casters) {
      const mat = item.material;
      if (!mat || mat.castShadow === false || mat.unlit) continue;
      const p = mat.depthProgram(d);
      p.use();
      p.set('uShadowVP', layer.vp);
      p.set('uAlphaTest', mat.alphaTest || 0.5);
      p.set('uUVScale', mat.uvScale);
      if (mat.maps.albedo && mat.alphaTest > 0) p.tex('uAlbedoMap', mat.maps.albedo);
      if (item.instanced) {
        item.instances.upload();
        gl.bindVertexArray(item.instances.vaoFor(item.mesh));
        gl.drawElementsInstanced(gl.TRIANGLES, item.mesh.indexCount, item.mesh.indexType, 0, item.instances.count);
        d.drawCalls++; this.stats.shadowDraws++;
      } else {
        p.set('uModel', item.worldMatrix);
        item.mesh.draw();
        this.stats.shadowDraws++;
      }
    }
  }

  _collectShadowCasters(scene, frustum) {
    const out = [];
    for (const item of scene.renderList) {
      if (!item.material || item.material.castShadow === false) continue;
      if (item.material.transparent && !item.material.alphaTest) continue;
      if (item.skipShadow || item.tag === 'viewmodel') continue;
      if (frustum && item.worldBounds && !frustum.intersectsAABB(item.worldBounds)) continue;
      out.push(item);
    }
    return out;
  }

  // ---- environment --------------------------------------------------------
  updateEnvironment(scene, force = false) {
    const d = this.device, gl = d.gl;
    const sun = scene.sun;
    const key = [sun.direction[0], sun.direction[1], sun.direction[2], sun.color[0], sun.intensity].map(v => v.toFixed(4)).join(',');
    if (!force && !this.envDirty && key === this._envKey) return;
    this._envKey = key;
    // 1. project sky into CPU SH (drives diffuse IBL)
    SkyModel.params.sunDir = sun.direction;
    SkyModel.params.sunColor = [sun.color[0], sun.color[1], sun.color[2]];
    SkyModel.params.turbidity = scene.sky.turbidity;
    SkyModel.params.exposure = 1.0;
    SkyModel.params.night = scene.sky.night;
    const sh = SkyModel.computeSH();
    this.ambientSH.set(sh);
    // 2. render sky into a cubemap, then prefilter with cone sampling
    const size = this.envSize;
    const views = [
      [[1, 0, 0], [0, -1, 0]], [[-1, 0, 0], [0, -1, 0]],
      [[0, 1, 0], [0, 0, 1]], [[0, -1, 0], [0, 0, -1]],
      [[0, 0, 1], [0, -1, 0]], [[0, 0, -1], [0, -1, 0]],
    ];
    const proj = Mat4.perspective(Mat4.create(), Math.PI / 2, 1, 0.1, 10);
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.envSource.fbo);
    this.skyProgram.use();
    for (let i = 0; i < 6; i++) {
      const view = Mat4.lookAt(Mat4.create(), [0, 0, 0], views[i][0], views[i][1]);
      const vp = Mat4.mul(Mat4.create(), proj, view);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, this.envSource.cube.texture, 0);
      gl.viewport(0, 0, size, size);
      this._setSkyUniforms(this.skyProgram, scene, vp);
      this.fs.draw();
    }
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);
    // prefilter chain: increasingly rough cones, ping-pong between the two cubes
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    this.cubeSkyProgram.use();
    this.cubeSkyProgram.set('uUseSky', 0);
    this.cubeSkyProgram.set('uRoughness', 0.08);
    this.cubeSkyProgram.tex('uPrev', this.envSource.cube);
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.envCube.fbo);
    for (let i = 0; i < 6; i++) {
      const view = Mat4.lookAt(Mat4.create(), [0, 0, 0], views[i][0], views[i][1]);
      const vp = Mat4.mul(Mat4.create(), proj, view);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, this.envCube.cube.texture, 0);
      gl.viewport(0, 0, size, size);
      this.cubeSkyProgram.set('uFaceViewProj', vp);
      this.cubeSkyProgram.set('uRoughness', 0.0);
      this.fs.draw();
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.envCube.mipmap();
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);
    this.envDirty = false;
  }

  _setSkyUniforms(p, scene, vp) {
    const d = this.device;
    p.set('uSunDir', scene.sun.direction);
    p.set('uSunColor', scene.sun.color);
    p.set('uSunSize', scene.sun.angularSize || 0.0035);
    p.set('uTurbidity', scene.sky.turbidity);
    p.set('uSkyExposure', scene.sky.exposure);
    p.set('uNight', scene.sky.night);
    if (vp) {
      p.set('uInvViewProj', Mat4.invert(Mat4.create(), vp));
      p.set('uCameraPos', [0, 0, 0]);
    }
  }

  // ---- main render --------------------------------------------------------
  render(scene, camera, dt) {
    const d = this.device, gl = d.gl;
    this.time += dt;
    this.frame++;
    d.resetStats();
    this._drawn = (this._drawn || new Map());
    this._drawn.clear();
    if (!this.hdrRT) this.resize(d.canvas.width, d.canvas.height);
    camera.updateMatrices();
    this._camPos = camera.getWorldPosition([0, 0, 0]);

    // scene bookkeeping
    scene.updateWorldMatrix();
    scene.buildRenderList(camera);
    this._fog = scene.fog;
    this.setLightState(scene, camera);

    // shadows
    this.renderShadows(scene, camera);
    this.updateEnvironment(scene);

    // --- sky background ----------------------------------------------------
    this.hdrRT.bind();
    gl.clear(gl.DEPTH_BUFFER_BIT);   // fresh depth every frame
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    this.skyProgram.use();
    this._setSkyUniforms(this.skyProgram, scene, Mat4.mul(Mat4.create(), camera.projection, camera.view));
    this.skyProgram.set('uCameraPos', this._camPos);
    this.fs.draw();
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);

    // --- reflection pass (planar, mirrored camera) -------------------------
    if (this.enableWater && scene.water) {
      this._renderReflection(scene, camera);
    }

    // --- opaque (rebind the main target: the reflection pass moved it) -----
    this.hdrRT.bind();
    this._renderScenePass(scene, camera, 'opaque');
    // copy the resolved colour for refraction/SSR-ish use
    // resolve colour + depth into the copy target (single blit, no shader pass)
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, this.hdrRT.fbo);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, this.sceneCopy.fbo);
    gl.blitFramebuffer(0, 0, this.width, this.height, 0, 0, this.width, this.height, gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT, gl.NEAREST);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, null);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, null);
    // --- transparent + water ----------------------------------------------
    this.hdrRT.bind();
    if (this.enableWater && scene.water) this._renderWater(scene, camera);
    this._renderScenePass(scene, camera, 'transparent');

    // --- post --------------------------------------------------------------
    this._postProcess(scene, camera);

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.stats.drawCalls = d.drawCalls;
    this.stats.triangles = d.triangles;
    this.stats.lights = scene.pointLights.length + scene.spotLights.length;
    this.stats.drawn = Object.fromEntries(this._drawn);
  }

  _renderReflection(scene, camera) {
    const d = this.device, gl = d.gl;
    d.resetUnits();
    const water = scene.water;
    const y = water.level;
    const camPos = this._camPos;
    // mirrored camera: reflect position and forward over the plane y
    const reflPos = [camPos[0], 2 * y - camPos[1], camPos[2]];
    const fwd = camera.getForward([0, 0, 0]);
    const reflFwd = [fwd[0], -fwd[1], fwd[2]];
    const up = [0, 1, 0];
    const view = Mat4.lookAt(Mat4.create(), reflPos, [reflPos[0] + reflFwd[0], reflPos[1] + reflFwd[1], reflPos[2] + reflFwd[2]], up);
    const proj = Mat4.perspective(Mat4.create(), camera.fov, camera.aspect, camera.near, Math.min(camera.far, 300));
    const vp = Mat4.mul(Mat4.create(), proj, view);
    this.reflection.bind();
    gl.clear(gl.DEPTH_BUFFER_BIT | gl.COLOR_BUFFER_BIT);
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    this.skyProgram.use();
    this._setSkyUniforms(this.skyProgram, scene, vp);
    this.skyProgram.set('uCameraPos', reflPos);
    this.fs.draw();
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);
    // render the scene mirrored + clipped so nothing below the water is drawn
    const frustum = new Frustum().fromMatrix(vp);
    gl.enable(gl.BLEND);
    gl.disable(gl.BLEND);
    for (const item of scene.renderList) {
      if (!item.material || item.material.transparent) continue;
      if (item.skipReflection || item.waterExclude) continue;
      if (item.material.defines && item.material.defines.BILLBOARD) continue;
      if (item.isInstanced) { if (!frustum.intersectsSphere(item._worldCenter, item._worldRadius)) continue; }
      else if (!frustum.intersectsSphere(item._worldCenter, item._worldRadius)) continue;
      this._drawItem(item, proj, view, reflPos);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  _renderWater(scene, camera) {
    const d = this.device, gl = d.gl;
    d.resetUnits();
    const water = scene.water;
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.depthMask(true);
    const p = this.waterProgram;
    p.use();
    p.set('uModel', water.mesh.worldMatrix);
    p.set('uView', camera.view);
    p.set('uProj', camera.projection);
    p.set('uTime', this.time);
    p.set('uWaveDirA', water.waveDirA || [1, 0.3]);
    p.set('uWaveDirB', water.waveDirB || [-0.4, 1]);
    p.set('uCameraPos', this._camPos);
    p.set('uSunDir', scene.sun.direction);
    p.set('uSunColor', scene.sun.color);
    p.set('uSunIntensity', scene.sun.intensity);
    p.tex('uReflection', this.reflection.color);
    p.tex('uRefraction', this.sceneCopy.color);
    p.tex('uNormalMap', scene.waterNormalMap);
    p.tex('uDepth', this.sceneCopy.depthTex);
    p.set('uResolution', [this.width, this.height]);
    p.set('uNear', camera.near);
    p.set('uFar', camera.far);
    p.set('uShallowColor', water.shallow);
    p.set('uDeepColor', water.deep);
    p.set('uFogColor', scene.fog.color);
    p.set('uFogDensity', scene.fog.density);
    p.set('uFoam', water.foam);
    water.mesh.mesh.draw();
    gl.disable(gl.BLEND);
    gl.disable(gl.DEPTH_TEST);
    this.skyProgram.use(); // restore state consistency
    gl.enable(gl.DEPTH_TEST);
  }

  _renderScenePass(scene, camera, pass) {
    const d = this.device, gl = d.gl;
    const transparent = pass === 'transparent';
    if (transparent) {
      gl.enable(gl.BLEND);
      gl.depthMask(false);
      gl.disable(gl.CULL_FACE);
    } else {
      gl.disable(gl.BLEND);
      gl.depthMask(true);
      gl.enable(gl.CULL_FACE);
    }
    for (const item of scene.renderList) {
      if (!item.material) continue;
      if (!!item.material.transparent !== transparent) continue;
      this._drawItem(item, camera.projection, camera.view, this._camPos);
    }
    if (transparent) {
      gl.disable(gl.BLEND);
      gl.depthMask(true);
      gl.enable(gl.CULL_FACE);
    }
  }

  _drawItem(item, proj, view, camPos) {
    const d = this.device, gl = d.gl;
    d.resetUnits();
    const mat = item.material;
    const fog = this._fog || { color: [0.4,0.45,0.5], density: 0.004, height: 0, falloff: 0.04, sunAmount: 0.4 };
    if (mat.blending === 'additive') gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    else gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    if (mat.doubleSided || mat.transparent) gl.disable(gl.CULL_FACE); else gl.enable(gl.CULL_FACE);
    const extra = {};
    if (item.instanced) extra.INSTANCED = 1;
    if (mat.defines.BILLBOARD || mat.billboard) extra.BILLBOARD = 1;
    if (mat.receiveShadow) extra.RECEIVE_SHADOW = 1;
    if (mat.doubleSided) extra.TWO_SIDED = 1;
    if (item.clipPlane) extra.CLIP_PLANE = 1;
    const p = mat.program(d, extra);
    p.use();
    p.set('uModel', item.worldMatrix || Mat4.identity(this._tmpMat));
    p.set('uView', view);
    p.set('uProj', proj);
    p.set('uNormalMat', Mat3from4(this._normalBuf || (this._normalBuf = new Float32Array(9)), item.worldMatrix || Mat4.identity(this._tmpMat)));
    p.set('uCameraPos', camPos);
    p.set('uAlbedo', mat.color);
    p.set('uRoughness', mat.roughness);
    p.set('uMetalness', mat.metalness);
    p.set('uEmissive', mat.emissive);
    p.set('uEmissiveIntensity', mat.emissiveIntensity);
    p.set('uOpacity', mat.opacity * (item.opacity !== undefined ? item.opacity : 1));
    p.set('uAOIntensity', mat.aoIntensity);
    p.set('uNormalScale', mat.normalScale);
    p.set('uUVScale', mat.uvScale);
    p.set('uUVOffset', mat.uvOffset);
    p.set('uTime', this.time);
    p.set('uInstanceTint', mat.instanceTint);
    p.set('uDebugView', this.debugView || 0);
    p.set('uRim', mat.rim);
    p.set('uRimColor', mat.rimColor);
    // lighting state
    const L = this.lightState;
    p.set('uSunDir', L.sunDir);
    p.set('uSunColor', L.sunColor);
    p.set('uSunIntensity', L.sunIntensity);
    p.set('uSkyIntensity', L.skyIntensity);
    p.set('uEnvLod', 5.0);
    p.setArray('uAmbientSH', this.ambientSH);
    p.set('uAmbientBoost', L.ambientBoost);
    p.set('uShadowStrength', L.shadowStrength);
    p.set('uShadowNormalBias', this.shadowBias || 0.02);
    p.set('uShadowTexel', this.shadowRT.texel);
    p.set('uShadowSoftness', this.shadowSoftness || 1.0);
    p.set('uCascadeCount', this.cascadeCount);
    p.set('uCascadeSplits', this.cascadeSplits ? [this.cascadeSplits[0], this.cascadeSplits[1] || this.cascadeSplits[0], this.cascadeSplits[2] || 0] : [80, 160, 240]);
    p.set('uPointCount', L.pointCount);
    if (L.pointCount > 0) {
      p.setArray('uPointPos', L.pointPos);
      p.setArray('uPointColor', L.pointColor);
      p.setArray('uPointParams', L.pointParams);
    }
    p.set('uSpotCount', L.spotCount);
    if (L.spotCount > 0) {
      p.setArray('uSpotPos', L.spotPos);
      p.setArray('uSpotColor', L.spotColor);
      p.setArray('uSpotDirInner', L.spotDirInner);
      p.setArray('uSpotParams', L.spotParams);
    }
    p.setArray('uShadowMatrix', this.shadowRT.shadowMatrix);
    p.setArray('uShadowTile', this.shadowRT.shadowTile);
    p.tex('uShadowArray', this.shadowRT);
    p.set('uFogColor', fog.color);
    p.set('uFogDensity', fog.enabled === false ? 0.0 : fog.density);
    p.set('uFogHeight', fog.height);
    p.set('uFogFalloff', fog.falloff);
    p.set('uFogSunAmount', fog.sunAmount);
    // textures
    if (mat.maps.albedo) p.tex('uAlbedoMap', mat.maps.albedo);
    if (mat.maps.orm) p.tex('uOrmMap', mat.maps.orm);
    if (mat.maps.normal) p.tex('uNormalMap', mat.maps.normal);
    if (mat.maps.emissive) p.tex('uEmissiveMap', mat.maps.emissive);
    if (mat.splat) {
      if (mat.maps.splat) p.tex('uSplatMap', mat.maps.splat);
      if (mat.maps.layerA) p.tex('uLayerA', mat.maps.layerA);
      if (mat.maps.layerB) p.tex('uLayerB', mat.maps.layerB);
      if (mat.maps.layerC) p.tex('uLayerC', mat.maps.layerC);
      if (mat.maps.layerD) p.tex('uLayerD', mat.maps.layerD);
      p.set('uSplatScale', mat.splatScale);
    }
    p.tex('uEnvMap', this.envCube.cube);
    // draw
    if (this.validateSamplers) p.validateSamplers(d);
    if (item.instanced) {
      item.instances.upload();
      gl.bindVertexArray(item.instances.vaoFor(item.mesh));
      gl.drawElementsInstanced(gl.TRIANGLES, item.mesh.indexCount, item.mesh.indexType, 0, item.instances.count);
      d.drawCalls++;
    } else {
      item.mesh.draw();
      item.mesh.draw ? (this._drawn.set(item.name, (this._drawn.get(item.name) || 0) + 1)) : 0;
      this._drawn.set('#' + mat.name, (this._drawn.get('#' + mat.name) || 0) + 1);
      const v0 = d.triangles;
    }
  }

  setLightState(scene, camera) {
    const L = this.lightState || (this.lightState = {
      sunDir: [0, 1, 0], sunColor: [1, 1, 1], sunIntensity: 1, skyIntensity: 1, ambientBoost: 1,
      shadowStrength: 1, pointCount: 0, spotCount: 0,
      pointPos: new Float32Array(12 * 3), pointColor: new Float32Array(12 * 3), pointParams: new Float32Array(12 * 4),
      spotPos: new Float32Array(6 * 3), spotColor: new Float32Array(6 * 3), spotDirInner: new Float32Array(6 * 4), spotParams: new Float32Array(6 * 4),
    });
    L.sunDir = scene.sun.direction;
    L.sunColor = scene.sun.color;
    L.sunIntensity = this.debugNoSun ? 0 : scene.sun.intensity;
    L.skyIntensity = this.debugNoAmbient ? 0 : scene.sky.intensity;
    L.ambientBoost = this.debugNoAmbient ? 0 : scene.sky.ambientBoost;
    L.shadowStrength = scene.sun.shadowStrength;
    const camPos = this._camPos;
    // nearest point lights
    const pts = scene.pointLights.slice().sort((a, b) => {
      const pa = a.getWorldPosition([0, 0, 0]), pb = b.getWorldPosition([0, 0, 0]);
      return Vec3.dist2(pa, camPos) - Vec3.dist2(pb, camPos);
    }).slice(0, this.maxPointLights);
    L.pointCount = pts.length;
    for (let i = 0; i < pts.length; i++) {
      const lp = pts[i].getWorldPosition([0, 0, 0]);
      L.pointPos[i * 3] = lp[0]; L.pointPos[i * 3 + 1] = lp[1]; L.pointPos[i * 3 + 2] = lp[2];
      const c = pts[i].getColor();
      L.pointColor[i * 3] = c[0]; L.pointColor[i * 3 + 1] = c[1]; L.pointColor[i * 3 + 2] = c[2];
      L.pointParams[i * 4] = pts[i].range;
      L.pointParams[i * 4 + 1] = pts[i].intensity;
      L.pointParams[i * 4 + 2] = -1;
      L.pointParams[i * 4 + 3] = 0;
    }
    const spots = scene.spotLights.slice(0, this.maxSpotLights);
    L.spotCount = spots.length;
    for (let i = 0; i < spots.length; i++) {
      const lp = spots[i].getWorldPosition([0, 0, 0]);
      L.spotPos[i * 3] = lp[0]; L.spotPos[i * 3 + 1] = lp[1]; L.spotPos[i * 3 + 2] = lp[2];
      const c = spots[i].getColor();
      L.spotColor[i * 3] = c[0]; L.spotColor[i * 3 + 1] = c[1]; L.spotColor[i * 3 + 2] = c[2];
      const dir = spots[i].getForward([0, 0, 0]);
      L.spotDirInner[i * 4] = dir[0]; L.spotDirInner[i * 4 + 1] = dir[1]; L.spotDirInner[i * 4 + 2] = dir[2];
      L.spotDirInner[i * 4 + 3] = Math.cos(spots[i].innerAngle);
      L.spotParams[i * 4] = spots[i].range;
      L.spotParams[i * 4 + 1] = spots[i].intensity;
      L.spotParams[i * 4 + 3] = Math.cos(spots[i].outerAngle);
      L.spotParams[i * 4 + 2] = L.spotParams[i * 4 + 3];
      const layerIdx = this.spotShadowLayers && this.spotShadowLayers.get(spots[i]);
      L.spotParams[i * 4 + 3] = layerIdx !== undefined ? layerIdx : -1;
      L.spotParams[i * 4 + 2] = spots[i].cosOuter !== undefined ? spots[i].cosOuter : Math.cos(spots[i].outerAngle);
      L.spotDirInner[i * 4 + 3] = spots[i].cosInner !== undefined ? spots[i].cosInner : Math.cos(spots[i].innerAngle);
    }
    return L;
  }

  // ---- post processing ----------------------------------------------------
  _postProcess(scene, camera) {
    const d = this.device, gl = d.gl;
    this.setLightState(scene, camera);
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    d.resetUnits();
    // SSAO
    if (this.enableSSAO) {
      this.aoRT.bind();
      this.ssaoProgram.use();
      this.ssaoProgram.tex('uDepth', this.hdrRT.depthTex);
      this.ssaoProgram.set('uTexel', [1 / this.aoRT.width, 1 / this.aoRT.height]);
      this.ssaoProgram.set('uProj', camera.projection);
      this.ssaoProgram.set('uInvProj', Mat4.invert(Mat4.create(), camera.projection));
      this.ssaoProgram.setArray('uKernel', this.ssaoKernel);
      this.ssaoProgram.set('uRadius', 1.1);
      this.ssaoProgram.set('uBias', 0.035);
      this.ssaoProgram.set('uIntensity', 1.15);
      this.ssaoProgram.set('uNear', camera.near);
      this.ssaoProgram.set('uFar', camera.far);
      this.fs.draw();
      this.aoBlurRT.bind();
      this.ssaoBlurProgram.use();
      this.ssaoBlurProgram.tex('uTex', this.aoRT.color);
      this.ssaoBlurProgram.set('uTexel', [1 / this.aoRT.width, 1 / this.aoRT.height]);
      this.fs.draw();
    } else {
      this.aoBlurRT.bind();
      gl.clearColor(1, 1, 1, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    // bloom
    if (this.enableBloom) {
      this.bloomChain[0].bind();
      this.bloomPre.use();
      this.bloomPre.tex('uTex', this.hdrRT.color);
      this.bloomPre.set('uTexel', [1 / this.width, 1 / this.height]);
      this.bloomPre.set('uThreshold', 0.9);
      this.bloomPre.set('uSoftKnee', 0.6);
      this.bloomPre.set('uExposure', this.exposure);
      this.fs.draw();
      for (let i = 1; i < this.bloomChain.length; i++) {
        this.bloomChain[i].bind();
        this.bloomDown.use();
        this.bloomDown.tex('uTex', this.bloomChain[i - 1].color);
        this.bloomDown.set('uTexel', [1 / this.bloomChain[i - 1].width, 1 / this.bloomChain[i - 1].height]);
        this.fs.draw();
      }
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE);
      for (let i = this.bloomChain.length - 2; i >= 0; i--) {
        this.bloomChain[i].bind();
        this.bloomUp.use();
        this.bloomUp.tex('uTex', this.bloomChain[i + 1].color);
        this.bloomUp.set('uTexel', [1 / this.bloomChain[i + 1].width, 1 / this.bloomChain[i + 1].height]);
        this.bloomUp.set('uRadius', 1.2);
        this.fs.draw();
      }
      gl.disable(gl.BLEND);
    }
    // god rays
    if (this.enableGodrays) {
      this.godrayRT.bind();
      this.godrayProgram.use();
      const sunClip = this._projectSun(scene, camera);
      this.godrayProgram.tex('uTex', this.hdrRT.color);
      this.godrayProgram.tex('uDepth', this.hdrRT.depthTex);
      this.godrayProgram.set('uSunUV', [sunClip[0], sunClip[1]]);
      this.godrayProgram.set('uDensity', 0.9);
      this.godrayProgram.set('uDecay', 0.94);
      this.godrayProgram.set('uWeight', sunClip[2] ? 0.85 : 0.0);
      this.fs.draw();
    }
    // composite to the canvas
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, d.canvas.width, d.canvas.height);
    const p = this.compositeProgram;
    p.use();
    p.tex('uColor', this.hdrRT.color);
    p.tex('uBloom', this.enableBloom ? this.bloomChain[0].color : this.aoBlurRT.color);
    p.tex('uAO', this.aoBlurRT.color);
    p.tex('uGodray', this.godrayRT.color);
    p.tex('uNoise', this.blueNoise);
    p.set('uTexel', [1 / this.width, 1 / this.height]);
    p.set('uResolution', [this.width, this.height]);
    p.set('uBloomStrength', this.enableBloom ? (this.bloomStrength || 0.09) : 0.0);
    p.set('uAOStrength', this.enableSSAO ? (this.aoStrength || 0.55) : 0.0);
    p.set('uGodrayStrength', this.enableGodrays ? (this.godrayStrength || 0.85) : 0.0);
    p.set('uVignette', this.vignette !== undefined ? this.vignette : 0.35);
    p.set('uChroma', this.chroma !== undefined ? this.chroma : 0.0028);
    p.set('uGrain', this.grain !== undefined ? this.grain : 0.022);
    p.set('uSaturation', this.saturation !== undefined ? this.saturation : 1.06);
    p.set('uContrast', this.contrast !== undefined ? this.contrast : 1.05);
    p.set('uLift', this.lift !== undefined ? this.lift : 0.0);
    p.set('uTime', this.time);
    p.set('uDamage', this.damage || 0);
    p.set('uFlash', this.flash || 0);
    p.set('uFlashColor', this.flashColor || [1, 1, 1]);
    p.set('uFade', this.fade || 0);
    p.set('uUnderwater', this.underwater || 0);
    p.set('uFxaa', this.enableFXAA ? 1 : 0);
    p.set('uExposure', this.exposure);
    this.fs.draw();
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);
  }

  _projectSun(scene, camera) {
    const vp = Mat4.mul(Mat4.create(), camera.projection, camera.view);
    const far = 2000;
    const p = [this._camPos[0] + scene.sun.direction[0] * far, this._camPos[1] + scene.sun.direction[1] * far, this._camPos[2] + scene.sun.direction[2] * far];
    const clip = [vp[0] * p[0] + vp[4] * p[1] + vp[8] * p[2] + vp[12],
      vp[1] * p[0] + vp[5] * p[1] + vp[9] * p[2] + vp[13],
      vp[2] * p[0] + vp[6] * p[1] + vp[10] * p[2] + vp[14],
      vp[3] * p[0] + vp[7] * p[1] + vp[11] * p[2] + vp[15]];
    if (clip[3] <= 0.0001) return [0.5, 0.5, 0];
    const uv = [clip[0] / clip[3] * 0.5 + 0.5, clip[1] / clip[3] * 0.5 + 0.5];
    const visible = uv[0] > -0.2 && uv[0] < 1.2 && uv[1] > -0.2 && uv[1] < 1.2 ? 1 : 0;
    return [uv[0], uv[1], visible];
  }
}

function Mat3from4(out, m) {
  out[0] = m[0]; out[1] = m[1]; out[2] = m[2];
  out[3] = m[4]; out[4] = m[5]; out[5] = m[6];
  out[6] = m[8]; out[7] = m[9]; out[8] = m[10];
  return out;
}
