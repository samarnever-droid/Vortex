// ===========================================================================
//  AGER ENGINE  ·  10-gl  ·  WebGL2 device, shaders, meshes, render targets
// ===========================================================================

class Device {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    const attrs = {
      alpha: false, antialias: false, depth: true, stencil: false, premultipliedAlpha: false,
      preserveDrawingBuffer: !!opts.preserveDrawingBuffer, powerPreference: 'high-performance',
      desynchronized: false, failIfMajorPerformanceCaveat: false
    };
    const gl = canvas.getContext('webgl2', attrs);
    if (!gl) throw new Error('Ager requires WebGL2');
    this.gl = gl;
    this.isWebGL2 = true;
    // float / half float render support
    this.ext = {
      colorBufferFloat: gl.getExtension('EXT_color_buffer_float'),
      floatBlend: gl.getExtension('EXT_float_blend'),
      textureFilterAniso: gl.getExtension('EXT_texture_filter_anisotropic'),
      debugRenderer: gl.getExtension('WEBGL_debug_renderer_info'),
    };
    this.hdrFormat = this.ext.colorBufferFloat ? gl.RGBA16F : gl.RGBA8;
    this.hdrType = this.ext.colorBufferFloat ? gl.HALF_FLOAT : gl.UNSIGNED_BYTE;
    this.maxAniso = this.ext.textureFilterAniso ? gl.getParameter(this.ext.textureFilterAniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 1;
    this.renderer = this.ext.debugRenderer ? gl.getParameter(this.ext.debugRenderer.UNMASKED_RENDERER_WEBGL) : 'unknown';
    this.caps = {
      maxTextureSize: gl.getParameter(gl.MAX_TEXTURE_SIZE),
      maxSamples: gl.getParameter(gl.MAX_SAMPLES),
      maxVertexUniforms: gl.getParameter(gl.MAX_VERTEX_UNIFORM_VECTORS),
      maxFragmentUniforms: gl.getParameter(gl.MAX_FRAGMENT_UNIFORM_VECTORS),
      maxTextureUnits: gl.getParameter(gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
      maxDrawBuffers: gl.getParameter(gl.MAX_DRAW_BUFFERS),
    };
    this.drawCalls = 0; this.triangles = 0; this.stateChanges = 0;
    this._prog = null; this._vao = null; this._fbo = null;
    this._unitMap = new Map();   // WebGLTexture -> unit index (per draw)
    this._unitIdx = 0;
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
    gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
    gl.clearColor(0, 0, 0, 1);
  }
  useProgram(p) { if (this._prog !== p) { this.gl.useProgram(p.glProgram); this._prog = p; this.stateChanges++; } }
  bindVAO(v) { if (this._vao !== v) { this.gl.bindVertexArray(v); this._vao = v; this.stateChanges++; } }
  bindFBO(f, w, h) {
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, f ? f.fbo : null);
    this._fbo = f;
    if (w !== undefined) gl.viewport(0, 0, w, h);
  }
  resetStats() { this.drawCalls = 0; this.triangles = 0; this.stateChanges = 0; }
  // texture unit management: reset at the start of every draw so a material
  // with 15 maps plus the shadow array never runs out of units.
  resetUnits() { this._unitMap.clear(); this._unitIdx = 0; }
  unit(tex) {
    const gl = this.gl;
    const existing = this._unitMap.get(tex.texture);
    if (existing !== undefined) { gl.activeTexture(gl.TEXTURE0 + existing); return existing; }
    let u = this._unitIdx++;
    if (u >= this.caps.maxTextureUnits) {
      u = this.caps.maxTextureUnits - 1;
      if (!this._unitWarned) { this._unitWarned = true; console.warn('[ager] texture unit overflow — deduping on unit ' + u); }
    } else this._unitMap.set(tex.texture, u);
    gl.activeTexture(gl.TEXTURE0 + u);
    gl.bindTexture(tex.target || (tex.isCube ? gl.TEXTURE_CUBE_MAP : gl.TEXTURE_2D), tex.texture);
    return u;
  }
}

// --- shader ---------------------------------------------------------------
class Shader {
  constructor(gl, type, src, label) {
    this.gl = gl; this.source = src; this.label = label || 'shader';
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      const log = gl.getShaderInfoLog(s);
      const lines = src.split('\n').map((l, i) => `${String(i + 1).padStart(4)} | ${l}`).join('\n');
      console.error(`[ager] ${this.label} compile failed:\n${log}\n${lines}`);
      this.error = log;
    }
    this.shader = s;
  }
}

const _programCache = new Map();

class Program {
  constructor(device, vsSrc, fsSrc, label = 'program', defines = {}) {
    this.device = device; this.label = label;
    const gl = device.gl;
    const key = label + '|' + Object.entries(defines).map(([k, v]) => k + '=' + v).join(',') + '|' + vsSrc.length + fsSrc.length;
    const cached = _programCache.get(key);
    if (cached) { this.glProgram = cached.glProgram; this.uniforms = cached.uniforms; }
    else {
      // #define block is injected *after* the #version line (GLSL demands it first)
      const defs = Object.entries(defines).map(([k, v]) => `#define ${k} ${v}`).join('\n');
      const inject = (src) => {
        if (!defs) return src;
        const i = src.indexOf('\n');
        return src.slice(0, i + 1) + defs + '\n' + src.slice(i + 1);
      };
      const vs = new Shader(gl, gl.VERTEX_SHADER, inject(vsSrc), label + '.vs');
      const fs = new Shader(gl, gl.FRAGMENT_SHADER, inject(fsSrc), label + '.fs');
      const p = gl.createProgram();
      gl.attachShader(p, vs.shader); gl.attachShader(p, fs.shader);
      gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
        console.error(`[ager] link failed (${label}):`, gl.getProgramInfoLog(p));
      }
      this.glProgram = p;
      this.uniforms = new Map();
      const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
      for (let i = 0; i < n; i++) {
        const info = gl.getActiveUniform(p, i);
        let name = info.name.replace(/\[0\]$/, '');
        const loc = gl.getUniformLocation(p, info.name);
        this.uniforms.set(name, { loc, type: info.type, size: info.size });
      }
      _programCache.set(key, { glProgram: p, uniforms: this.uniforms });
    }
    this._textureUnits = new Map();
  }
  use() { this.device.useProgram(this); return this; }
  // generic setter with type inference
  set(name, value) {
    const u = this.uniforms.get(name);
    if (!u) return this;
    const gl = this.device.gl, loc = u.loc;
    switch (u.type) {
      case gl.FLOAT: gl.uniform1f(loc, value); break;
      case gl.FLOAT_VEC2: gl.uniform2fv(loc, value); break;
      case gl.FLOAT_VEC3: gl.uniform3fv(loc, value); break;
      case gl.FLOAT_VEC4: gl.uniform4fv(loc, value); break;
      case gl.INT: case gl.BOOL: case gl.SAMPLER_2D: case gl.SAMPLER_CUBE: case gl.SAMPLER_2D_SHADOW: case gl.SAMPLER_2D_ARRAY:
        gl.uniform1i(loc, value); break;
      case gl.INT_VEC2: gl.uniform2iv(loc, value); break;
      case gl.INT_VEC3: gl.uniform3iv(loc, value); break;
      case gl.INT_VEC4: gl.uniform4iv(loc, value); break;
      case gl.FLOAT_MAT3: gl.uniformMatrix3fv(loc, false, value); break;
      case gl.FLOAT_MAT4: gl.uniformMatrix4fv(loc, false, value); break;
      case gl.FLOAT_MAT3x4: gl.uniformMatrix3x4fv(loc, false, value); break;
      case gl.FLOAT_MAT4x3: gl.uniformMatrix4x3fv(loc, false, value); break;
      case gl.FLOAT_VEC3 + 0x1000: break;
      default:
        if (Array.isArray(value) || value instanceof Float32Array) {
          if (value.length === 2) gl.uniform2fv(loc, value);
          else if (value.length === 3) gl.uniform3fv(loc, value);
          else if (value.length === 4) gl.uniform4fv(loc, value);
          else if (value.length === 9) gl.uniformMatrix3fv(loc, false, value);
          else if (value.length === 16) gl.uniformMatrix4fv(loc, false, value);
          else gl.uniform1fv(loc, value);
        } else gl.uniform1f(loc, value);
    }
    return this;
  }
  setArray(name, value) {
    const u = this.uniforms.get(name);
    if (!u) return this;
    if (value && value.length !== undefined) {
      const per = { 5126: 1, 35664: 2, 35665: 3, 35666: 4, 5124: 1, 35667: 2, 35668: 3, 35669: 4, 35676: 16 }[u.type] || 1;
      const expect = per * (u.size > 1 ? u.size : 1);
      if (value.length !== expect && value.length !== per) {
        console.warn(`[ager] uniform ${name}: got ${value.length} floats, expected ${expect} (type ${u.type} size ${u.size})`);
      }
    }
    const gl = this.device.gl;
    switch (u.type) {
      case gl.FLOAT: gl.uniform1fv(u.loc, value); break;
      case gl.FLOAT_VEC2: gl.uniform2fv(u.loc, value); break;
      case gl.FLOAT_VEC3: gl.uniform3fv(u.loc, value); break;
      case gl.FLOAT_VEC4: gl.uniform4fv(u.loc, value); break;
      case gl.INT: case gl.BOOL: gl.uniform1iv(u.loc, value); break;
      case gl.INT_VEC2: gl.uniform2iv(u.loc, value); break;
      case gl.INT_VEC3: gl.uniform3iv(u.loc, value); break;
      case gl.INT_VEC4: gl.uniform4iv(u.loc, value); break;
      case gl.FLOAT_MAT4: gl.uniformMatrix4fv(u.loc, false, value); break;
      default: gl.uniform1fv(u.loc, value);
    }
    return this;
  }
  // dev helper: report samplers bound to the same unit with different targets
  validateSamplers(device) {
    const gl = device.gl;
    const used = new Map();
    for (const [name, u] of this.uniforms) {
      if (u.type !== gl.SAMPLER_2D && u.type !== gl.SAMPLER_CUBE && u.type !== gl.SAMPLER_2D_ARRAY && u.type !== gl.SAMPLER_2D_SHADOW && u.type !== gl.SAMPLER_2D_ARRAY_SHADOW) continue;
      const unit = gl.getUniform(this.glProgram, u.loc);
      const kind = u.type === gl.SAMPLER_CUBE ? 'cube' : (u.type === gl.SAMPLER_2D_ARRAY || u.type === gl.SAMPLER_2D_ARRAY_SHADOW ? 'array' : '2d');
      const prev = used.get(unit);
      if (prev && prev.kind !== kind) {
        const all = [...this.uniforms].filter(([n, uu]) => uu.type === gl.SAMPLER_2D || uu.type === gl.SAMPLER_CUBE || uu.type === gl.SAMPLER_2D_ARRAY || uu.type === gl.SAMPLER_2D_SHADOW || uu.type === gl.SAMPLER_2D_ARRAY_SHADOW)
          .map(([n, uu]) => `${n}=${gl.getUniform(this.glProgram, uu.loc)}`);
        console.warn(`[ager] sampler conflict in ${this.label}: ${prev.name}(${prev.kind}) and ${name}(${kind}) share unit ${unit} :: ${all.join(' ')}`);
      }
      used.set(unit, { name, kind });
    }
  }

  // bind a texture object {texture,target} to a named sampler
  tex(name, texObj) {
    if (!texObj) return this;
    const u = this.uniforms.get(name);
    if (!u) return this;
    const unit = this.device.unit(texObj);
    this.device.gl.uniform1i(u.loc, unit);
    return this;
  }
}

// --- GPU mesh -------------------------------------------------------------
class GPUMesh {
  constructor(device, geometry, opts = {}) {
    this.device = device; this.geometry = geometry;
    const gl = device.gl;
    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);
    this.buffers = [];
    const attrs = opts.attributes || ['position', 'normal', 'uv', 'tangent'];
    for (const name of attrs) {
      const data = geometry[name];
      if (!data) continue;
      const loc = opts.locations ? opts.locations[name] : GPUMesh.LOCATIONS[name];
      if (loc === undefined) continue;
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      const size = { position: 3, normal: 3, uv: 2, uv2: 2, tangent: 4, color: 4, joints: 4, weights: 4 }[name] || opts.sizes?.[name] || 3;
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
      this.buffers.push(buf);
    }
    if (geometry.index) {
      this.indexBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, geometry.index, gl.STATIC_DRAW);
      this.indexCount = geometry.index.length;
      this.indexType = geometry.index instanceof Uint32Array ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
    } else {
      this.indexCount = geometry.position.length / 3;
      this.indexType = gl.UNSIGNED_SHORT;
    }
    gl.bindVertexArray(null);
    this.bounds = geometry.bounds || computeBounds(geometry.position);
  }
  draw(instanceCount = 0) {
    const gl = this.device.gl;
    const prim = this.geometry.primitive || gl.TRIANGLES;
    this.device.bindVAO(this.vao);
    if (this.indexBuffer) {
      gl.drawElementsInstanced(prim, this.indexCount, this.indexType, 0, Math.max(1, instanceCount));
      this.device.triangles += (this.indexCount / 3) * Math.max(1, instanceCount);
    } else {
      gl.drawArraysInstanced(prim, 0, this.indexCount, Math.max(1, instanceCount));
      this.device.triangles += (this.indexCount / 3) * Math.max(1, instanceCount);
    }
    this.device.drawCalls++;
  }
  dispose() {
    const gl = this.device.gl;
    for (const b of this.buffers) gl.deleteBuffer(b);
    if (this.indexBuffer) gl.deleteBuffer(this.indexBuffer);
    gl.deleteVertexArray(this.vao);
  }
}
GPUMesh.LOCATIONS = { position: 0, normal: 1, uv: 2, tangent: 3, uv2: 4, color: 5, joints: 6, weights: 7, instanceMat: 8, instanceData: 12 };

// --- dynamic instance buffer (for instanced rendering) ---------------------
class InstanceBuffer {
  constructor(device, capacity = 256, floatsPerInstance = 16) {
    this.device = device; this.capacity = capacity; this.fpi = floatsPerInstance;
    this.data = new Float32Array(capacity * floatsPerInstance);
    this.count = 0;
    const gl = device.gl;
    this.buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.data.byteLength, gl.DYNAMIC_DRAW);
    this.vaos = [];
  }
  // one VAO per source mesh (attributes bound to that mesh's buffers)
  vaoFor(mesh) {
    let v = this.vaos.find(v => v.mesh === mesh);
    if (v) return v.vao;
    const gl = this.device.gl;
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    // re-bind mesh attribute buffers
    const attrs = ['position', 'normal', 'uv', 'tangent'];
    let bi = 0;
    for (const name of attrs) {
      if (!mesh.geometry[name]) continue;
      const loc = GPUMesh.LOCATIONS[name];
      const buf = mesh.buffers[bi++]; // buffers added in same order
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      const size = { position: 3, normal: 3, uv: 2, tangent: 4 }[name];
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
    }
    if (mesh.indexBuffer) { gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indexBuffer); }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    const stride = this.fpi * 4;
    for (let i = 0; i < 4; i++) {
      const loc = GPUMesh.LOCATIONS.instanceMat + i;
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 4, gl.FLOAT, false, stride, i * 16);
      gl.vertexAttribDivisor(loc, 1);
    }
    if (this.fpi >= 20) {
      const loc = GPUMesh.LOCATIONS.instanceData;
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 4, gl.FLOAT, false, stride, 64);
      gl.vertexAttribDivisor(loc, 1);
    }
    gl.bindVertexArray(null);
    const rec = { mesh, vao };
    this.vaos.push(rec);
    return vao;
  }
  upload() {
    const gl = this.device.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.data, 0, this.count * this.fpi);
  }
  clear() { this.count = 0; }
  push(m) { // m: mat4 (16 floats), optional extra vec4
    if (this.count >= this.capacity) this.grow();
    const o = this.count * this.fpi;
    this.data.set(m, o);
    this.count++;
  }
  pushMat(m, extra) {
    if (this.count >= this.capacity) this.grow();
    const o = this.count * this.fpi;
    this.data.set(m, o);
    if (extra && this.fpi > 16) this.data.set(extra, o + 16);
    this.count++;
  }
  grow() {
    this.capacity *= 2;
    const nd = new Float32Array(this.capacity * this.fpi);
    nd.set(this.data); this.data = nd;
    const gl = this.device.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.data.byteLength, gl.DYNAMIC_DRAW);
  }
  draw(mesh, count = this.count) {
    if (count <= 0) return;
    const gl = this.device.gl;
    this.upload();
    const vao = this.vaoFor(mesh);
    this.device.bindVAO(vao);
    const prim = mesh.geometry.primitive || gl.TRIANGLES;
    if (mesh.indexBuffer) {
      gl.drawElementsInstanced(prim, mesh.indexCount, mesh.indexType, 0, count);
      this.device.triangles += (mesh.indexCount / 3) * count;
    } else {
      gl.drawArraysInstanced(prim, 0, mesh.indexCount, count);
      this.device.triangles += (mesh.indexCount / 3) * count;
    }
    this.device.drawCalls++;
  }
}

// --- textures -------------------------------------------------------------
function createTexture(device, opts = {}) {
  const gl = device.gl;
  const tex = gl.createTexture();
  const target = opts.cube ? gl.TEXTURE_CUBE_MAP : gl.TEXTURE_2D;
  gl.bindTexture(target, tex);
  const w = opts.width || 1, h = opts.height || 1;
  const internal = opts.internalFormat !== undefined ? opts.internalFormat : (opts.hdr ? device.hdrFormat : gl.RGBA8);
  const format = opts.format || gl.RGBA;
  const type = opts.type || (opts.hdr ? device.hdrType : gl.UNSIGNED_BYTE);
  if (opts.cube) {
    for (let i = 0; i < 6; i++) gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, internal, w, h, 0, format, type, null);
  } else {
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, w, h, 0, format, type, opts.data || null);
  }
  const filter = opts.filter || gl.LINEAR;
  gl.texParameteri(target, gl.TEXTURE_MIN_FILTER, opts.mips ? (opts.mipFilter || gl.LINEAR_MIPMAP_LINEAR) : filter);
  gl.texParameteri(target, gl.TEXTURE_MAG_FILTER, filter);
  const wrap = opts.wrap || gl.REPEAT;
  gl.texParameteri(target, gl.TEXTURE_WRAP_S, wrap);
  gl.texParameteri(target, gl.TEXTURE_WRAP_T, wrap);
  if (opts.cube) gl.texParameteri(target, gl.TEXTURE_WRAP_R, wrap);
  if (opts.mips) gl.generateMipmap(target);
  if (opts.compare) {
    gl.texParameteri(target, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(target, gl.TEXTURE_COMPARE_FUNC, opts.compareFunc || gl.LEQUAL);
  }
  if (device.maxAniso > 1 && opts.aniso) gl.texParameterf(target, device.ext.textureFilterAniso.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(opts.aniso, device.maxAniso));
  gl.bindTexture(target, null);
  return { texture: tex, width: w, height: h, isCube: !!opts.cube, target, mips: !!opts.mips };
}

function fromImageData(device, img, opts = {}) {
  const gl = device.gl;
  if (!img || !(img.width > 0)) throw new Error('fromImageData: needs an image-like object with width/height');
  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  const internal = opts.srgb ? gl.SRGB8_ALPHA8 : gl.RGBA8;
  gl.texImage2D(gl.TEXTURE_2D, 0, internal, img.width, img.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, img.data);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, opts.mips === false ? gl.LINEAR : gl.LINEAR_MIPMAP_LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  const wrap = opts.wrap || gl.REPEAT;
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
  if (opts.mips !== false) gl.generateMipmap(gl.TEXTURE_2D);
  if (device.maxAniso > 1 && opts.aniso !== 0) gl.texParameterf(gl.TEXTURE_2D, device.ext.textureFilterAniso.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(opts.aniso || 8, device.maxAniso));
  gl.bindTexture(gl.TEXTURE_2D, null);
  return { texture: tex, width: img.width, height: img.height, isCube: false, target: gl.TEXTURE_2D };
}

class RenderTarget {
  constructor(device, opts = {}) {
    this.device = device;
    const gl = device.gl;
    this.width = opts.width || 1; this.height = opts.height || 1;
    this.depth = opts.depth !== false;
    this.depthTexture = !!opts.depthTexture;
    this.hdr = opts.hdr !== false;
    this.samples = opts.samples | 0;
    this.fbo = gl.createFramebuffer();
    this.color = opts.noColor ? null : createTexture(device, {
      width: this.width, height: this.height, hdr: this.hdr,
      filter: opts.filter || gl.LINEAR, wrap: opts.wrap || gl.CLAMP_TO_EDGE,
      internalFormat: opts.internalFormat, format: opts.format, type: opts.type,
    });
    this.attachments = this.color ? [this.color] : [];
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    if (this.color) gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.color.texture, 0);
    if (opts.extraColors) {
      for (let i = 0; i < opts.extraColors.length; i++) {
        const t = createTexture(device, Object.assign({ width: this.width, height: this.height, filter: gl.NEAREST, wrap: gl.CLAMP_TO_EDGE }, opts.extraColors[i]));
        this.attachments.push(t);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0 + 1 + i, gl.TEXTURE_2D, t.texture, 0);
        if (i + 1 >= device.caps.maxDrawBuffers) break;
      }
      const bufs = this.attachments.map((_, i) => gl.COLOR_ATTACHMENT0 + i);
      gl.drawBuffers(bufs);
    }
    if (this.depthTexture) {
      this.depthTex = createTexture(device, {
        width: this.width, height: this.height, internalFormat: gl.DEPTH_COMPONENT24, format: gl.DEPTH_COMPONENT,
        type: gl.UNSIGNED_INT, filter: gl.NEAREST, hdr: false
      });
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.depthTex.texture, 0);
    } else if (this.depth) {
      this.depthBuffer = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, this.depthBuffer);
      gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, this.width, this.height);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.depthBuffer);
    }
    this.check('RT');
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  check(label) {
    const gl = this.device.gl;
    const st = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
    if (st !== gl.FRAMEBUFFER_COMPLETE) console.warn(`[ager] incomplete framebuffer (${label})`, st.toString(16));
  }
  resize(w, h) {
    if (w === this.width && h === this.height) return this;
    const gl = this.device.gl;
    this.width = w; this.height = h;
    gl.bindTexture(gl.TEXTURE_2D, this.color.texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, this.hdr ? this.device.hdrFormat : gl.RGBA8, w, h, 0, gl.RGBA, this.hdr ? this.device.hdrType : gl.UNSIGNED_BYTE, null);
    for (let i = 1; i < this.attachments.length; i++) {
      const a = this.attachments[i];
      gl.bindTexture(gl.TEXTURE_2D, a.texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    }
    if (this.depthTex) {
      gl.bindTexture(gl.TEXTURE_2D, this.depthTex.texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, w, h, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
      this.depthTex.width = w; this.depthTex.height = h;
    } else if (this.depthBuffer) {
      gl.bindRenderbuffer(gl.RENDERBUFFER, this.depthBuffer);
      gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h);
    }
    this.color.width = w; this.color.height = h;
    return this;
  }
  bind() { const gl = this.device.gl; gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo); this.device._fbo = this; gl.viewport(0, 0, this.width, this.height); return this; }
  dispose() {
    const gl = this.device.gl;
    gl.deleteFramebuffer(this.fbo);
    if (this.color) gl.deleteTexture(this.color.texture);
    if (this.depthTex) gl.deleteTexture(this.depthTex.texture);
    if (this.depthBuffer) gl.deleteRenderbuffer(this.depthBuffer);
  }
}

class CubeTarget {
  constructor(device, size, opts = {}) {
    this.device = device; this.size = size;
    const gl = device.gl;
    this.cube = createTexture(device, { cube: true, width: size, height: size, hdr: opts.hdr !== false, mips: false, filter: opts.filter || gl.LINEAR });
    this.fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    const rb = gl.createRenderbuffer();
    gl.bindRenderbuffer(gl.RENDERBUFFER, rb);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, size, size);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, rb);
    this.depthBuffer = rb;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  face(i) {
    const gl = this.device.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, this.cube.texture, 0);
    gl.viewport(0, 0, this.size, this.size);
    return this;
  }
  mipmap() {
    const gl = this.device.gl;
    gl.bindTexture(gl.TEXTURE_CUBE_MAP, this.cube.texture);
    gl.generateMipmap(gl.TEXTURE_CUBE_MAP);
    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    this.cube.mips = true;
  }
}

function computeBounds(position) {
  const min = [1e9, 1e9, 1e9], max = [-1e9, -1e9, -1e9];
  for (let i = 0; i < position.length; i += 3) {
    for (let k = 0; k < 3; k++) { const v = position[i + k]; if (v < min[k]) min[k] = v; if (v > max[k]) max[k] = v; }
  }
  return new AABB(min, max);
}

// --- fullscreen triangle ---------------------------------------------------
class FullScreen {
  constructor(device) {
    this.device = device;
    const gl = device.gl;
    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
  }
  draw() {
    const gl = this.device.gl;
    this.device.bindVAO(this.vao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    this.device.drawCalls++;
  }
}

const FS_TRI_VS = `#version 300 es
precision highp float;
layout(location=0) in vec2 aPos;
out vec2 vUV;
void main(){ vUV = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }`;
