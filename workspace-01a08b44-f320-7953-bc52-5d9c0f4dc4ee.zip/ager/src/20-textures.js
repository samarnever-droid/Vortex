// ===========================================================================
//  AGER ENGINE  ·  20-textures  ·  procedural texture lab (zero assets)
//  Every texel in Ager is generated on the CPU at boot. No downloads, no
//  asset folder, no CORS, no broken URLs. A whole game that is one file.
//
//  Output convention (matches the shader's sampler contract):
//    albedo : RGBA8 (sRGB)   rgb = base colour
//    orm    : RGBA8 (linear) R = ambient occlusion, G = roughness,
//                            B = metalness, A = height
//    normal : RGBA8 (linear) tangent space normal map (rgb = xyz remapped)
//    emiss  : RGBA8 (sRGB)   rgb = emission
// ===========================================================================

class TexData {
  constructor(w, h) { this.width = w; this.height = h; this.data = new Uint8Array(w * h * 4); this.srgb = false; }
  idx(x, y) { return ((y & (this.height - 1)) * this.width + (x & (this.width - 1))) * 4; }
  put(i, r, g, b, a) { this.data[i] = r; this.data[i + 1] = g; this.data[i + 2] = b; this.data[i + 3] = a; }
  get(x, y) { const i = this.idx(x, y); return [this.data[i], this.data[i + 1], this.data[i + 2], this.data[i + 3]]; }
  toImage() {
    return { width: this.width, height: this.height, data: new Uint8ClampedArray(this.data) };
  }
}

// --- tileable noise --------------------------------------------------------
function hash2t(x, y, px, py) { return hash2(mod(x, px), mod(y, py)); }
function noise2t(x, y, px, py) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2t(xi, yi, px, py), b = hash2t(xi + 1, yi, px, py);
  const c = hash2t(xi, yi + 1, px, py), d = hash2t(xi + 1, yi + 1, px, py);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
function fbm2t(u, v, freq, oct = 4, gain = 0.5, lac = 2) {
  let s = 0, n = 0, a = 0.5, f = freq;
  for (let i = 0; i < oct; i++) {
    s += a * noise2t(u * f, v * f, Math.round(f), Math.round(f));
    n += a; a *= gain; f *= lac;
  }
  return s / n;
}
function worleyT(u, v, cells, seed = 0) {
  const x = u * cells, y = v * cells;
  const xi = Math.floor(x), yi = Math.floor(y);
  let best = 1e9, second = 1e9, id = 0;
  for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
    const cx = xi + i, cy = yi + j;
    const wx = mod(cx, cells), wy = mod(cy, cells);
    const px = cx + hash2(wx + seed * 13.7, wy - seed * 7.3);
    const py = cy + hash2(wx - seed * 3.1, wy + seed * 5.9);
    const d = (px - x) * (px - x) + (py - y) * (py - y);
    if (d < best) { second = best; best = d; id = wx * 131 + wy; } else if (d < second) second = d;
  }
  return { f1: Math.sqrt(best), f2: Math.sqrt(second), edge: Math.sqrt(second) - Math.sqrt(best), id: hash1(id) };
}

const TexLab = {
  cache: new Map(),
  _size: 256,

  make(name, size, fn) {
    const key = name + size;
    if (this.cache.has(key)) return this.cache.get(key);
    const w = size, h = size;
    const albedo = new TexData(w, h), orm = new TexData(w, h), normal = new TexData(w, h), emiss = new TexData(w, h);
    albedo.srgb = true; emiss.srgb = true;
    const hgt = new Float32Array(w * h);
    const ctx = { w, h, hgt };
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const u = x / w, v = y / h;
        const i = (y * w + x) * 4;
        const o = { r: 0.5, g: 0.5, b: 0.5, rough: 0.6, metal: 0, ao: 1, height: 0.5, em: [0, 0, 0], alpha: 1 };
        fn(u, v, x, y, o, ctx);
        hgt[y * w + x] = o.height;
        const lin = (c) => clamp(Math.pow(clamp(c, 0, 1), 1 / 2.2), 0, 1);
        albedo.put(i, o.r * 255, o.g * 255, o.b * 255, o.alpha * 255);
        orm.put(i, o.ao * 255, o.rough * 255, o.metal * 255, o.height * 255);
        emiss.put(i, lin(o.em[0]) * 255, lin(o.em[1]) * 255, lin(o.em[2]) * 255, 255);
      }
    }
    this.buildNormal(normal, hgt, w, h, 2.4);
    const out = { albedo, orm, normal, emiss, name, size };
    this.cache.set(key, out);
    return out;
  },

  buildNormal(target, hgt, w, h, strength) {
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const xl = (x - 1 + w) % w, xr = (x + 1) % w, yu = (y - 1 + h) % h, yd = (y + 1) % h;
        const dx = (hgt[y * w + xr] - hgt[y * w + xl]) * strength * w / 64;
        const dy = (hgt[yd * w + x] - hgt[yu * w + x]) * strength * h / 64;
        let nx = -dx, ny = -dy, nz = 1;
        const l = Math.hypot(nx, ny, nz);
        nx /= l; ny /= l; nz /= l;
        const i = (y * w + x) * 4;
        target.put(i, (nx * 0.5 + 0.5) * 255, (ny * 0.5 + 0.5) * 255, (nz * 0.5 + 0.5) * 255, 255);
      }
    }
  },

  // --- recipes ------------------------------------------------------------
  // 1. Heavy sci-fi hull plating: brushed metal, panel seams, rivets, scuffs
  metalPlate(size = 256) {
    return this.make('metalPlate', size, (u, v, x, y, o) => {
      const px = 4, py = 2.4;                        // panels across the tile
      const gx = Math.floor(u * px), gy = Math.floor(v * py);
      const fu = fract(u * px), fv = fract(v * py);
      const seam = Math.min(smoothstep(0, 0.03, fu) * smoothstep(0, 0.03, 1 - fu),
        smoothstep(0, 0.04, fv) * smoothstep(0, 0.04, 1 - fv));
      const grit = fbm2t(u, v, 48, 4) * 0.22 + 0.78;
      const brush = noise2t(u * 320, v * 12, 320, 12) * 0.5 + 0.5;
      const scratchN = fbm2t(u * 2.0, v * 0.05 + 0.3, 6, 3);
      const scratch = smoothstep(0.72, 0.88, scratchN) * 0.5;
      const panelTone = 0.86 + hash2(gx * 3.3 + 1.7, gy * 5.9) * 0.28;
      const rivet = (cx, cy) => {
        const d = Math.hypot((fu - cx) * px, (fv - cy) * py) * (size / 64) * 6;
        return smoothstep(0.55, 0.15, d);
      };
      const rv = Math.max(rivet(0.08, 0.5), rivet(0.92, 0.5), rivet(0.5, 0.1), rivet(0.5, 0.9));
      const rust = smoothstep(0.62, 0.85, fbm2t(u * 3.1, v * 3.1, 8, 4)) * 0.5;
      const base = 0.30 * panelTone * grit * (0.86 + brush * 0.14);
      o.r = base * (1 - scratch * 0.35) + rust * 0.20;
      o.g = base * (1 - scratch * 0.30) + rust * 0.09;
      o.b = base * 1.05 * (1 - scratch * 0.22) + rust * 0.03;
      o.rough = clamp(0.52 - brush * 0.10 + scratch * 0.35 + rust * 0.42 - rv * 0.05, 0.05, 1);
      o.metal = clamp(0.95 - rust * 0.7 - grit * 0.03, 0.2, 1);
      o.ao = clamp(0.55 + seam * 0.45 - rv * 0.1, 0.2, 1);
      o.height = clamp(0.5 * seam + rv * 0.35 + grit * 0.1 + brush * 0.03, 0, 1);
      if (rv > 0.6) { o.rough = Math.min(1, o.rough + 0.08); }
    });
  },

  // 2. Cast concrete / bunker wall
  concrete(size = 256) {
    return this.make('concrete', size, (u, v, x, y, o) => {
      const n = fbm2t(u, v, 9, 5);
      const fine = fbm2t(u, v, 64, 3);
      const w1 = worleyT(u, v, 7, 3), w2 = worleyT(u, v, 13, 11);
      const crack = smoothstep(0.055, 0.0, w1.edge) + smoothstep(0.04, 0.0, w2.edge) * 0.7;
      const stain = smoothstep(0.45, 0.9, fbm2t(u * 1.7 + 4, v * 1.7, 5, 4));
      const val = 0.34 + n * 0.14 + fine * 0.06 - crack * 0.22 - stain * 0.08;
      o.r = val * 1.02; o.g = val * 1.0; o.b = val * 0.94;
      o.rough = clamp(0.82 + fine * 0.12 - crack * 0.06, 0.3, 1);
      o.metal = 0.0;
      o.ao = clamp(0.72 + n * 0.22 - crack * 0.5, 0.1, 1);
      o.height = clamp(0.5 + (n - 0.5) * 0.5 - crack * 0.35 + fine * 0.1, 0, 1);
    });
  },

  // 3. Supply crate: painted alloy with hazard band + stamped icon
  crate(size = 256) {
    return this.make('crate', size, (u, v, x, y, o) => {
      const rim = Math.min(smoothstep(0, 0.06, u) * smoothstep(0, 0.06, 1 - u), smoothstep(0, 0.06, v) * smoothstep(0, 0.06, 1 - v));
      const inner = smoothstep(0.02, 0.09, Math.min(u, 1 - u, v, 1 - v));
      const fret = fbm2t(u, v, 40, 4);
      const grime = smoothstep(0.5, 0.95, fbm2t(u * 2.3, v * 2.3 + 7, 7, 4));
      const bandV = smoothstep(0.30, 0.315, v) * smoothstep(0.72, 0.705, v);
      const diag = fract((u * 8.0 + v * 8.0) * 0.5);
      const stripeBand = (diag > 0.44 && diag < 0.56) ? 1 : 0;
      const shake = bandV > 0.5 ? stripeBand : 0;
      // body colour: olive-drab alloy (muted, pbr friendly)
      let r = 0.30 + fret * 0.09, g = 0.33 + fret * 0.10, b = 0.26 + fret * 0.07;
      // top plate is darker
      const plate = smoothstep(0.55, 0.95, v) * 0.35;
      r -= plate * 0.06; g -= plate * 0.05; b -= plate * 0.04;
      // hazard band
      const warn = bandV * (0.35 + 0.65 * shake);
      r = lerp(r, 0.62, warn * 0.7); g = lerp(g, 0.54, warn * 0.7); b = lerp(b, 0.20, warn * 0.7);
      // rim highlight
      const edge = (1 - inner) * 0.5;
      r += edge * 0.22; g += edge * 0.23; b += edge * 0.2;
      // grime
      r *= 1 - grime * 0.35; g *= 1 - grime * 0.3; b *= 1 - grime * 0.28;
      o.r = r; o.g = g; o.b = b;
      o.rough = clamp(0.62 + fret * 0.14 + grime * 0.2 - warn * 0.1, 0.15, 1);
      o.metal = clamp(0.35 + edge * 0.3 - grime * 0.3, 0, 1);
      o.ao = clamp(0.6 + inner * 0.4 - grime * 0.2, 0.15, 1);
      o.height = clamp(0.35 + rim * 0.3 + fret * 0.2 + (1 - inner) * 0.3, 0, 1);
    });
  },

  // 4. Alien basalt / arena floor
  basalt(size = 256) {
    return this.make('basalt', size, (u, v, x, y, o) => {
      const w = worleyT(u, v, 6, 21);
      const w2 = worleyT(u, v, 12, 5);
      const vor = smoothstep(0.0, 0.22, w.f2 - w.f1);
      const n = fbm2t(u, v, 14, 5);
      const dark = 0.10 + n * 0.09 + vor * 0.07;
      const hot = smoothstep(0.86, 1.0, w.edge * -1 + 0.2) * 0;
      o.r = dark * 1.15; o.g = dark * 1.0; o.b = dark * 1.06;
      // faint mineral veins
      const vein = smoothstep(0.028, 0.0, w2.edge) * smoothstep(0.4, 0.7, fbm2t(u * 2, v * 2, 4, 3));
      o.r += vein * 0.16; o.g += vein * 0.19; o.b += vein * 0.22;
      o.rough = clamp(0.66 + n * 0.22 - vor * 0.1, 0.2, 1);
      o.metal = 0.03;
      o.ao = clamp(0.65 + vor * 0.35, 0.2, 1);
      o.height = clamp(vor * 0.65 + n * 0.35, 0, 1);
    });
  },

  // 5. Energy / emissive panel (reactor housing, door trims, the Crucible)
  energy(size = 256) {
    return this.make('energy', size, (u, v, x, y, o) => {
      const cell = 8;
      const fu = fract(u * cell), fv = fract(v * cell);
      const line = Math.max(smoothstep(0.06, 0.0, Math.min(fu, 1 - fu)), smoothstep(0.06, 0.0, Math.min(fv, 1 - fv)));
      const pulse = 0.6 + 0.4 * Math.sin(u * 30 + v * 12);
      const n = fbm2t(u, v, 22, 4);
      const glow = clamp(line * pulse * (0.5 + n * 0.5), 0, 1);
      o.r = 0.05 + glow * 0.04; o.g = 0.07 + glow * 0.06; o.b = 0.08 + glow * 0.06;
      const c = [0.10, 0.85, 1.0];
      o.em = [c[0] * glow, c[1] * glow, c[2] * glow];
      o.r += o.em[0] * 0.3; o.g += o.em[1] * 0.3; o.b += o.em[2] * 0.3;
      o.rough = clamp(0.35 + n * 0.2, 0.1, 1);
      o.metal = 0.25;
      o.ao = 1;
      o.height = clamp(glow, 0, 1);
    });
  },

  // 6. Sand (dunes / arena outskirts) — tileable, gentle
  sand(size = 128) {
    return this.make('sand', size, (u, v, x, y, o) => {
      const ripple = Math.sin((u * 14 + fbm2t(u, v, 5, 3) * 3.2) * 3.0) * 0.5 + 0.5;
      const n = fbm2t(u, v, 40, 4);
      const g = 0.62 + n * 0.14 + ripple * 0.06;
      o.r = g * 0.68; o.g = g * 0.56; o.b = g * 0.38;
      o.rough = clamp(0.9 - n * 0.06, 0.4, 1);
      o.metal = 0;
      o.ao = clamp(0.85 + n * 0.15, 0.3, 1);
      o.height = ripple * 0.4 + n * 0.6;
    });
  },

  // 7. Rock cliff layer
  rock(size = 128) {
    return this.make('rock', size, (u, v, x, y, o) => {
      const n = fbm2t(u, v, 9, 5);
      const strata = Math.sin(v * 26 + n * 6) * 0.5 + 0.5;
      const crack = smoothstep(0.05, 0, worleyT(u, v, 9, 17).edge);
      const val = 0.20 + n * 0.16 + strata * 0.05;
      o.r = val * 1.12; o.g = val * 1.02; o.b = val * 0.96;
      o.rough = clamp(0.88 - n * 0.1, 0.4, 1);
      o.metal = 0;
      o.ao = clamp(0.6 + n * 0.4 - crack * 0.3, 0.15, 1);
      o.height = clamp(n * 0.7 + strata * 0.3, 0, 1);
    });
  },

  // 8. Moss / alien turf layer
  turf(size = 128) {
    return this.make('turf', size, (u, v, x, y, o) => {
      const clump = worleyT(u, v, 20, 3).f1;
      const n = fbm2t(u, v, 34, 4);
      const val = clamp(0.55 - clump * 0.4 + n * 0.3, 0, 1);
      o.r = 0.09 * val + 0.03; o.g = 0.24 * val + 0.05; o.b = 0.10 * val + 0.02;
      o.em = [0.0, 0.012 * val, 0.006 * val];
      o.rough = 0.85;
      o.metal = 0;
      o.ao = clamp(0.5 + val * 0.5, 0.2, 1);
      o.height = val;
    });
  },

  // 9. Hazard stripes for the arena ring
  hazard(size = 128) {
    return this.make('hazard', size, (u, v, x, y, o) => {
      const stripe = fract((u * 10 + v * 10) * 0.5) > 0.5 ? 1 : 0;
      const n = fbm2t(u, v, 30, 4);
      const wear = smoothstep(0.55, 0.95, fbm2t(u * 1.4, v * 1.4, 6, 4));
      const k = 1 - wear * 0.55;
      o.r = lerp(0.06, 0.72, stripe) * k + n * 0.05;
      o.g = lerp(0.06, 0.60, stripe) * k + n * 0.05;
      o.b = lerp(0.06, 0.10, stripe) * k + n * 0.04;
      o.rough = clamp(0.55 + wear * 0.35, 0.2, 1);
      o.metal = 0.15 * (1 - stripe);
      o.ao = 1;
      o.height = 0.5 + stripe * 0.02;
    });
  },

  // 10. Glass / cockpit / shield surface
  glass(size = 128) {
    return this.make('glass', size, (u, v, x, y, o) => {
      const n = fbm2t(u, v, 60, 3);
      o.r = 0.02; o.g = 0.03; o.b = 0.045;
      o.rough = clamp(0.04 + n * 0.05, 0.01, 0.4);
      o.metal = 0.0;
      o.ao = 1;
      o.em = [0, 0, 0];
      o.height = 0.5;
    });
  },

  // --- sprite / fx textures -------------------------------------------------
  sprite(size, fn) { return this.make('sprite' + size + fn.name, size, fn); },

  radialSprite(size = 64) {
    return this.make('radial', size, (u, v, x, y, o) => {
      const d = Math.hypot(u - 0.5, v - 0.5) * 2;
      const a = clamp(1 - d, 0, 1);
      const k = Math.pow(a, 2.2);
      o.r = o.g = o.b = 1;
      o.em = [k, k, k];
      o.alpha = k;
      o.rough = 1; o.ao = 1; o.height = k;
    });
  },

  smokeSprite(size = 128) {
    return this.make('smoke', size, (u, v, x, y, o) => {
      const d = Math.hypot(u - 0.5, v - 0.5) * 2;
      const mask = clamp(1 - d, 0, 1);
      const n = fbm2t(u, v, 5, 5);
      const k = clamp(mask * 1.3 - 0.15, 0, 1) * (0.35 + n * 0.9);
      o.r = o.g = o.b = 1;
      o.em = [k, k, k];
      o.alpha = clamp(k * 1.1, 0, 1);
      o.height = k;
    });
  },

  scorchDecal(size = 128) {
    return this.make('scorch', size, (u, v, x, y, o) => {
      const d = Math.hypot(u - 0.5, v - 0.5) * 2;
      const n = fbm2t(u, v, 7, 5);
      const k = clamp(1 - d * (0.85 + n * 0.5), 0, 1);
      const dark = Math.pow(k, 1.5);
      o.r = lerp(0.5, 0.02, dark); o.g = lerp(0.5, 0.02, dark); o.b = lerp(0.5, 0.018, dark);
      o.rough = 0.95;
      o.metal = 0; o.ao = clamp(1 - dark, 0.2, 1);
      o.alpha = clamp(dark * 1.4, 0, 1);
      o.height = 0.5;
    });
  },

  // small tileable noise used for shadow dithering and film grain
  noiseTile(size = 64) {
    return this.make('noiseTile', size, (u, v, x, y, o) => {
      const n = hash2(x * 1.13 + 0.5, y * 2.71 + 0.7);
      const n2 = hash2(x * 5.3 + 11.1, y * 3.7 + 5.5);
      const k = (n + n2) * 0.5;
      o.r = o.g = o.b = k;
      o.em = [k, k, k];
      o.ao = 1; o.rough = 1; o.height = k;
      o.alpha = 1;
    });
  },

  // build the full library once
  buildAll(size = 256, onProgress) {
    const jobs = [
      ['metalPlate', () => this.metalPlate(size)],
      ['concrete', () => this.concrete(size)],
      ['crate', () => this.crate(size)],
      ['basalt', () => this.basalt(size)],
      ['energy', () => this.energy(size)],
      ['sand', () => this.sand(128)],
      ['rock', () => this.rock(128)],
      ['turf', () => this.turf(128)],
      ['hazard', () => this.hazard(128)],
      ['glass', () => this.glass(128)],
      ['radial', () => this.radialSprite(64)],
      ['smoke', () => this.smokeSprite(128)],
      ['scorch', () => this.scorchDecal(128)],
      ['noiseTile', () => this.noiseTile(64)],
    ];
    const out = {};
    for (let i = 0; i < jobs.length; i++) {
      out[jobs[i][0]] = jobs[i][1]();
      if (onProgress) onProgress((i + 1) / jobs.length, jobs[i][0]);
    }
    return out;
  }
};
