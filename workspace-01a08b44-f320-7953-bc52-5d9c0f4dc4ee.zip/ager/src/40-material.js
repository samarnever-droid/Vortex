// ===========================================================================
//  AGER ENGINE  ·  40-material  ·  physically based materials + shader build
//
//  Shading model : Cook-Torrance GGX, Smith correlated visibility,
//                  Burley diffuse, split-sum IBL (analytic DFG),
//                  SH9 sky irradiance, cascaded shadow maps + spot shadows,
//                  point/spot light loops, height fog with sun inscattering.
// ===========================================================================

const GLSL_HASH13 = `float hash13(vec3 p3){ p3 = fract(p3*0.1031); p3 += dot(p3, p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }`;

const GLSL_COMMON = `const float PI = 3.14159265359;
float saturate(float x){ return clamp(x,0.0,1.0); }
vec3 saturate3(vec3 x){ return clamp(x,0.0,1.0); }
vec3 acesFilm(vec3 x){
  const mat3 ACESInput = mat3(0.59719,0.07600,0.02840, 0.35458,0.90834,0.13383, 0.04823,0.01566,0.83777);
  const mat3 ACESOutput = mat3(1.60475,-0.10208,-0.00327, -0.53108,1.10813,-0.07276, -0.07367,-0.00605,1.07602);
  x = ACESInput * max(vec3(0.0), x);
  vec3 a = x * (x + 0.0245786) - 0.000090537;
  vec3 b = x * (0.983729 * x + 0.4329510) + 0.238081;
  return saturate3(ACESOutput * (a / b));
}`;

// Analytic single-scattering atmosphere. The JS twin is SkyModel.sample()
// and must stay in sync (it drives the SH irradiance used by every material).
const GLSL_SKY = `vec2 raySphere(vec3 ro, vec3 rd, float r){
  float b = dot(ro, rd);
  float c = dot(ro,ro) - r*r;
  float d = b*b - c;
  if (d < 0.0) return vec2(-1.0);
  d = sqrt(d);
  return vec2(-b - d, -b + d);
}
vec3 skyColor(vec3 rd, vec3 sunDir, vec3 sunColor, float sunSize, float turbidity, float exposure, float night){
  const float Rg = 6360000.0;
  const float Ra = 6420000.0;
  const float Hr = 8000.0;
  const float Hm = 1200.0;
  const vec3 betaR = vec3(5.8e-6, 13.5e-6, 33.1e-6);
  const float betaM = 21e-6;
  const float G = 0.76;
  vec3 ro = vec3(0.0, Rg + 300.0, 0.0);
  vec2 a = raySphere(ro, rd, Ra);
  vec2 b = raySphere(ro, rd, Rg);
  if (a.y < 0.0){
    float h = saturate(1.0 + rd.y * 6.0);
    vec3 ground = vec3(0.055,0.06,0.07) * night + vec3(0.06,0.062,0.07);
    return mix(ground*0.6, ground, h);
  }
  float tEnd = min(a.y, b.y > 0.0 ? b.y : a.y);
  const int STEPS = 14;
  float step = tEnd / float(STEPS);
  float mu = dot(rd, sunDir);
  float g2 = G*G;
  float phaseR = 3.0/(16.0*PI) * (1.0 + mu*mu);
  float phaseM = 3.0/(8.0*PI) * ((1.0-g2)*(1.0+mu*mu)) / ((2.0+g2)*pow(max(1e-3,1.0+g2-2.0*G*mu), 1.5));
  float mieF = mix(0.4, 1.6, clamp(turbidity,0.0,1.5));
  vec3 sumR = vec3(0.0), sumM = vec3(0.0);
  float odR = 0.0, odM = 0.0;
  for (int i=0;i<STEPS;i++){
    vec3 p = ro + rd * (float(i)+0.5) * step;
    float h = max(0.0, length(p) - Rg);
    float dR = exp(-h/Hr) * step;
    float dM = exp(-h/Hm) * step;
    odR += dR; odM += dM;
    vec3 tau = betaR * (odR + odM*0.3) + betaM * 1.1 * odM;
    vec3 att = exp(-tau);
    sumR += att * dR;
    sumM += att * dM;
  }
  vec3 col = (sumR * betaR * phaseR + sumM * betaM * phaseM * mieF) * sunColor * 8.0 * exposure;
  float cosAng = dot(rd, sunDir);
  float ang = acos(clamp(cosAng,-1.0,1.0));
  float disk = 1.0 - smoothstep(sunSize, sunSize*1.5, ang);
  float glow = pow(saturate(cosAng), 300.0)*0.5 + pow(saturate(cosAng), 14.0)*0.06;
  col += (disk*140.0 + glow*3.0) * sunColor * exposure;
  if (night > 0.001 && rd.y > -0.02){
    vec3 sd = rd * 220.0;
    float st = hash13(floor(sd));
    float star = smoothstep(0.9982, 1.0, st);
    col += vec3(0.9,0.95,1.0) * star * 3.0 * night * saturate(rd.y*2.5);
  }
  float hz = exp(-max(0.0, rd.y) * 8.0);
  col += sunColor * hz * 0.02 * saturate(sunDir.y+0.35) * exposure;
  col *= mix(vec3(0.7,0.78,0.95), vec3(1.0), saturate(sunDir.y*4.0+0.6));
  return col;
}`;

const PBR_VS = `#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
layout(location=3) in vec4 aTangent;
#ifdef INSTANCED
layout(location=8) in vec4 iM0;
layout(location=9) in vec4 iM1;
layout(location=10) in vec4 iM2;
layout(location=11) in vec4 iM3;
layout(location=12) in vec4 iData;
#endif
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProj;
uniform mat3 uNormalMat;
uniform vec2 uUVScale;
uniform vec2 uUVOffset;
uniform float uTime;
out vec3 vWorld;
out vec3 vNormal;
out vec2 vUV;
out vec4 vTangent;
out float vViewDepth;
out vec4 vInst;
void main(){
  mat4 M = uModel;
  mat3 NM = uNormalMat;
#ifdef INSTANCED
  M = mat4(iM0, iM1, iM2, iM3);
  NM = mat3(M);
#endif
  vec3 pos = aPosition;
  vec3 wpos = (M * vec4(pos,1.0)).xyz;
  vec3 wnrm = normalize(NM * aNormal);
#ifdef BILLBOARD
  vec3 camRight = vec3(uView[0][0], uView[1][0], uView[2][0]);
  vec3 camUp    = vec3(uView[0][1], uView[1][1], uView[2][1]);
  vec3 center = M[3].xyz;
  float size = aPosition.z;
  wpos = center + camRight * pos.x * size + camUp * pos.y * size;
  wnrm = normalize(camUp * 0.35 + camRight * 0.0 + vec3(0.0,0.0,1.0)*0.0 + vec3(0.0,0.0,0.0));
  wnrm = normalize(vec3(uView[0][2], uView[1][2], uView[2][2]));
#endif
  vWorld = wpos;
  vNormal = wnrm;
  vUV = aUV * uUVScale + uUVOffset;
  vTangent = aTangent;
  vec4 vpos = uView * vec4(wpos,1.0);
  vViewDepth = -vpos.z;
  gl_Position = uProj * vpos;
  #ifdef INSTANCED
  vInst = iData;
  #else
  vInst = vec4(0.0);
  #endif
}`;

const PBR_FS = `#version 300 es
precision highp float;
precision highp sampler2DArrayShadow;
in vec3 vWorld;
in vec3 vNormal;
in vec2 vUV;
in vec4 vTangent;
in float vViewDepth;
in vec4 vInst;
layout(location=0) out vec4 outColor;

uniform vec3 uCameraPos;
uniform vec3 uAlbedo;
uniform float uRoughness;
uniform float uMetalness;
uniform vec3 uEmissive;
uniform float uEmissiveIntensity;
uniform float uOpacity;
uniform float uAOIntensity;
uniform float uNormalScale;
uniform float uTime;
uniform float uInstanceTint;

uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunIntensity;
uniform float uSkyIntensity;
uniform float uEnvLod;
uniform vec3 uAmbientSH[9];
uniform float uAmbientBoost;
uniform float uShadowStrength;
uniform float uShadowNormalBias;
uniform float uShadowTexel;
uniform float uShadowSoftness;
uniform int uCascadeCount;
uniform vec3 uCascadeSplits;

uniform int uPointCount;
uniform vec3 uPointPos[12];
uniform vec3 uPointColor[12];
uniform vec4 uPointParams[12];   // x range, y intensity, z shadow layer or -1, w unused

uniform int uSpotCount;
uniform vec3 uSpotPos[6];
uniform vec3 uSpotColor[6];
uniform vec4 uSpotDirInner[6];   // xyz = dir, w = cos(inner)
uniform vec4 uSpotParams[6];     // x range, y intensity, z cos(outer), w shadow layer or -1

uniform sampler2DArrayShadow uShadowArray;
uniform mat4 uShadowMatrix[8];
uniform vec4 uShadowTile[8];

uniform vec3 uFogColor;
uniform float uFogDensity;
uniform float uFogHeight;
uniform float uFogFalloff;
uniform float uFogSunAmount;

uniform sampler2D uAlbedoMap;
uniform sampler2D uOrmMap;
uniform sampler2D uNormalMap;
uniform sampler2D uEmissiveMap;
uniform sampler2D uSplatMap;
uniform sampler2D uLayerA;
uniform sampler2D uLayerB;
uniform sampler2D uLayerC;
uniform sampler2D uLayerD;
uniform float uSplatScale;

uniform float uRim;
uniform vec3 uRimColor;

uniform samplerCube uEnvMap;
uniform int uDebugView;   // 0 off, 1 sun, 2 shadow, 3 albedo, 4 irradiance, 5 env spec, 6 NdotL, 7 normals, 8 rough/metal

${GLSL_HASH13}
${GLSL_COMMON}
${GLSL_SKY}

float shadowFactor(int layer, vec3 world, float ndl){
  if (layer < 0) return 1.0;
  vec3 offs = vNormal * (uShadowNormalBias + (1.0-ndl)*uShadowNormalBias*2.5);
  vec4 lp = uShadowMatrix[layer] * vec4(world + offs, 1.0);
  vec3 proj = lp.xyz / lp.w;
  proj = proj * 0.5 + 0.5;
  if (proj.x < 0.001 || proj.x > 0.999 || proj.y < 0.001 || proj.y > 0.999 || proj.z > 1.0) return 1.0;
  vec4 tile = uShadowTile[layer];
  vec2 uv = tile.xy + proj.xy * tile.zw;
  float ref = proj.z - 0.0012;
  vec2 texel = tile.zw * uShadowTexel * uShadowSoftness;
  float sum = 0.0;
  for (int y=-1;y<=1;y++){
    for (int x=-1;x<=1;x++){
      sum += texture(uShadowArray, vec4(uv + vec2(float(x),float(y))*texel, float(layer), ref));
    }
  }
  return sum * (1.0/9.0);
}

float sunShadow(vec3 world, float ndl){
  int layer = 0;
  if (uCascadeCount > 1 && vViewDepth > uCascadeSplits.x) layer = 1;
  if (uCascadeCount > 2 && vViewDepth > uCascadeSplits.y) layer = 2;
  if (uCascadeCount > 3 && vViewDepth > uCascadeSplits.z) layer = 3;
  return shadowFactor(layer, world, ndl);
}

float D_GGX(float NoH, float a){
  float a2 = a*a;
  float d = (NoH*NoH*(a2-1.0)+1.0);
  return a2 / max(1e-7, PI*d*d);
}
float V_SmithGGXCorrelated(float NoV, float NoL, float a){
  float a2 = a*a;
  float gv = NoL * sqrt(NoV*NoV*(1.0-a2)+a2);
  float gl = NoV * sqrt(NoL*NoL*(1.0-a2)+a2);
  return 0.5 / max(1e-7, gv+gl);
}
vec3 F_Schlick(vec3 f0, float f90, float VoH){
  return f0 + (f90 - f0) * pow(1.0 - VoH, 5.0);
}
float Fd_Burley(float NoV, float NoL, float LoH, float rough){
  float f90 = 0.5 + 2.0*rough*LoH*LoH;
  float lightScatter = 1.0 + (f90-1.0)*pow(1.0-NoL, 5.0);
  float viewScatter = 1.0 + (f90-1.0)*pow(1.0-NoV, 5.0);
  return lightScatter*viewScatter/PI;
}
vec2 envBRDFApprox(float NoV, float rough){
  const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
  const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
  vec4 r = rough * c0 + c1;
  float a004 = min(r.x*r.x, exp2(-9.28*NoV)) * r.x + r.y;
  return vec2(-1.04, 1.04) * a004 + vec2(r.z, r.w);
}
vec3 shadeLight(vec3 f0, vec3 diffCol, float rough, float metal, float ao, vec3 N, vec3 V, vec3 L, vec3 radiance){
  float NoL = saturate(dot(N,L));
  if (NoL <= 0.0) return vec3(0.0);
  vec3 H = normalize(V+L);
  float NoV = saturate(dot(N,V)) + 1e-4;
  float NoH = saturate(dot(N,H));
  float VoH = saturate(dot(V,H));
  float a = max(0.0025, rough*rough);
  float D = D_GGX(NoH, a);
  float Vis = V_SmithGGXCorrelated(NoV, NoL, a);
  vec3 F = F_Schlick(f0, 1.0, VoH);
  vec3 spec = D * Vis * F;
  vec3 kd = (1.0 - F) * (1.0 - metal);
  vec3 diff = kd * diffCol * Fd_Burley(NoV, NoL, VoH, rough);
  return (diff + spec) * radiance * NoL;
}
vec3 shIrradiance(vec3 n){
  vec3 c1 = vec3(0.429043, 0.511664, 0.743125);
  vec3 c2 = vec3(0.886227, 0.511664, 0.429043);
  return max(vec3(0.0),
      c1.x*(n.x*n.x - n.y*n.y)*uAmbientSH[7]
    + 3.0*c1.z*n.y*n.y*uAmbientSH[8]
    - c1.x*uAmbientSH[7] + 0.0
    + 0.858086*n.x*n.y*uAmbientSH[4]
    + 2.0*0.511664*n.y*uAmbientSH[1]
    + 2.0*0.511664*n.z*uAmbientSH[2]
    + 2.0*0.511664*n.x*uAmbientSH[3]
    + c1.z*(n.y*n.z)*uAmbientSH[5]
    + c1.z*(n.x*n.z)*uAmbientSH[6]
    + c2.x*uAmbientSH[0]);
}

void main(){
  vec3 albedo = uAlbedo;
  float alpha = uOpacity;
  #ifdef HAS_ALBEDO_MAP
  vec4 texA = texture(uAlbedoMap, vUV);
  albedo *= texA.rgb;
  alpha *= texA.a;
  #endif
  float rough = uRoughness;
  float metal = uMetalness;
  float ao = 1.0;
  #ifdef HAS_ORM_MAP
  vec4 orm = texture(uOrmMap, vUV);
  ao = orm.r;
  rough = clamp(orm.g * uRoughness, 0.03, 1.0);
  metal = clamp(orm.b * uMetalness, 0.0, 1.0);
  #endif
  #ifdef USE_SPLAT
  vec4 sp = texture(uSplatMap, vWorld.xz * uSplatScale * 0.2);
  float ws = max(1e-4, sp.r+sp.g+sp.b+sp.a);
  sp /= ws;
  vec2 suv = vWorld.xz * uSplatScale;
  vec3 a0 = texture(uLayerA, suv).rgb;
  vec3 a1 = texture(uLayerB, suv*0.65).rgb;
  vec3 a2 = texture(uLayerC, suv*1.6).rgb;
  vec3 a3 = texture(uLayerD, suv*0.45).rgb;
  albedo = (a0*sp.r + a1*sp.g + a2*sp.b + a3*sp.a) * uAlbedo;
  #endif
  #ifdef INSTANCED
  if (uInstanceTint > 0.0){
    vec3 tint = fract(vec3(vInst.w*0.1371, vInst.w*0.2717, vInst.w*0.5197))*0.7 + 0.65;
    albedo = mix(albedo, albedo*tint, uInstanceTint);
    rough = clamp(rough + vInst.y, 0.03, 1.0);
  }
  #endif

  vec3 N = normalize(vNormal);
  #ifdef TWO_SIDED
  if (!gl_FrontFacing) N = -N;
  #endif
  #ifdef HAS_NORMAL_MAP
  vec3 T = normalize(vTangent.xyz - N*dot(N, vTangent.xyz));
  vec3 B = cross(N,T) * vTangent.w;
  vec3 tn = texture(uNormalMap, vUV).xyz * 2.0 - 1.0;
  tn.xy *= uNormalScale;
  N = normalize(mat3(T,B,N) * tn);
  #endif
  vec3 V = normalize(uCameraPos - vWorld);
  float NoV = saturate(dot(N,V)) + 1e-4;

  #ifdef UNLIT
  vec3 ucol = albedo * uEmissiveIntensity + uEmissive;
  vec3 ufog = mix(ucol, uFogColor, saturate(1.0 - exp(-vViewDepth * max(0.0005,uFogDensity) * 1.5)));
  outColor = vec4(ufog, alpha);
  return;
  #endif

  vec3 f0 = mix(vec3(0.04), albedo, metal);
  vec3 diffCol = albedo * (1.0 - metal);
  vec3 color = vec3(0.0);

  // sun
  vec3 sunTerm = vec3(0.0);
  float sunShadowTerm = 1.0;
  float ndl = 0.0;
  if (uSunIntensity > 0.0){
    vec3 L = normalize(uSunDir);
    ndl = saturate(dot(N,L));
    #ifdef RECEIVE_SHADOW
    sunShadowTerm = mix(1.0, sunShadow(vWorld, ndl), uShadowStrength);
    #endif
    sunTerm = shadeLight(f0, diffCol, rough, metal, ao, N, V, L, uSunColor * uSunIntensity) * sunShadowTerm;
  }
  color += sunTerm;
  // point lights
  for (int i = 0; i < uPointCount; i++){
    vec3 d = uPointPos[i] - vWorld;
    float dist = length(d);
    float range = uPointParams[i].x;
    if (dist > range) continue;
    vec3 L = d / max(1e-4, dist);
    float t = saturate(1.0 - dist/range);
    float atten = t*t*uPointParams[i].y;
    int layer = int(uPointParams[i].z);
    float sh = 1.0;
    #ifdef RECEIVE_SHADOW
    if (layer >= 0) sh = mix(1.0, shadowFactor(layer, vWorld, saturate(dot(N,L))), uShadowStrength);
    #endif
    color += shadeLight(f0, diffCol, rough, metal, ao, N, V, L, uPointColor[i]*atten) * sh;
  }
  // spot lights
  for (int i = 0; i < uSpotCount; i++){
    vec3 d = uSpotPos[i] - vWorld;
    float dist = length(d);
    float range = uSpotParams[i].x;
    if (dist > range) continue;
    vec3 L = d / max(1e-4, dist);
    float cosA = dot(-L, normalize(uSpotDirInner[i].xyz));
    float outer = uSpotParams[i].z;
    float inner = uSpotDirInner[i].w;
    if (cosA < outer) continue;
    float atten = smoothstep(outer, inner, cosA) * saturate(1.0-dist/range);
    atten = atten*atten*uSpotParams[i].y;
    int layer = int(uSpotParams[i].w);
    float sh = 1.0;
    #ifdef RECEIVE_SHADOW
    if (layer >= 0) sh = mix(1.0, shadowFactor(layer, vWorld, saturate(dot(N,L))), uShadowStrength);
    #endif
    color += shadeLight(f0, diffCol, rough, metal, ao, N, V, L, uSpotColor[i]*atten) * sh;
  }

  // IBL
  vec3 irr = shIrradiance(N) * uSkyIntensity * uAmbientBoost;
  vec3 ambDiffTerm = diffCol * irr * mix(1.0, ao, uAOIntensity);
  color += ambDiffTerm;
  vec3 R = reflect(-V, N);
  vec3 pref = textureLod(uEnvMap, R, rough * (uEnvLod - 1.0)).rgb * uSkyIntensity;
  vec2 ab = envBRDFApprox(NoV, rough);
  vec3 ambSpecTerm = pref * (f0*ab.x + ab.y) * mix(1.0, ao, 0.5);
  color += ambSpecTerm;

  if (uDebugView > 0){
    if (uDebugView == 1) { outColor = vec4(sunTerm, 1.0); return; }
    if (uDebugView == 2) { outColor = vec4(vec3(sunShadowTerm), 1.0); return; }
    if (uDebugView == 3) { outColor = vec4(albedo, 1.0); return; }
    if (uDebugView == 4) { outColor = vec4(irr, 1.0); return; }
    if (uDebugView == 5) { outColor = vec4(ambSpecTerm, 1.0); return; }
    if (uDebugView == 6) { outColor = vec4(vec3(ndl), 1.0); return; }
    if (uDebugView == 7) { outColor = vec4(N*0.5+0.5, 1.0); return; }
    if (uDebugView == 8) { outColor = vec4(rough, metal, ao, 1.0); return; }
    if (uDebugView == 9) { outColor = vec4(uSunColor * uSunIntensity, 1.0); return; }
    if (uDebugView == 10) { outColor = vec4(1.0, 0.0, 1.0, 1.0); return; }          // coverage
    if (uDebugView == 11) { outColor = vec4(fract(vUV), 0.0, 1.0); return; }        // uv
    #ifdef HAS_ALBEDO_MAP
    if (uDebugView == 12) { outColor = vec4(texture(uAlbedoMap, vUV).rgb, 1.0); return; }
    #endif
    #ifdef HAS_ORM_MAP
    if (uDebugView == 13) { outColor = vec4(texture(uOrmMap, vUV).rgb, 1.0); return; }
    #endif
    if (uDebugView == 14) { outColor = vec4(uAlbedo, 1.0); return; }                // uniform albedo
  }

  if (uRim > 0.0) color += uRimColor * pow(1.0-NoV, 3.0) * uRim;

  vec3 emis = uEmissive * uEmissiveIntensity;
  #ifdef HAS_EMISSIVE_MAP
  emis *= texture(uEmissiveMap, vUV).rgb;
  #endif
  color += emis;

  // height fog + sun inscattering
  float fogAmount;
  if (uFogHeight > 0.0){
    float h = max(0.0, vWorld.y - uFogHeight);
    float kr = uFogDensity * exp(-h * uFogFalloff);
    fogAmount = 1.0 - exp(-kr * vViewDepth * (1.0 + vViewDepth*uFogDensity*0.3));
  } else {
    fogAmount = 1.0 - exp(-uFogDensity * vViewDepth);
  }
  vec3 fogCol = uFogColor;
  float sunAmt = pow(saturate(dot(-V, normalize(uSunDir))), 6.0) * uFogSunAmount;
  fogCol += uSunColor * sunAmt * 3.0;
  color = mix(color, fogCol, saturate(fogAmount));

  outColor = vec4(color, alpha);
}`;

const DEPTH_VS = `#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
layout(location=3) in vec4 aTangent;
#ifdef INSTANCED
layout(location=8) in vec4 iM0;
layout(location=9) in vec4 iM1;
layout(location=10) in vec4 iM2;
layout(location=11) in vec4 iM3;
layout(location=12) in vec4 iData;
#endif
uniform mat4 uModel;
uniform mat4 uShadowVP;
uniform vec2 uUVScale;
uniform float uTime;
out vec2 vUV;
void main(){
  mat4 M = uModel;
#ifdef INSTANCED
  M = mat4(iM0,iM1,iM2,iM3);
#endif
  vUV = aUV * uUVScale;
  gl_Position = uShadowVP * M * vec4(aPosition,1.0);
}`;

const DEPTH_FS = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uAlbedoMap;
uniform float uAlphaTest;
void main(){
  float a = 1.0;
  #ifdef HAS_ALBEDO_MAP
  a = texture(uAlbedoMap, vUV).a;
  #endif
  if (a < uAlphaTest) discard;
}`;

// ---------------------------------------------------------------------------
//  Material
// ---------------------------------------------------------------------------
let _matId = 0;
class Material {
  constructor(o = {}) {
    this.id = ++_matId;
    this.name = o.name || ('mat' + this.id);
    this.color = o.color !== undefined ? (typeof o.color === 'number' ? colorToLinear(o.color) : o.color) : [0.5, 0.5, 0.5];
    this.roughness = o.roughness !== undefined ? o.roughness : 0.7;
    this.metalness = o.metalness !== undefined ? o.metalness : 0.0;
    this.emissive = o.emissive !== undefined ? (typeof o.emissive === 'number' ? colorToLinear(o.emissive) : o.emissive) : [0, 0, 0];
    this.emissiveIntensity = o.emissiveIntensity !== undefined ? o.emissiveIntensity : 1.0;
    this.aoIntensity = o.aoIntensity !== undefined ? o.aoIntensity : 1.0;
    this.uvScale = o.uvScale !== undefined ? (typeof o.uvScale === 'number' ? [o.uvScale, o.uvScale] : o.uvScale) : [1, 1];
    this.uvOffset = o.uvOffset || [0, 0];
    this.opacity = o.opacity !== undefined ? o.opacity : 1;
    this.transparent = !!o.transparent;
    this.blending = o.blending || 'normal';
    this.depthWrite = o.depthWrite !== undefined ? o.depthWrite : !o.transparent;
    this.doubleSided = !!o.doubleSided;
    this.alphaTest = o.alphaTest || 0;
    this.unlit = !!o.unlit;
    this.castShadow = o.castShadow !== undefined ? o.castShadow : true;
    this.receiveShadow = o.receiveShadow !== undefined ? o.receiveShadow : true;
    this.rim = o.rim || 0;
    this.rimColor = o.rimColor ? (typeof o.rimColor === 'number' ? colorToLinear(o.rimColor) : o.rimColor) : [0.4, 0.7, 1.0];
    this.instanceTint = o.instanceTint !== undefined ? o.instanceTint : 0;
    this.splat = !!o.splat;
    this.splatScale = o.splatScale !== undefined ? o.splatScale : 0.06;
    this.normalScale = o.normalScale !== undefined ? o.normalScale : 1.0;
    this.timeScale = o.timeScale !== undefined ? o.timeScale : 1.0;
    this.maps = Object.assign({ albedo: null, orm: null, normal: null, emissive: null, splat: null, layerA: null, layerB: null, layerC: null, layerD: null, blueNoise: null, env: null }, o.maps || {});
    this.defines = Object.assign({}, o.defines);
    this._program = null; this._depthProgram = null; this._key = '';
  }
  hasAlbedoMap() { return !!this.maps.albedo; }
  keys() {
    const d = this.defines;
    return [
      this.maps.albedo ? 'A' : '', this.maps.orm ? 'O' : '', this.maps.normal ? 'N' : '',
      this.maps.emissive ? 'E' : '', this.splat ? 'S' : '', this.unlit ? 'U' : '',
      this.transparent ? 'T' : '', this.alphaTest > 0 ? 'X' : '', this.doubleSided ? 'D' : '',
      this.blending === 'additive' ? 'G' : '', this.rim > 0 ? 'R' : '', this.instanceTint > 0 ? 'I' : '',
      d.INSTANCED ? 'M' : '', d.BILLBOARD ? 'B' : '', d.FLAT ? 'F' : '', d.RECEIVE_SHADOW === false ? 'Z' : '',
    ].join('');
  }
  clone(over = {}) {
    const m = new Material(Object.assign({}, this, over));
    m.maps = Object.assign({}, this.maps, over.maps || {});
    m.defines = Object.assign({}, this.defines, over.defines || {});
    if (over.color !== undefined) m.color = typeof over.color === 'number' ? colorToLinear(over.color) : over.color;
    if (over.emissive !== undefined) m.emissive = typeof over.emissive === 'number' ? colorToLinear(over.emissive) : over.emissive;
    m.id = ++_matId;
    m.name = over.name || (this.name + '_c');
    return m;
  }
  // program caching happens per (keys + defines) combination
  program(device, extraDefines) {
    const defines = Object.assign({
      HAS_ALBEDO_MAP: this.maps.albedo ? 1 : undefined,
      HAS_ORM_MAP: this.maps.orm ? 1 : undefined,
      HAS_NORMAL_MAP: this.maps.normal ? 1 : undefined,
      HAS_EMISSIVE_MAP: this.maps.emissive ? 1 : undefined,
      USE_SPLAT: this.splat ? 1 : undefined,
      UNLIT: this.unlit ? 1 : undefined,
      TWO_SIDED: this.doubleSided ? 1 : undefined,
    }, this.defines, extraDefines);
    for (const k of Object.keys(defines)) if (defines[k] === undefined) delete defines[k];
    const key = this.keys() + '|' + Object.entries(defines).map(([k, v]) => k + v).join(',');
    if (this._program && this._key === key) return this._program;
    this._program = new Program(device, PBR_VS, PBR_FS, 'pbr_' + key, defines);
    this._key = key;
    return this._program;
  }
  depthProgram(device) {
    const defines = {
      INSTANCED: this.defines.INSTANCED ? 1 : undefined,
      HAS_ALBEDO_MAP: (this.maps.albedo && this.alphaTest > 0) ? 1 : undefined,
    };
    for (const k of Object.keys(defines)) if (defines[k] === undefined) delete defines[k];
    const key = 'depth|' + this.keys() + Object.values(defines).join('');
    if (this._depthProgram && this._depthKey === key) return this._depthProgram;
    this._depthProgram = new Program(device, DEPTH_VS, DEPTH_FS, 'depth_' + key, defines);
    this._depthKey = key;
    return this._depthProgram;
  }
}
