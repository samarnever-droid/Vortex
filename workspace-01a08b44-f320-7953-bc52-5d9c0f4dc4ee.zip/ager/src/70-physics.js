// ===========================================================================
//  AGER ENGINE  ·  70-physics  ·  colliders, capsule character controller,
//  raycasts, spatial hash broadphase, kinematic bodies
// ===========================================================================

class Collider {
  constructor(opts = {}) {
    this.type = opts.type || 'box';           // box | sphere | capsule | plane | terrain
    this.node = opts.node || null;
    this.offset = opts.offset || [0, 0, 0];
    this.halfExtents = opts.size ? [opts.size[0] / 2, opts.size[1] / 2, opts.size[2] / 2] : (opts.halfExtents || [0.5, 0.5, 0.5]);
    this.radius = opts.radius || 0.5;
    this.height = opts.height || 1;
    this.box = new AABB();
    this.center = [0, 0, 0];
    this.static = opts.static !== false;
    this.tag = opts.tag || 'world';
    this.material = opts.material || 'concrete';
    this.owner = opts.owner || null;
    this.enabled = true;
    this.update();
  }
  update() {
    let x = this.offset[0], y = this.offset[1], z = this.offset[2];
    if (this.node) {
      const m = this.node.worldMatrix;
      const ox = this.offset[0], oy = this.offset[1], oz = this.offset[2];
      x = m[0] * ox + m[4] * oy + m[8] * oz + m[12];
      y = m[1] * ox + m[5] * oy + m[9] * oz + m[13];
      z = m[2] * ox + m[6] * oy + m[10] * oz + m[14];
    }
    this.center[0] = x; this.center[1] = y; this.center[2] = z;
    const hx = this.type === 'sphere' || this.type === 'capsule' ? this.radius : this.halfExtents[0];
    const hy = this.type === 'sphere' ? this.radius : (this.type === 'capsule' ? this.height / 2 + this.radius : this.halfExtents[1]);
    const hz = this.type === 'sphere' || this.type === 'capsule' ? this.radius : this.halfExtents[2];
    this.box.set([x - hx, y - hy, z - hz], [x + hx, y + hy, z + hz]);
    return this;
  }
  // closest point on this collider's AABB surface to p, plus penetration depth
  closestPoint(p, out = [0, 0, 0]) {
    const b = this.box;
    out[0] = clamp(p[0], b.min[0], b.max[0]);
    out[1] = clamp(p[1], b.min[1], b.max[1]);
    out[2] = clamp(p[2], b.min[2], b.max[2]);
    return out;
  }
  raycast(origin, dir, maxT = 1e9) {
    if (this.type === 'sphere') {
      // ray vs sphere
      const oc = [origin[0] - this.center[0], origin[1] - this.center[1], origin[2] - this.center[2]];
      const b = oc[0] * dir[0] + oc[1] * dir[1] + oc[2] * dir[2];
      const c = Vec3.len2(oc) - this.radius * this.radius;
      const disc = b * b - c;
      if (disc < 0) return null;
      const sq = Math.sqrt(disc);
      let t = -b - sq;
      if (t < 0) t = -b + sq;
      if (t < 0 || t > maxT) return null;
      const p = [origin[0] + dir[0] * t, origin[1] + dir[1] * t, origin[2] + dir[2] * t];
      const n = Vec3.normalize([0, 0, 0], [p[0] - this.center[0], p[1] - this.center[1], p[2] - this.center[2]]);
      return { t, point: p, normal: n, collider: this };
    }
    const t = this.box.intersectsRay(origin, dir, maxT);
    if (t < 0 || t > maxT) return null;
    const p = [origin[0] + dir[0] * t, origin[1] + dir[1] * t, origin[2] + dir[2] * t];
    // normal from the face we entered
    const b = this.box, eps = 1e-3;
    let n = [0, 0, 0];
    if (Math.abs(p[0] - b.min[0]) < eps) n = [-1, 0, 0];
    else if (Math.abs(p[0] - b.max[0]) < eps) n = [1, 0, 0];
    else if (Math.abs(p[1] - b.min[1]) < eps) n = [0, -1, 0];
    else if (Math.abs(p[1] - b.max[1]) < eps) n = [0, 1, 0];
    else if (Math.abs(p[2] - b.min[2]) < eps) n = [0, 0, -1];
    else n = [0, 0, 1];
    return { t, point: p, normal: n, collider: this };
  }
}

class PhysicsWorld {
  constructor(opts = {}) {
    this.hash = new SpatialHash(opts.cell || 6);
    this.colliders = [];
    this.terrain = opts.terrain || null;   // { heightAt(x,z), normalAt(x,z) }
    this.gravity = opts.gravity !== undefined ? opts.gravity : -22;
    this._tmp = [];
    this._q = new AABB();
    this.debugDraw = false;
  }
  add(collider) {
    this.colliders.push(collider);
    if (collider.static) this.hash.insert(collider.box, collider);
    return collider;
  }
  addBox(node, size, opts = {}) { return this.add(new Collider(Object.assign({ type: 'box', node, size }, opts))); }
  addSphere(node, radius, opts = {}) { return this.add(new Collider(Object.assign({ type: 'sphere', node, radius }, opts))); }
  addCapsule(node, radius, height, opts = {}) { return this.add(new Collider(Object.assign({ type: 'capsule', node, radius, height }, opts))); }
  remove(collider) {
    const i = this.colliders.indexOf(collider);
    if (i >= 0) this.colliders.splice(i, 1);
    return this;
  }
  rebuild() {
    this.hash.clear();
    for (const c of this.colliders) { c.update(); if (c.static) this.hash.insert(c.box, c); }
  }
  update() {
    for (const c of this.colliders) if (!c.static) c.update();
  }
  query(aabb, out = []) { return this.hash.query(aabb, out); }
  querySphere(center, radius, out = []) {
    this._q.set([center[0] - radius, center[1] - radius, center[2] - radius], [center[0] + radius, center[1] + radius, center[2] + radius]);
    const cand = this.hash.query(this._q, this._tmp);
    out.length = 0;
    for (const c of cand) if (c.enabled && c.box.intersectsSphere(center, radius)) out.push(c);
    return out;
  }
  raycast(origin, dir, maxDist = 200, filter = null) {
    let best = null;
    // terrain first
    if (this.terrain) {
      const hit = this.terrain.raycast ? this.terrain.raycast(origin, dir, maxDist) : null;
      if (hit) best = hit;
    }
    const step = 2.0;
    const steps = Math.ceil(maxDist / step);
    const box = new AABB();
    for (let i = 0; i < steps; i++) {
      const t0 = i * step, t1 = Math.min((i + 1) * step, maxDist);
      box.set([Math.min(origin[0], origin[0] + dir[0] * t1) - 1, Math.min(origin[1], origin[1] + dir[1] * t1) - 1, Math.min(origin[2], origin[2] + dir[2] * t1) - 1],
        [Math.max(origin[0], origin[0] + dir[0] * t1) + 1, Math.max(origin[1], origin[1] + dir[1] * t1) + 1, Math.max(origin[2], origin[2] + dir[2] * t1) + 1]);
      const cand = this.hash.query(box, this._tmp);
      for (const c of cand) {
        if (!c.enabled) continue;
        if (filter && !filter(c)) continue;
        const hit = c.raycast(origin, dir, maxDist);
        if (hit && (!best || hit.t < best.t)) best = hit;
      }
      if (best && best.t <= t0) break;
    }
    return best;
  }
  // vertical capsule (character) vs world. Returns resolved position.
  moveCapsule(pos, radius, height, motion, opts = {}) {
    const res = { position: [pos[0], pos[1], pos[2]], grounded: false, groundNormal: [0, 1, 0], hitWall: false, hitCeiling: false, groundCollider: null, steps: 0 };
    const target = [pos[0] + motion[0], pos[1] + motion[1], pos[2] + motion[2]];
    const maxSlide = opts.maxSlide || 4;
    for (let step = 0; step < maxSlide; step++) {
      res.steps = step;
      const cand = this.querySphere(target, radius + 0.05);
      let resolved = false;
      for (const c of cand) {
        if (!c.enabled) continue;
        if (opts.ignore && opts.ignore(c)) continue;
        const push = this._resolveCapsule(target, radius, height, c);
        if (push) {
          target[0] += push[0]; target[1] += push[1]; target[2] += push[2];
          resolved = true;
          if (Math.abs(push[1]) > 0.001) { if (push[1] > 0) res.grounded = true; else res.hitCeiling = true; }
          if (Math.abs(push[0]) > 0.001 || Math.abs(push[2]) > 0.001) res.hitWall = true;
        }
      }
      if (!resolved) break;
    }
    // grounds: boxes + terrain
    const groundBox = new AABB([target[0] - radius, target[1] - height / 2 - radius - 0.35, target[2] - radius],
      [target[0] + radius, target[1] - height / 2 + 0.1, target[2] + radius]);
    const near = this.hash.query(groundBox, this._tmp);
    let bestGround = -1e9;
    for (const c of near) {
      if (!c.enabled || c.type !== 'box') continue;
      if (target[0] + radius > c.box.min[0] && target[0] - radius < c.box.max[0] &&
        target[2] + radius > c.box.min[2] && target[2] - radius < c.box.max[2]) {
        const top = c.box.max[1];
        if (top <= target[1] - height / 2 + 0.12 && top > bestGround) { bestGround = top; res.groundCollider = c; }
      }
    }
    if (bestGround > -1e8 && target[1] - height / 2 - bestGround <= 0.32) {
      target[1] = bestGround + height / 2;
      res.grounded = true;
      res.groundNormal = [0, 1, 0];
      res.groundY = bestGround;
    }
    if (this.terrain) {
      const h = this.terrain.heightAt(target[0], target[2]);
      if (target[1] - height / 2 <= h + 0.2) {
        target[1] = h + height / 2;
        res.grounded = true;
        const n = this.terrain.normalAt ? this.terrain.normalAt(target[0], target[2]) : [0, 1, 0];
        res.groundNormal = n;
        res.groundY = h;
      }
    }
    res.position = target;
    return res;
  }
  _resolveCapsule(pos, radius, height, c) {
    const b = c.box;
    if (c.type === 'sphere') {
      const d = [pos[0] - c.center[0], pos[1] - c.center[1], pos[2] - c.center[2]];
      const len = Vec3.len(d);
      const minDist = radius + c.radius;
      if (len >= minDist || len < 1e-6) return null;
      const push = (minDist - len);
      return [d[0] / len * push, d[1] / len * push, d[2] / len * push];
    }
    // vertical capsule (segment along +/- height/2) vs AABB
    const yc = clamp(pos[1], b.min[1] + 1e-4, b.max[1] - 1e-4);
    const cx = clamp(pos[0], b.min[0], b.max[0]);
    const cz = clamp(pos[2], b.min[2], b.max[2]);
    let dx = pos[0] - cx, dz = pos[2] - cz;
    let dist2 = dx * dx + dz * dz;
    const overlapY = (pos[1] + height / 2 + radius > b.min[1]) && (pos[1] - height / 2 - radius < b.max[1]);
    if (!overlapY) return null;
    if (dist2 > radius * radius) {
      // check the sphere caps against the box
      const topD = Math.abs(pos[1] - height / 2 - yc), botD = Math.abs(pos[1] + height / 2 - yc);
      return null;
    }
    // inside the XZ extent: push out to the nearest face
    const insideX = pos[0] > b.min[0] && pos[0] < b.max[0];
    const insideZ = pos[2] > b.min[2] && pos[2] < b.max[2];
    const toMinX = pos[0] - b.min[0], toMaxX = b.max[0] - pos[0];
    const toMinZ = pos[2] - b.min[2], toMaxZ = b.max[2] - pos[2];
    const feet = pos[1] - height / 2;
    const toTop = b.max[1] - feet;
    const toBot = pos[1] + height / 2 - b.min[1];
    const opts = [];
    if (toTop >= 0 && toTop < stepUp()) opts.push([0, toTop, 0]);
    opts.push([-(toMinX + radius), 0, 0], [toMaxX + radius, 0, 0], [0, 0, -(toMinZ + radius)], [0, 0, toMaxZ + radius]);
    if (toBot > 0) opts.push([0, -toBot, 0]);
    let best = null, bestLen = 1e9;
    for (const o of opts) {
      const l = Math.abs(o[0]) + Math.abs(o[1]) + Math.abs(o[2]);
      if (l < bestLen) { bestLen = l; best = o; }
    }
    return best;
  }
}

function stepUp() { return 0.55; }

// A simple kinematic body: gravity, friction, collide-and-slide against world.
class KinematicBody {
  constructor(physics, opts = {}) {
    this.physics = physics;
    this.position = opts.position ? Vec3.of(opts.position) : Vec3.create();
    this.velocity = Vec3.create();
    this.radius = opts.radius || 0.4;
    this.height = opts.height || 1.6;
    this.grounded = false;
    this.drag = opts.drag !== undefined ? opts.drag : 0.02;
    this.bounce = opts.bounce || 0.25;
    this.ignore = opts.ignore || null;
  }
  step(dt) {
    const g = this.physics.gravity;
    this.velocity[1] += g * dt;
    const motion = [this.velocity[0] * dt, this.velocity[1] * dt, this.velocity[2] * dt];
    const res = this.physics.moveCapsule(this.position, this.radius, this.height, motion, { ignore: this.ignore });
    this.position[0] = res.position[0]; this.position[1] = res.position[1]; this.position[2] = res.position[2];
    this.grounded = res.grounded;
    if (res.grounded) {
      if (this.velocity[1] < 0) this.velocity[1] = 0;
      this.velocity[0] *= (1 - this.drag);
      this.velocity[2] *= (1 - this.drag);
    }
    if (res.hitWall) {
      // slide: kill the velocity component into the wall
      const n = res.groundNormal;
      this.velocity[0] *= 0.7; this.velocity[2] *= 0.7;
    }
    if (res.hitCeiling && this.velocity[1] > 0) this.velocity[1] = 0;
    return res;
  }
}
