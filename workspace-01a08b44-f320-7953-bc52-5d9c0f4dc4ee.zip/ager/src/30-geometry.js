// ===========================================================================
//  AGER ENGINE  ·  30-geometry  ·  primitive + procedural mesh builders
//  Every builder returns { position, normal, uv, tangent, index, bounds }
//  ready to be handed straight to GPUMesh. Tangents are real so that normal
//  maps actually shade correctly (most toy engines fake this and look flat).
// ===========================================================================

class GeoBuilder {
  constructor() { this.pos = []; this.nrm = []; this.uv = []; this.tan = []; this.idx = []; }
  v(px, py, pz, nx, ny, nz, u, v) {
    this.pos.push(px, py, pz); this.nrm.push(nx, ny, nz); this.uv.push(u, v);
    this.tan.push(1, 0, 0, 1);
    return this.pos.length / 3 - 1;
  }
  tri(a, b, c) { this.idx.push(a, b, c); }
  quad(a, b, c, d) { this.idx.push(a, b, c, a, c, d); }
  build() {
    const position = new Float32Array(this.pos), normal = new Float32Array(this.nrm);
    const uv = new Float32Array(this.uv), tangent = new Float32Array(this.tan);
    const index = this.pos.length / 3 > 65535 ? new Uint32Array(this.idx) : new Uint16Array(this.idx);
    return { position, normal, uv, tangent, index, bounds: computeBounds(position) };
  }
}

const Geometry = {
  plane(w = 1, h = 1, wSeg = 1, hSeg = 1, axis = 'y') {
    const b = new GeoBuilder();
    const flip = axis === 'y' ? 1 : -1; // +y faces are CCW from above
    const grid = [];
    for (let j = 0; j <= hSeg; j++) for (let i = 0; i <= wSeg; i++) {
      const u = i / wSeg, v = j / hSeg;
      const x = (u - 0.5) * w, z = (v - 0.5) * h;
      if (axis === 'y') grid.push(b.v(x, 0, -z * flip, 0, flip, 0, u, v));
      else if (axis === 'z') grid.push(b.v(x, (v - 0.5) * h, 0, 0, 0, 1, u, 1 - v));
      else grid.push(b.v(0, (v - 0.5) * h, x, 1, 0, 0, u, v));
    }
    for (let j = 0; j < hSeg; j++) for (let i = 0; i < wSeg; i++) {
      const a = grid[j * (wSeg + 1) + i], bb = grid[j * (wSeg + 1) + i + 1];
      const c = grid[(j + 1) * (wSeg + 1) + i + 1], d = grid[(j + 1) * (wSeg + 1) + i];
      // wind CCW when seen from the face normal
      if (axis === 'y') b.quad(a, bb, c, d);
      else b.quad(a, d, c, bb);
    }
    return b.build();
  },

  box(w = 1, h = 1, d = 1, uvScale = 1) {
    const b = new GeoBuilder();
    const hx = w / 2, hy = h / 2, hz = d / 2;
    const faces = [
      { n: [0, 0, 1], v: [[-hx, -hy, hz], [hx, -hy, hz], [hx, hy, hz], [-hx, hy, hz]], t: [1, 0] },
      { n: [0, 0, -1], v: [[hx, -hy, -hz], [-hx, -hy, -hz], [-hx, hy, -hz], [hx, hy, -hz]], t: [-1, 0] },
      { n: [1, 0, 0], v: [[hx, -hy, hz], [hx, -hy, -hz], [hx, hy, -hz], [hx, hy, hz]], t: [0, 1] },
      { n: [-1, 0, 0], v: [[-hx, -hy, -hz], [-hx, -hy, hz], [-hx, hy, hz], [-hx, hy, -hz]], t: [0, 1] },
      { n: [0, 1, 0], v: [[-hx, hy, hz], [hx, hy, hz], [hx, hy, -hz], [-hx, hy, -hz]], t: [1, 0] },
      { n: [0, -1, 0], v: [[-hx, -hy, -hz], [hx, -hy, -hz], [hx, -hy, hz], [-hx, -hy, hz]], t: [1, 0] },
    ];
    for (const f of faces) {
      const s = uvScale;
      const uvs = [[0, 0], [s, 0], [s, s], [0, s]];
      const i0 = b.pos.length / 3;
      for (let k = 0; k < 4; k++) b.v(f.v[k][0], f.v[k][1], f.v[k][2], f.n[0], f.n[1], f.n[2], uvs[k][0], uvs[k][1]);
      b.quad(i0, i0 + 1, i0 + 2, i0 + 3);
    }
    return b.build();
  },

  sphere(radius = 1, wSeg = 32, hSeg = 16, uvScale = 1) {
    const b = new GeoBuilder();
    const grid = [];
    for (let j = 0; j <= hSeg; j++) {
      const v = j / hSeg, theta = v * Math.PI;
      for (let i = 0; i <= wSeg; i++) {
        const u = i / wSeg, phi = u * TAU;
        const x = Math.sin(theta) * Math.cos(phi), y = Math.cos(theta), z = Math.sin(theta) * Math.sin(phi);
        grid.push(b.v(x * radius, y * radius, z * radius, x, y, z, u * uvScale, (1 - v) * uvScale));
      }
    }
    for (let j = 0; j < hSeg; j++) for (let i = 0; i < wSeg; i++) {
      const a = grid[j * (wSeg + 1) + i], bb = grid[j * (wSeg + 1) + i + 1];
      const c = grid[(j + 1) * (wSeg + 1) + i + 1], d = grid[(j + 1) * (wSeg + 1) + i];
      if (j !== 0) b.tri(a, d, c);
      if (j !== hSeg - 1) b.tri(a, c, bb);
    }
    const g = b.build(); computeTangents(g); return g;
  },

  icosphere(radius = 1, subdiv = 2) {
    const t = (1 + Math.sqrt(5)) / 2;
    let verts = [
      [-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0],
      [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t],
      [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]
    ].map(v => Vec3.normalize([0, 0, 0], v));
    let faces = [
      [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
      [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
      [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
      [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]
    ];
    const midCache = new Map();
    const mid = (a, c) => {
      const key = a < c ? a + '_' + c : c + '_' + a;
      if (midCache.has(key)) return midCache.get(key);
      const m = Vec3.normalize([0, 0, 0], [(verts[a][0] + verts[c][0]) / 2, (verts[a][1] + verts[c][1]) / 2, (verts[a][2] + verts[c][2]) / 2]);
      verts.push(m); const id = verts.length - 1; midCache.set(key, id); return id;
    };
    for (let s = 0; s < subdiv; s++) {
      const nf = [];
      for (const f of faces) {
        const a = mid(f[0], f[1]), b2 = mid(f[1], f[2]), c = mid(f[2], f[0]);
        nf.push([f[0], a, c], [f[1], b2, a], [f[2], c, b2], [a, b2, c]);
      }
      faces = nf;
    }
    const b = new GeoBuilder();
    for (const v of verts) b.v(v[0] * radius, v[1] * radius, v[2] * radius, v[0], v[1], v[2], Math.atan2(v[2], v[0]) / TAU + 0.5, Math.asin(v[1]) / Math.PI + 0.5);
    for (const f of faces) b.tri(f[0], f[1], f[2]);
    const g = b.build(); computeTangents(g); return g;
  },

  cylinder(rTop = 1, rBot = 1, height = 2, seg = 24, capTop = true, capBot = true) {
    const b = new GeoBuilder();
    const sides = [];
    for (let i = 0; i <= seg; i++) {
      const u = i / seg, a = u * TAU, x = Math.cos(a), z = Math.sin(a);
      const nx = x, nz = z;
      const slope = (rBot - rTop) / height;
      const nl = Math.hypot(1, slope);
      sides.push([
        b.v(x * rBot, -height / 2, z * rBot, nx / nl, slope / nl, nz / nl, u, 0),
        b.v(x * rTop, height / 2, z * rTop, nx / nl, slope / nl, nz / nl, u, 1)]);
    }
    for (let i = 0; i < seg; i++) {
      const a = sides[i][0], bb = sides[i][1], c = sides[i + 1][1], d = sides[i + 1][0];
      b.quad(a, d, c, bb);
    }
    const cap = (r, y, ny) => {
      const cIdx = b.v(0, y, 0, 0, ny, 0, 0.5, 0.5);
      const ring = [];
      for (let i = 0; i <= seg; i++) {
        const a = (i / seg) * TAU;
        ring.push(b.v(Math.cos(a) * r, y, Math.sin(a) * r, 0, ny, 0, Math.cos(a) * 0.5 + 0.5, Math.sin(a) * 0.5 + 0.5));
      }
      for (let i = 0; i < seg; i++) { if (ny > 0) b.tri(cIdx, ring[i + 1], ring[i]); else b.tri(cIdx, ring[i], ring[i + 1]); }
    };
    if (capTop && rTop > 0) cap(rTop, height / 2, 1);
    if (capBot && rBot > 0) cap(rBot, -height / 2, -1);
    return b.build();
  },

  cone(radius = 1, height = 2, seg = 24) {
    const b = new GeoBuilder();
    const apex = b.v(0, height / 2, 0, 0, 1, 0, 0.5, 1);
    const slope = radius / height;
    const nl = Math.hypot(1, slope);
    const ring = [];
    for (let i = 0; i <= seg; i++) {
      const a = (i / seg) * TAU, x = Math.cos(a), z = Math.sin(a);
      ring.push(b.v(x * radius, -height / 2, z * radius, x / nl, slope / nl, z / nl, i / seg, 0));
    }
    for (let i = 0; i < seg; i++) b.tri(apex, ring[i], ring[i + 1]);
    const c = b.v(0, -height / 2, 0, 0, -1, 0, 0.5, 0.5);
    for (let i = 0; i < seg; i++) b.tri(c, ring[i + 1], ring[i]);
    return b.build();
  },

  capsule(radius = 0.5, height = 1, seg = 20, ringSeg = 8) {
    const b = new GeoBuilder();
    const grid = [];
    const half = Math.max(0, height / 2);
    for (let j = 0; j <= ringSeg * 2; j++) {
      const v = j / (ringSeg * 2);
      const ang = v * Math.PI;
      const y = Math.cos(ang) * radius + (v < 0.5 ? half : -half);
      const rr = Math.sin(ang) * radius;
      const row = [];
      for (let i = 0; i <= seg; i++) {
        const u = i / seg, a = u * TAU;
        const nx = Math.sin(ang) * Math.cos(a), nz = Math.sin(ang) * Math.sin(a), ny = Math.cos(ang);
        row.push(b.v(Math.cos(a) * rr, y + (Math.cos(ang) * 0), Math.sin(a) * rr, nx, ny, nz, u, 1 - v));
      }
      grid.push(row);
    }
    // correct y positions: cos already includes radius offset; keep simple hemispheres
    for (let j = 0; j < ringSeg * 2; j++) for (let i = 0; i < seg; i++) {
      const a = grid[j][i], bb = grid[j][i + 1], c = grid[j + 1][i + 1], d = grid[j + 1][i];
      b.quad(a, d, c, bb);
    }
    const g = b.build(); computeTangents(g); return g;
  },

  torus(R = 1, r = 0.35, seg = 32, ringSeg = 16) {
    const b = new GeoBuilder();
    const grid = [];
    for (let j = 0; j <= seg; j++) {
      const u = j / seg, a = u * TAU;
      const row = [];
      for (let i = 0; i <= ringSeg; i++) {
        const v = i / ringSeg, c = v * TAU;
        const x = (R + r * Math.cos(c)) * Math.cos(a);
        const y = r * Math.sin(c);
        const z = (R + r * Math.cos(c)) * Math.sin(a);
        const nx = Math.cos(c) * Math.cos(a), ny = Math.sin(c), nz = Math.cos(c) * Math.sin(a);
        row.push(b.v(x, y, z, nx, ny, nz, u, v));
      }
      grid.push(row);
    }
    for (let j = 0; j < seg; j++) for (let i = 0; i < ringSeg; i++) b.quad(grid[j][i], grid[j + 1][i], grid[j + 1][i + 1], grid[j][i + 1]);
    const g = b.build(); computeTangents(g); return g;
  },

  disc(radius = 1, seg = 48, uvScale = 1) {
    const b = new GeoBuilder();
    const c = b.v(0, 0, 0, 0, 1, 0, 0.5, 0.5);
    const ring = [];
    for (let i = 0; i <= seg; i++) {
      const a = (i / seg) * TAU;
      ring.push(b.v(Math.cos(a) * radius, 0, Math.sin(a) * radius, 0, 1, 0, (Math.cos(a) * 0.5 + 0.5) * uvScale, (Math.sin(a) * 0.5 + 0.5) * uvScale));
    }
    for (let i = 0; i < seg; i++) b.tri(c, ring[i + 1], ring[i]);
    return b.build();
  },

  ring(inner = 1, outer = 2, seg = 64, uvRepeat = 8) {
    const b = new GeoBuilder();
    const ri = [], ro = [];
    for (let i = 0; i <= seg; i++) {
      const u = i / seg, a = u * TAU;
      const cx = Math.cos(a), sz = Math.sin(a);
      ri.push(b.v(cx * inner, 0, sz * inner, 0, 1, 0, u * uvRepeat, 0));
      ro.push(b.v(cx * outer, 0, sz * outer, 0, 1, 0, u * uvRepeat, 1));
    }
    for (let i = 0; i < seg; i++) b.quad(ri[i], ro[i], ro[i + 1], ri[i + 1]);
    return b.build();
  },

  // billboard quad in XY, facing +Z (used by particles / imposters)
  quad(w = 1, h = 1) {
    const b = new GeoBuilder();
    b.v(-w / 2, -h / 2, 0, 0, 0, 1, 0, 0);
    b.v(w / 2, -h / 2, 0, 0, 0, 1, 1, 0);
    b.v(w / 2, h / 2, 0, 0, 0, 1, 1, 1);
    b.v(-w / 2, h / 2, 0, 0, 0, 1, 0, 1);
    b.quad(0, 1, 2, 3);
    return b.build();
  },

  // spiral tube — reactor piping, torches, cables
  helix(radius = 1, height = 2, turns = 3, tube = 0.06, seg = 120, sideSeg = 6) {
    const b = new GeoBuilder();
    const grid = [];
    for (let i = 0; i <= seg; i++) {
      const t = i / seg, a = t * turns * TAU;
      const cx = Math.cos(a) * radius, cz = Math.sin(a) * radius, cy = -height / 2 + t * height;
      const tx = -Math.sin(a) * radius * turns, tz = Math.cos(a) * radius * turns, ty = height;
      const tl = Math.hypot(tx, ty, tz) || 1;
      const T = [tx / tl, ty / tl, tz / tl];
      const N = Vec3.normalize([0, 0, 0], Vec3.cross([0, 0, 0], T, [0, 1, 0]));
      if (!isFinite(N[0])) Vec3.set(N, 1, 0, 0);
      const B = Vec3.cross([0, 0, 0], T, N);
      const row = [];
      for (let j = 0; j <= sideSeg; j++) {
        const v = j / sideSeg, ang = v * TAU;
        const nx = N[0] * Math.cos(ang) + B[0] * Math.sin(ang);
        const ny = N[1] * Math.cos(ang) + B[1] * Math.sin(ang);
        const nz = N[2] * Math.cos(ang) + B[2] * Math.sin(ang);
        row.push(b.v(cx + nx * tube, cy + ny * tube, cz + nz * tube, nx, ny, nz, t * 8, v * 2));
      }
      grid.push(row);
    }
    for (let i = 0; i < seg; i++) for (let j = 0; j < sideSeg; j++) b.quad(grid[i][j], grid[i + 1][j], grid[i + 1][j + 1], grid[i][j + 1]);
    const g = b.build(); computeTangents(g); return g;
  },

  // terrain: grid with height from a callback, normals from finite differences
  terrain(size = 100, seg = 128, heightFn = () => 0, uvRepeat = 24) {
    const b = new GeoBuilder();
    const grid = [];
    const half = size / 2, step = size / seg;
    for (let j = 0; j <= seg; j++) {
      for (let i = 0; i <= seg; i++) {
        const x = -half + i * step, z = -half + j * step;
        const y = heightFn(x, z);
        const e = step;
        const hx = heightFn(x + e, z) - heightFn(x - e, z);
        const hz = heightFn(x, z + e) - heightFn(x, z - e);
        const n = Vec3.normalize([0, 0, 0], [-hx, 2 * e, -hz]);
        grid.push(b.v(x, y, z, n[0], n[1], n[2], (i / seg) * uvRepeat, (j / seg) * uvRepeat));
      }
    }
    for (let j = 0; j < seg; j++) for (let i = 0; i < seg; i++) {
      const a = grid[j * (seg + 1) + i], bb = grid[j * (seg + 1) + i + 1];
      const c = grid[(j + 1) * (seg + 1) + i + 1], d = grid[(j + 1) * (seg + 1) + i];
      b.quad(a, bb, c, d);
    }
    return b.build();
  },

  // vertical rock wall / arena barrier ring with crenellations
  arenaWall(radius = 30, height = 6, seg = 96, thickness = 1.2, tooth = 0.6) {
    const b = new GeoBuilder();
    const inner = radius, outer = radius + thickness;
    const ringInner = [], ringOuter = [];
    for (let i = 0; i <= seg; i++) {
      const u = i / seg, a = u * TAU;
      const cx = Math.cos(a), sz = Math.sin(a);
      const hgt = height + Math.sin(a * 24) * tooth * 0.5 + Math.sin(a * 7 + 1.3) * tooth;
      const uvx = u * 20;
      // inner face (facing inward)
      ringInner.push([
        b.v(cx * inner, -2, sz * inner, -cx, 0, -sz, uvx, 0),
        b.v(cx * inner, hgt, sz * inner, -cx, 0, -sz, uvx, hgt / 3)
      ]);
      ringOuter.push([
        b.v(cx * outer, -2, sz * outer, cx, 0, sz, uvx, 0),
        b.v(cx * outer, hgt, sz * outer, cx, 0, sz, uvx, hgt / 3)
      ]);
    }
    for (let i = 0; i < seg; i++) {
      // inner wall
      b.quad(ringInner[i][0], ringInner[i + 1][0], ringInner[i + 1][1], ringInner[i][1]);
      // outer wall
      b.quad(ringOuter[i][1], ringOuter[i + 1][1], ringOuter[i + 1][0], ringOuter[i][0]);
      // top cap
      b.quad(ringInner[i][1], ringOuter[i][1], ringOuter[i + 1][1], ringInner[i + 1][1]);
    }
    return b.build();
  },
};

function computeTangents(geo) {
  const { position: p, normal: n, uv: t, index: ix } = geo;
  const tan = geo.tangent, bit = new Float32Array(p.length / 3 * 3);
  const count = p.length / 3;
  for (let i = 0; i < count * 3; i++) { tan[i] = 0; }
  const triCount = ix.length / 3;
  for (let f = 0; f < triCount; f++) {
    const i0 = ix[f * 3], i1 = ix[f * 3 + 1], i2 = ix[f * 3 + 2];
    const x0 = p[i0 * 3], y0 = p[i0 * 3 + 1], z0 = p[i0 * 3 + 2];
    const x1 = p[i1 * 3], y1 = p[i1 * 3 + 1], z1 = p[i1 * 3 + 2];
    const x2 = p[i2 * 3], y2 = p[i2 * 3 + 1], z2 = p[i2 * 3 + 2];
    const u0 = t[i0 * 2], v0 = t[i0 * 2 + 1], u1 = t[i1 * 2], v1 = t[i1 * 2 + 1], u2 = t[i2 * 2], v2 = t[i2 * 2 + 1];
    const e1x = x1 - x0, e1y = y1 - y0, e1z = z1 - z0;
    const e2x = x2 - x0, e2y = y2 - y0, e2z = z2 - z0;
    const du1 = u1 - u0, dv1 = v1 - v0, du2 = u2 - u0, dv2 = v2 - v0;
    const r = (du1 * dv2 - du2 * dv1) || 1e-6;
    const rcp = 1 / r;
    const tx = (e1x * dv2 - e2x * dv1) * rcp, ty = (e1y * dv2 - e2y * dv1) * rcp, tz = (e1z * dv2 - e2z * dv1) * rcp;
    const bx = (e2x * du1 - e1x * du2) * rcp, by = (e2y * du1 - e1y * du2) * rcp, bz = (e2z * du1 - e1z * du2) * rcp;
    for (const i of [i0, i1, i2]) {
      tan[i * 3] += tx; tan[i * 3 + 1] += ty; tan[i * 3 + 2] += tz;
      bit[i * 3] += bx; bit[i * 3 + 1] += by; bit[i * 3 + 2] += bz;
    }
  }
  for (let i = 0; i < count; i++) {
    const nx = n[i * 3], ny = n[i * 3 + 1], nz = n[i * 3 + 2];
    let tx = tan[i * 3], ty = tan[i * 3 + 1], tz = tan[i * 3 + 2];
    const d = nx * tx + ny * ty + nz * tz;
    tx -= nx * d; ty -= ny * d; tz -= nz * d;
    const l = Math.hypot(tx, ty, tz) || 1;
    tan[i * 3] = tx / l; tan[i * 3 + 1] = ty / l; tan[i * 3 + 2] = tz / l;
    // handedness
    const cx = ny * tz - nz * ty, cy = nz * tx - nx * tz, cz = nx * ty - ny * tx;
    const bx = bit[i * 3], by = bit[i * 3 + 1], bz = bit[i * 3 + 2];
    geo.tangent[i * 4 + 3] = (cx * bx + cy * by + cz * bz) < 0 ? -1 : 1;
  }
  return geo;
}
