// ===========================================================================
//  AGER ENGINE  ·  55-particles  ·  GPU particles, decals, trails, ribbons
//
//  One InstancedMesh per emitter, billboarded in the vertex shader, simulated
//  on the CPU into a flat Float32Array. Sparks, smoke, blood, dust, nova rings,
//  bullet tracers and muzzle flashes all run through this.
// ===========================================================================

class ParticleEmitter {
  constructor(scene, opts = {}) {
    this.scene = scene;
    this.capacity = opts.capacity || 256;
    this.count = 0;
    // per particle state (SoA)
    this.px = new Float32Array(this.capacity);
    this.py = new Float32Array(this.capacity);
    this.pz = new Float32Array(this.capacity);
    this.vx = new Float32Array(this.capacity);
    this.vy = new Float32Array(this.capacity);
    this.vz = new Float32Array(this.capacity);
    this.life = new Float32Array(this.capacity);
    this.maxLife = new Float32Array(this.capacity);
    this.size0 = new Float32Array(this.capacity);
    this.size1 = new Float32Array(this.capacity);
    this.rot = new Float32Array(this.capacity);
    this.spin = new Float32Array(this.capacity);
    this.drag = new Float32Array(this.capacity);
    this.gravity = new Float32Array(this.capacity);
    this.r = new Float32Array(this.capacity);
    this.g = new Float32Array(this.capacity);
    this.b = new Float32Array(this.capacity);
    this.fadeIn = new Float32Array(this.capacity);
    this.collide = new Uint8Array(this.capacity);
    this.bounce = new Float32Array(this.capacity);
    this._free = [];
    for (let i = this.capacity - 1; i >= 0; i--) this._free.push(i);
    const mat = (opts.material || MaterialLib.get('sprite')).clone({
      transparent: true, depthWrite: false, defines: { BILLBOARD: 1 }, unlit: true,
      blending: opts.blending || 'additive', castShadow: false, receiveShadow: false,
    });
    this.mesh = scene.makeInstanced(Geometry.quad(1, 1), mat, this.capacity, opts.name || ('particles_' + (++_matId)));
    this.mesh.tag = 'transient';
    this.mesh.skipShadow = true;
    this.mesh.skipReflection = true;
    this.mesh.material.instanceTint = opts.instanceTint || 0;
    this.tmpMat = Mat4.create();
    this.identity = Quat.create();
    this.sortBias = 0;
    this._idx = new Int32Array(this.capacity);
  }
  alive() { return this.count; }
  spawn(o) {
    let i;
    if (this._free.length) i = this._free.pop();
    else { i = 0; let worst = 1e9; for (let k = 0; k < this.capacity; k++) if (this.life[k] < worst) { worst = this.life[k]; i = k; } }
    this.px[i] = o.x || 0; this.py[i] = o.y || 0; this.pz[i] = o.z || 0;
    this.vx[i] = o.vx || 0; this.vy[i] = o.vy || 0; this.vz[i] = o.vz || 0;
    this.maxLife[i] = o.life || 1; this.life[i] = o.life || 1;
    this.size0[i] = o.size !== undefined ? o.size : 0.3;
    this.size1[i] = o.sizeEnd !== undefined ? o.sizeEnd : 0;
    this.rot[i] = o.rot !== undefined ? o.rot : Math.random() * TAU;
    this.spin[i] = o.spin !== undefined ? o.spin : 0;
    this.drag[i] = o.drag !== undefined ? o.drag : 1.2;
    this.gravity[i] = o.gravity !== undefined ? o.gravity : 0;
    this.r[i] = o.color ? o.color[0] : 1; this.g[i] = o.color ? o.color[1] : 1; this.b[i] = o.color ? o.color[2] : 1;
    this.fadeIn[i] = o.fadeIn || 0;
    this.collide[i] = o.collide ? 1 : 0;
    this.bounce[i] = o.bounce !== undefined ? o.bounce : 0.3;
    this.count++;
    return i;
  }
  update(dt, physics = null) {
    const n = this.count;
    if (n === 0) { this.mesh.count = 0; return; }
    this.mesh.begin();
    let alive = 0;
    for (let i = 0; i < this.capacity; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) { this._free.push(i); continue; }
      const t = 1 - this.life[i] / this.maxLife[i];
      const dragK = Math.exp(-this.drag[i] * dt);
      this.vx[i] *= dragK; this.vz[i] *= dragK;
      this.vy[i] = this.vy[i] * dragK + this.gravity[i] * dt;
      this.px[i] += this.vx[i] * dt; this.py[i] += this.vy[i] * dt; this.pz[i] += this.vz[i] * dt;
      if (this.collide[i] && physics) {
        const h = physics.terrain ? physics.terrain.heightAt(this.px[i], this.pz[i]) : -1e9;
        if (this.py[i] < h + 0.02) { this.py[i] = h + 0.02; this.vy[i] = Math.abs(this.vy[i]) * this.bounce[i]; this.vx[i] *= 0.6; this.vz[i] *= 0.6; }
      }
      this.rot[i] += this.spin[i] * dt;
      const size = lerp(this.size0[i], this.size1[i], t * (this.size1[i] > this.size0[i] ? 1.0 : 1.0));
      const fade = t < this.fadeIn[i] && this.fadeIn[i] > 0 ? t / this.fadeIn[i] : 1 - Math.max(0, (t - 0.65) / 0.35);
      Mat4.fromTRS(this.tmpMat, [this.px[i], this.py[i], this.pz[i]], this.identity, [size, size, size]);
      // colour + alpha packed into the instance data (x = tint select handled by material)
      this.mesh.instances.pushMat(this.tmpMat, [this.r[i], this.g[i], this.b[i], this.rot[i]]);
      this.mesh.count++;
      alive++;
    }
    this.count = alive;
  }
}

// --- higher level fx helpers ----------------------------------------------
const FX = {
  emitters: {},
  physics: null,
  spritePool: null,

  init(scene, physics) {
    this.scene = scene;
    this.physics = physics;
    this.emitters.spark = new ParticleEmitter(scene, { capacity: 900, name: 'fx_sparks', material: MaterialLib.get('sprite'), blending: 'additive' });
    this.emitters.smoke = new ParticleEmitter(scene, { capacity: 400, name: 'fx_smoke', material: MaterialLib.get('smoke'), blending: 'normal' });
    this.emitters.debris = new ParticleEmitter(scene, { capacity: 500, name: 'fx_debris', material: MaterialLib.get('smoke'), blending: 'normal' });
    this.emitters.trail = new ParticleEmitter(scene, { capacity: 600, name: 'fx_trail', material: MaterialLib.get('sprite'), blending: 'additive' });
    this.emitters.ring = new ParticleEmitter(scene, { capacity: 200, name: 'fx_rings', material: MaterialLib.get('sprite'), blending: 'additive' });
    // material tweak: particles take colour from the instance data
    for (const e of Object.values(this.emitters)) {
      if (!e.mesh.material.uniforms_inst) {
        // patch the shader path: colour lives in vInst.rgb
        e.mesh.material.defines.PARTICLE = 1;
      }
    }
    this.decals = [];
    this.decalMesh = scene.makeInstanced(Geometry.quad(1, 1), MaterialLib.get('decal').clone({
      defines: { BILLBOARD: 0 }, transparent: true, depthWrite: false, castShadow: false, receiveShadow: false,
    }), 64, 'fx_decals');
    this.decalMesh.tag = 'transient';
    this.decalMesh.skipShadow = true;
    this.maxDecals = 48;
    this.ringMesh = null;
    return this;
  },

  update(dt) {
    for (const e of Object.values(this.emitters)) e.update(dt, this.physics);
    // decals: keep only the newest N
    while (this.decals.length > this.maxDecals) this.decals.shift();
    this.decalMesh.begin();
    const up = Quat.create();
    for (const d of this.decals) {
      Quat.fromEuler(up, -Math.PI / 2 + (d.tilt || 0), d.rot || 0, 0);
      Mat4.fromTRS(this.decalMesh._mat, [d.x, d.y + 0.02, d.z], up, [d.size, d.size, d.size]);
      this.decalMesh.instances.pushMat(this.decalMesh._mat, [d.age / d.life, 0, 0, 0]);
      this.decalMesh.count++;
      d.age += dt;
    }
    this.decals = this.decals.filter(d => d.age < d.life);
  },

  decal(x, y, z, size = 1, life = 12, rot = Math.random() * TAU) {
    this.decals.push({ x, y, z, size, life, age: 0, rot, tilt: 0 });
  },

  burst(position, opts = {}) {
    const e = this.emitters[opts.emitter || 'spark'];
    const n = opts.count || 12;
    for (let i = 0; i < n; i++) {
      const dir = opts.dir || null;
      let vx, vy, vz;
      const speed = (opts.speed !== undefined ? opts.speed : 6) * (0.5 + Math.random());
      if (dir) {
        const sx = (Math.random() - 0.5) * (opts.spread !== undefined ? opts.spread : 0.8);
        const sy = (Math.random() - 0.5) * (opts.spread !== undefined ? opts.spread : 0.8);
        const sz = (Math.random() - 0.5) * (opts.spread !== undefined ? opts.spread : 0.8);
        vx = (dir[0] + sx) * speed; vy = (dir[1] + sy) * speed; vz = (dir[2] + sz) * speed;
      } else {
        const a = Math.random() * TAU, u = Math.random() * 2 - 1, s = Math.sqrt(1 - u * u);
        vx = s * Math.cos(a) * speed; vy = u * speed * 0.8 + (opts.up || 1); vz = s * Math.sin(a) * speed;
      }
      e.spawn({
        x: position[0] + (Math.random() - 0.5) * (opts.jitter || 0.1),
        y: position[1] + (Math.random() - 0.5) * (opts.jitter || 0.1),
        z: position[2] + (Math.random() - 0.5) * (opts.jitter || 0.1),
        vx, vy, vz,
        life: (opts.life || 0.6) * (0.6 + Math.random() * 0.8),
        size: (opts.size || 0.22) * (0.7 + Math.random() * 0.6),
        sizeEnd: opts.sizeEnd !== undefined ? opts.sizeEnd : 0.02,
        color: opts.color || [1, 0.75, 0.35],
        drag: opts.drag !== undefined ? opts.drag : 2.0,
        gravity: opts.gravity !== undefined ? opts.gravity : 0,
        collide: opts.collide !== undefined ? opts.collide : true,
        bounce: 0.35,
        spin: (Math.random() - 0.5) * 6,
        fadeIn: 0.05,
      });
    }
  },

  smoke(position, count = 6, opts = {}) {
    const e = this.emitters.smoke;
    for (let i = 0; i < count; i++) {
      e.spawn({
        x: position[0] + (Math.random() - 0.5) * 0.4, y: position[1] + Math.random() * 0.3, z: position[2] + (Math.random() - 0.5) * 0.4,
        vx: (Math.random() - 0.5) * 0.9, vy: 0.5 + Math.random() * 0.8, vz: (Math.random() - 0.5) * 0.9,
        life: (opts.life || 1.8) * (0.7 + Math.random() * 0.6),
        size: opts.size || 0.5, sizeEnd: (opts.size || 0.5) * 3.2,
        color: opts.color || [0.4, 0.4, 0.42],
        drag: 0.6, gravity: 0.2, fadeIn: 0.2, spin: (Math.random() - 0.5) * 1.2,
      });
    }
  },

  debris(position, count = 14, opts = {}) {
    const e = this.emitters.debris;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * TAU;
      e.spawn({
        x: position[0], y: position[1], z: position[2],
        vx: Math.cos(a) * (2 + Math.random() * 5), vy: 2 + Math.random() * 5, vz: Math.sin(a) * (2 + Math.random() * 5),
        life: 1.4 + Math.random() * 1.2,
        size: 0.1 + Math.random() * 0.14, sizeEnd: 0.02,
        color: opts.color || [0.55, 0.53, 0.5],
        drag: 0.35, gravity: -14, collide: true, bounce: 0.3, spin: (Math.random() - 0.5) * 14,
      });
    }
  },

  trail(position, color, size = 0.16) {
    this.emitters.trail.spawn({
      x: position[0], y: position[1], z: position[2], vx: 0, vy: 0.2, vz: 0,
      life: 0.35, size, sizeEnd: 0.01, color, drag: 3, fadeIn: 0.1,
    });
  },

  ring(position, color = [0.4, 0.9, 1], count = 20, speed = 12, life = 0.5) {
    for (let i = 0; i < count; i++) {
      const a = (i / count) * TAU;
      this.emitters.ring.spawn({
        x: position[0], y: position[1], z: position[2],
        vx: Math.cos(a) * speed, vy: 0.6, vz: Math.sin(a) * speed,
        life, size: 0.5, sizeEnd: 0.1, color, drag: 4.5, gravity: 0, fadeIn: 0.1,
      });
    }
  },
};
