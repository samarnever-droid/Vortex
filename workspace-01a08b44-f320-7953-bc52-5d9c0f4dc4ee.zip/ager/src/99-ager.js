// ===========================================================================
//  AGER ENGINE  ·  99-ager  ·  engine facade, boot, HUD/console, spec loader
// ===========================================================================

const PRIMITIVES = {
  box: (a) => Geometry.box(a[0] || 1, a[1] || 1, a[2] || 1, a[3] || 1),
  sphere: (a) => Geometry.sphere(a[0] || 0.5, a[1] || 24, a[2] || 16, a[3]),
  icosphere: (a) => Geometry.icosphere(a[0] || 0.5, a[1] || 2),
  cylinder: (a) => Geometry.cylinder(a[0] || 0.5, a[1] || 0.5, a[2] || 1, a[3] || 20),
  cone: (a) => Geometry.cone(a[0] || 0.5, a[1] || 1, a[2] || 20),
  capsule: (a) => Geometry.capsule(a[0] || 0.4, a[1] || 1, a[2] || 16),
  torus: (a) => Geometry.torus(a[0] || 0.6, a[1] || 0.18, a[2] || 28, a[3] || 14),
  plane: (a) => Geometry.plane(a[0] || 1, a[1] || 1, a[2] || 1, a[3] || 1),
  disc: (a) => Geometry.disc(a[0] || 1, a[1] || 32),
  ring: (a) => Geometry.ring(a[0] || 1, a[1] || 2, a[2] || 48),
  quad: (a) => Geometry.quad(a[0] || 1, a[1] || 1),
  helix: (a) => Geometry.helix(a[0] || 1, a[1] || 2, a[2] || 3, a[3] || 0.06),
  wall: (a) => Geometry.arenaWall(a[0] || 30, a[1] || 6, a[2] || 96, a[3] || 1.2, a[4] || 0.6),
};

// ---------------------------------------------------------------------------
//  Material library — built from the procedural texture lab
// ---------------------------------------------------------------------------
const MaterialLib = {
  registry: {},
  tex: {},
  splatMap: null,

  build(device, size = 256, onProgress) {
    const lib = TexLab.buildAll(size, onProgress);
    // albedo/emissive are sRGB (hardware converts to linear on sample),
    // orm + normal are linear data textures.
    const up = (t, srgb) => fromImageData(device, t, { mips: true, aniso: 8, srgb: !!srgb });
    for (const [key, t] of Object.entries(lib)) {
      this.tex[key] = up(t.albedo, true);
      this.tex[key + '_orm'] = up(t.orm, false);
      this.tex[key + '_normal'] = up(t.normal, false);
      this.tex[key + '_emissive'] = up(t.emiss, true);
    }
    // terrain splat weights (procedural, no authoring tools needed)
    const S = 256;
    const splat = new TexData(S, S);
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const u = x / S * 6, v = y / S * 6;
      const a = fbm2(u, v, 5);
      const b = fbm2(u + 13.7, v - 4.1, 7);
      const c = fbm2(u * 0.5 + 31.1, v * 0.5 + 7.7, 3);
      const dd = fbm2(u * 1.7 - 9.3, v * 1.7 + 2.2, 9);
      const sum = a + b + c + dd;
      const i = (y * S + x) * 4;
      splat.data[i] = (a / sum) * 255; splat.data[i + 1] = (b / sum) * 255;
      splat.data[i + 2] = (c / sum) * 255; splat.data[i + 3] = (dd / sum) * 255;
    }
    this.splatMap = up(splat, false);

    const T = this.tex;
    const M = (name, opts) => (this.registry[name] = new Material(Object.assign({ name }, opts)));
    M('metal', { color: 0xf2f4f6, roughness: 1.0, metalness: 1.0, maps: { albedo: T.metalPlate, orm: T.metalPlate_orm, normal: T.metalPlate_normal }, uvScale: [2, 2] });
    M('metalDark', { color: 0x8d949c, roughness: 1.0, metalness: 1.0, maps: { albedo: T.metalPlate, orm: T.metalPlate_orm, normal: T.metalPlate_normal }, uvScale: [3.5, 3.5] });
    M('hull', { color: 0xb9c3cc, roughness: 0.9, metalness: 1.0, maps: { albedo: T.metalPlate, orm: T.metalPlate_orm, normal: T.metalPlate_normal }, uvScale: [6, 6] });
    M('concrete', { color: 0xb9b3a8, roughness: 1.0, metalness: 0.0, maps: { albedo: T.concrete, orm: T.concrete_orm, normal: T.concrete_normal }, uvScale: [1.4, 1.4] });
    M('crate', { color: 0xffffff, roughness: 1.0, metalness: 0.35, maps: { albedo: T.crate, orm: T.crate_orm, normal: T.crate_normal }, uvScale: [1, 1] });
    M('basalt', { color: 0xffffff, roughness: 1.0, metalness: 0.05, maps: { albedo: T.basalt, orm: T.basalt_orm, normal: T.basalt_normal }, uvScale: [3, 3] });
    M('energy', { color: 0x0a0f14, roughness: 0.5, metalness: 0.4, emissiveIntensity: 2.2, maps: { albedo: T.energy, orm: T.energy_orm, normal: T.energy_normal, emissive: T.energy_emissive }, uvScale: [1, 1] });
    M('hazard', { color: 0xffffff, roughness: 0.85, metalness: 0.2, maps: { albedo: T.hazard, orm: T.hazard_orm, normal: T.hazard_normal }, uvScale: [4, 1] });
    M('glass', { color: 0x9fd8ff, roughness: 0.06, metalness: 0.0, transparent: true, opacity: 0.24, maps: { orm: T.glass_orm, normal: T.glass_normal }, doubleSided: true, castShadow: false });
    M('terrain', {
      color: 0xffffff, roughness: 1.0, metalness: 0.0, splat: true, splatScale: 0.05,
      maps: { splat: this.splatMap, layerA: T.sand, layerB: T.rock, layerC: T.turf, layerD: T.basalt },
      normalScale: 0.7,
    });
    M('sand', { color: 0xffffff, roughness: 1.0, metalness: 0, maps: { albedo: T.sand, orm: T.sand_orm, normal: T.sand_normal }, uvScale: [12, 12] });
    M('rock', { color: 0xffffff, roughness: 1.0, metalness: 0, maps: { albedo: T.rock, orm: T.rock_orm, normal: T.rock_normal }, uvScale: [8, 8] });
    M('turf', { color: 0xffffff, roughness: 1.0, metalness: 0, maps: { albedo: T.turf, orm: T.turf_orm, normal: T.turf_normal }, uvScale: [10, 10] });
    M('glow', { color: 0x39e2ff, emissive: 0x39e2ff, emissiveIntensity: 2.6, unlit: true });
    M('glowWarm', { color: 0xff8a2a, emissive: 0xff8a2a, emissiveIntensity: 2.6, unlit: true });
    M('glowGreen', { color: 0x7dff9a, emissive: 0x7dff9a, emissiveIntensity: 2.6, unlit: true });
    M('glowRed', { color: 0xff4444, emissive: 0xff4444, emissiveIntensity: 2.6, unlit: true });
    M('sprite', { color: 0xffffff, unlit: true, transparent: true, blending: 'additive', depthWrite: false, maps: { albedo: T.radial }, defines: { BILLBOARD: 1 }, castShadow: false, receiveShadow: false });
    M('smoke', { color: 0xffffff, unlit: true, transparent: true, depthWrite: false, maps: { albedo: T.smoke }, defines: { BILLBOARD: 1 }, castShadow: false, receiveShadow: false });
    M('decal', { color: 0xffffff, transparent: true, depthWrite: false, maps: { albedo: T.scorch }, doubleSided: true, castShadow: false, receiveShadow: false });
    M('crystal', { color: 0x2ad4ff, roughness: 0.15, metalness: 0.1, emissive: 0x0a5f80, emissiveIntensity: 0.9, transparent: true, opacity: 0.75, doubleSided: true, maps: { normal: T.glass_normal } });
    M('shield', { color: 0x59d2ff, roughness: 0.1, metalness: 0.0, transparent: true, opacity: 0.18, blending: 'additive', depthWrite: false, doubleSided: true, castShadow: false });
    return this.registry;
  },
  get(name) { return this.registry[name] || this.registry.metal; },
};

// ---------------------------------------------------------------------------
//  Engine
// ---------------------------------------------------------------------------
const Engine = {
  device: null, renderer: null, scene: null, camera: null, input: null, audio: null, music: null,
  physics: null, clock: null, running: false, paused: false, timeScale: 1, frame: 0,
  time: 0, stats: {}, callbacks: { update: [], lateUpdate: [], render: [], resize: [] },
  assets: null, canvas: null, ui: null, loading: null,
  on: function (kind, fn) { (this.callbacks[kind] = this.callbacks[kind] || []).push(fn); return fn; },
  off: function (kind, fn) { const a = this.callbacks[kind] || []; const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1); },

  stats_() {
    const r = this.renderer;
    return {
      fps: Math.round(this.clock ? this.clock.fps : 0),
      frameMs: this.clock ? +(this.clock.dt * 1000).toFixed(1) : 0,
      drawCalls: r ? r.stats.drawCalls : 0,
      triangles: r ? Math.round(r.stats.triangles) : 0,
      lights: this.scene ? this.scene.pointLights.length + this.scene.spotLights.length : 0,
      entities: this.scene ? this.scene.meshes.length : 0,
      shadowDraws: r ? r.stats.shadowDraws : 0,
      resolution: r ? `${r.width}x${r.height}` : '',
      quality: r ? r.quality : '',
      backend: this.device ? this.device.renderer : '',
      physicsBodies: this.physics ? this.physics.colliders.length : 0,
    };
  },

  boot(canvas, opts = {}) {
    this.canvas = canvas;
    const params = new URLSearchParams(location.search);
    const qualityParam = params.get('quality');
    const device = new Device(canvas, { preserveDrawingBuffer: !!opts.preserveDrawingBuffer });
    this.device = device;
    // auto-detect software rasterisers so the demo is at least interactive
    const swRenderer = /swiftshader|llvmpipe|software|angle \(google/i.test(device.renderer);
    const quality = qualityParam || opts.quality || (swRenderer ? 'low' : 'high');
    const renderer = new Renderer(device, {
      quality,
      resScale: opts.resScale !== undefined ? opts.resScale : (swRenderer ? 0.55 : (quality === 'ultra' ? 1.0 : 1.0)),
      shadowMapSize: opts.shadowMapSize || (swRenderer ? 512 : undefined),
    });
    this.renderer = renderer;
    if (opts.exposure !== undefined) renderer.exposure = opts.exposure;
    this.clock = new Clock();
    this.input = new Input(canvas, opts.input || {});
    this.audio = new AudioEngine();
    this.music = new MusicDirector(this.audio);
    const dpr = opts.pixelRatio || Math.min(devicePixelRatio || 1, quality === 'low' ? 1.0 : 2);
    const resize = () => {
      const w = Math.floor((canvas.clientWidth || innerWidth) * dpr);
      const h = Math.floor((canvas.clientHeight || innerHeight) * dpr);
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      renderer.resize(canvas.width, canvas.height);
      if (this.camera) this.camera.aspect = canvas.width / canvas.height;
      for (const fn of this.callbacks.resize) fn(canvas.width, canvas.height);
    };
    addEventListener('resize', resize);
    resize();
    this.resize = resize;
    this.assets = { materials: MaterialLib };
    if (MaterialLib.tex.noiseTile) renderer.blueNoise = MaterialLib.tex.noiseTile;
    this.time = 0;
    return this;
  },

  start() {
    if (this.running) return;
    this.running = true;
    const loop = () => {
      if (!this.running) return;
      requestAnimationFrame(loop);
      this.tick();
    };
    requestAnimationFrame(loop);
  },
  stop() { this.running = false; },

  tick() {
    const clock = this.clock;
    const rawDt = clock.tick();
    if (this.paused) { return; }
    const dt = Math.min(rawDt, 0.05) * this.timeScale;
    this.time += dt;
    this.frame++;
    this.input.beginFrame();
    this.input.pollGamepad();
    // fixed-step logic (120 Hz) for deterministic movement
    this._acc = (this._acc || 0) + dt;
    const step = 1 / 120;
    let steps = 0;
    while (this._acc >= step && steps < 8) {
      for (const fn of this.callbacks.update) fn(step, this.time);
      this._acc -= step;
      steps++;
    }
    for (const fn of this.callbacks.lateUpdate) fn(dt, this.time);
    if (this.scene && this.camera) {
      this.scene.update(dt);
      this.renderer.render(this.scene, this.camera, dt);
      for (const fn of this.callbacks.render) fn(dt, this.time);
    }
    this.input.endFrame();
    if (this.audio && this.audio.ready) this.audio.updateListener(this.camera);
    if (this.ui) this.ui.tick(dt, this.stats_());
  },
};

// ---------------------------------------------------------------------------
//  Ager facade
// ---------------------------------------------------------------------------
const Ager = {
  version: AGER_VERSION,
  Engine, MaterialLib, Geometry, Mat4, Vec3, Quat, AABB, PhysicsWorld, Input, AudioEngine,
  TexLab, SkyModel, PRIMITIVES, AgerAI,

  create(opts = {}) {
    const canvas = opts.canvas || (() => {
      const c = document.createElement('canvas');
      c.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;display:block';
      c.id = 'ager-canvas';
      document.body.appendChild(c);
      return c;
    })();
    Engine.boot(canvas, opts);
    Engine.scene = new Scene('world');
    Engine.camera = new Camera(opts.fov || 68, canvas.width / canvas.height, opts.near || 0.06, opts.far || 900);
    Engine.camera.setPosition(0, 2, 8);
    Engine.scene.add(Engine.camera);
    Engine.physics = new PhysicsWorld({ gravity: opts.gravity !== undefined ? opts.gravity : -22 });
    Engine.ui = opts.ui === false ? null : new AgerUI();
    AgerAI.context.engine = Engine;
    AgerAI.context.scene = Engine.scene;
    AgerAI.context.camera = Engine.camera;
    this._registerCoreOps();
    return { engine: Engine, scene: Engine.scene, camera: Engine.camera, device: Engine.device, renderer: Engine.renderer };
  },

  // --- texture / material helpers ------------------------------------------
  upload(TexData, opts = {}) {
    return fromImageData(Engine.device, TexData, Object.assign({ mips: true, aniso: 8 }, opts));
  },
  material(nameOrOpts) {
    if (typeof nameOrOpts === 'string') return MaterialLib.get(nameOrOpts);
    return new Material(nameOrOpts);
  },
  geometry(name, args = []) {
    const fn = PRIMITIVES[name];
    if (!fn) throw new Error('unknown primitive: ' + name + ' (have: ' + Object.keys(PRIMITIVES).join(', ') + ')');
    const g = fn(args);
    g.primitiveKey = name;
    return g;
  },
  mesh(geometryOrName, materialName = 'metal', opts = {}) {
    const g = typeof geometryOrName === 'string' ? this.geometry(geometryOrName, opts.args || []) : geometryOrName;
    const m = new Mesh(g, MaterialLib.get(materialName), opts.name);
    m.geometryKey = g.primitiveKey || 'mesh';
    m.tag = opts.tag || '';
    if (opts.position) m.setPosition(opts.position[0], opts.position[1], opts.position[2]);
    if (opts.rotation) m.setRotation(opts.rotation[0], opts.rotation[1], opts.rotation[2]);
    if (opts.scale) m.setScale(opts.scale[0], opts.scale[1], opts.scale[2] !== undefined ? opts.scale[2] : opts.scale[0]);
    Engine.scene.addMesh(m);
    return m;
  },
  instanced(geometryOrName, materialName, capacity = 512, opts = {}) {
    const g = typeof geometryOrName === 'string' ? this.geometry(geometryOrName, opts.args || []) : geometryOrName;
    const m = Engine.scene.makeInstanced(g, MaterialLib.get(materialName), capacity, opts.name);
    m.tag = opts.tag || '';
    return m;
  },
  light(type, opts = {}) {
    const l = new Light(type, opts);
    if (opts.position) l.setPosition(opts.position[0], opts.position[1], opts.position[2]);
    if (opts.target) l.lookAt(opts.target);
    Engine.scene.addLight(l);
    l.update(0);
    return l;
  },
  sun(opts) { Object.assign(Engine.scene.sun, opts); return Engine.scene.sun; },
  update(fn) { Engine.on('update', fn); return fn; },

  // --- declarative world description (AI / data friendly) -------------------
  loadSpec(spec) {
    const results = [];
    if (spec.sun) Object.assign(Engine.scene.sun, spec.sun);
    if (spec.sky) Object.assign(Engine.scene.sky, spec.sky);
    if (spec.fog) Object.assign(Engine.scene.fog, spec.fog);
    for (const e of (spec.entities || [])) {
      const mesh = this.mesh(e.geometry || 'box', e.material || 'metal', {
        name: e.name, tag: e.tag, args: e.args,
        position: e.position, rotation: e.rotation, scale: e.scale,
      });
      if (e.collider) {
        const size = e.colliderSize || (e.scale ? [e.scale[0], e.scale[1], e.scale[2]] : [1, 1, 1]);
        Engine.physics.addBox(mesh, size, { tag: e.tag || 'world', material: e.material || 'metal' });
      }
      results.push(mesh);
    }
    for (const l of (spec.lights || [])) this.light(l.type || 'point', l);
    return results;
  },

  serialize() { return AgerAI.serialize(Engine.scene); },

  // --- AI entry points -----------------------------------------------------
  describe() { return AgerAI.describe(); },
  describeText() { return AgerAI.describeText(); },
  spawn(op, args) { return AgerAI.op(op, args); },
  say(text) { return AgerAI.say(text); },
  query(filter = {}) {
    const out = [];
    for (const m of Engine.scene.meshes) {
      if (filter.tag && m.tag !== filter.tag) continue;
      if (filter.name && m.name !== filter.name) continue;
      if (filter.material && (!m.material || m.material.name !== filter.material)) continue;
      out.push({
        name: m.name, tag: m.tag, geometry: m.geometryKey, material: m.material ? m.material.name : null,
        position: Array.from(m.position).map(v => +v.toFixed(3)),
        visible: m.visible, instanced: !!m.isInstanced, count: m.count || 0,
      });
    }
    return out;
  },
  stats() { return Engine.stats_(); },
  screenshot(type = 'image/png') { return Engine.canvas.toDataURL(type); },

  _registerCoreOps() {
    const scene = () => Engine.scene;
    const r = AgerAI.router;
    r.register('spawn', (a) => {
      const type = (a.type || 'crate').toLowerCase();
      const count = clamp(a.count | 0 || 1, 1, 200);
      const near = a.near || 'ahead';
      const cam = Engine.camera;
      const cp = cam.getWorldPosition([0, 0, 0]);
      const fwd = cam.getForward([0, 0, 0]);
      const anchor = near === 'player' || near === 'me' ? cp : [cp[0] + fwd[0] * 6, cp[1] + fwd[1] * 6, cp[2] + fwd[2] * 6];
      const matMap = { crate: 'crate', barrel: 'metalDark', box: 'concrete', sphere: 'metal', rock: 'rock', crystal: 'crystal', drone: 'metalDark' };
      const geoMap = { crate: 'box', barrel: 'cylinder', box: 'box', sphere: 'sphere', rock: 'icosphere', crystal: 'icosphere', drone: 'icosphere' };
      const spawned = [];
      for (let i = 0; i < count; i++) {
        const scatter = a.scatter || 4;
        const m = Ager.mesh(geoMap[type] || 'box', matMap[type] || 'metalDark', {
          name: type + '_' + Math.floor(Math.random() * 1e6).toString(36), tag: 'prop',
          args: type === 'barrel' ? [0.35, 0.35, 0.9, 16] : [0.6, 0.6, 0.6],
          position: [anchor[0] + (Math.random() - 0.5) * scatter, Math.max(0.4, anchor[1] + (Math.random() - 0.5) * 1.5), anchor[2] + (Math.random() - 0.5) * scatter],
        });
        m.setRotation(0, Math.random() * TAU, 0);
        Engine.physics.addBox(m, [0.6, 0.6, 0.6], { static: true, tag: 'prop' });
        spawned.push(m.name);
      }
      return { result: `spawned ${count} ${type}(s) near ${near}`, count, names: spawned.slice(0, 5) };
    }, 'spawn {type, count, near, scatter} — add props to the world');
    r.register('remove', (a) => {
      const q = Ager.query({ tag: a.tag || 'prop' });
      let n = 0;
      for (const info of q) {
        const m = Engine.scene.meshes.find(x => x.name === info.name);
        if (m && (a.name ? m.name === a.name : true)) { Engine.scene.remove(m); n++; if (a.name) break; }
      }
      return { result: `removed ${n} entities` };
    }, 'remove {tag|name} — delete entities');
    r.register('clearProps', () => {
      const q = Ager.query({ tag: 'prop' });
      for (const info of q) { const m = Engine.scene.meshes.find(x => x.name === info.name); if (m) Engine.scene.remove(m); }
      return { result: `cleared ${q.length} props` };
    }, 'clearProps — remove all props');
    r.register('time', (a) => {
      const presets = {
        dawn: [6 * DEG, 100 * DEG, [1.0, 0.72, 0.52], 1.6], sunrise: [8 * DEG, 110 * DEG, [1.0, 0.78, 0.58], 2.2],
        noon: [62 * DEG, 120 * DEG, [1.0, 0.98, 0.94], 3.4], day: [48 * DEG, 130 * DEG, [1.0, 0.96, 0.9], 3.2],
        dusk: [9 * DEG, 250 * DEG, [1.0, 0.52, 0.30], 1.5], sunset: [5 * DEG, 262 * DEG, [1.0, 0.42, 0.22], 1.1],
        night: [-14 * DEG, 300 * DEG, [0.30, 0.40, 0.68], 0.28],
      };
      const p = presets[a.preset] || presets[dusk];
      scene().setSunFromAngles(p[0] * (1), p[1], p[2], p[3]);
      scene().sky.night = a.preset === 'night' ? 1 : clamp(1 - p[0] * RAD / 6, 0, 1) * 0.9;
      scene().sky.turbidity = a.preset === 'night' ? 0.2 : (a.preset === 'dusk' || a.preset === 'sunset' ? 1.1 : 0.45);
      Engine.renderer.envDirty = true;
      return { result: `time set to ${a.preset}` };
    }, 'time {preset: dawn|noon|dusk|sunset|night}');
    r.register('weather', (a) => {
      const s = scene();
      if (a.type === 'storm') { s.fog.density = 0.02; s.fog.color = [0.30, 0.33, 0.38]; s.sky.turbidity = 1.4; s.sun.intensity *= 0.5; Engine.rain = 1.0; }
      else if (a.type === 'rain') { s.fog.density = 0.012; s.fog.color = [0.36, 0.40, 0.46]; Engine.rain = 0.6; }
      else { s.fog.density = 0.0055; s.fog.color = [0.36, 0.44, 0.56]; s.sky.turbidity = 0.45; Engine.rain = 0; }
      Engine.renderer.envDirty = true;
      return { result: `weather: ${a.type}` };
    }, 'weather {type: clear|rain|storm}');
    r.register('bloom', (a) => { Engine.renderer.bloomStrength = clamp((Engine.renderer.bloomStrength || 0.09) + (a.value || 0.03), 0, 1.2); return { result: 'bloom ' + Engine.renderer.bloomStrength.toFixed(3) }; }, 'bloom {value}');
    r.register('exposure', (a) => { Engine.renderer.exposure = clamp(Engine.renderer.exposure + (a.value || 0.1), 0.05, 6); return { result: 'exposure ' + Engine.renderer.exposure.toFixed(2) }; }, 'exposure {value}');
    r.register('fog', (a) => {
      const f = scene().fog;
      f.density = a.mode === 'more' ? Math.min(0.06, f.density * 2) : Math.max(0.0005, f.density * 0.5);
      return { result: 'fog density ' + f.density.toFixed(5) };
    }, 'fog {mode: more|less}');
    r.register('timescale', (a) => { Engine.timeScale = clamp(a.value || 1, 0.05, 4); return { result: 'timeScale ' + Engine.timeScale }; }, 'timescale {value}');
    r.register('stats', () => ({ result: JSON.stringify(Engine.stats_()) }), 'stats — engine statistics');
    r.register('wireframe', () => { Engine.renderer.wireframe = !Engine.renderer.wireframe; return { result: 'wireframe ' + Engine.renderer.wireframe }; }, 'wireframe — toggle wireframe mode');
    r.register('screenshot', () => {
      try {
        const url = Ager.screenshot();
        const a = document.createElement('a'); a.href = url; a.download = 'ager-' + Date.now() + '.png'; a.click();
        return { result: 'screenshot saved' };
      } catch (e) { return { result: 'screenshot failed: ' + e.message }; }
    }, 'screenshot — download a png');
    r.register('regenTextures', () => {
      TexLab.cache.clear();
      MaterialLib.build(Engine.device, 256);
      return { result: 'textures regenerated' };
    }, 'regenTextures — rebuild every procedural texture');
    r.register('describe', () => ({ result: AgerAI.describeText() }), 'describe — engine + world summary');
    r.register('quality', (a) => {
      const q = a.level || 'high';
      Engine.renderer.quality = q;
      Engine.renderer.shadowMapSize = q === 'low' ? 512 : (q === 'medium' ? 1024 : 1536);
      Engine.renderer.enableSSAO = q !== 'low';
      Engine.renderer.enableBloom = q !== 'low';
      Engine.renderer.resScale = q === 'low' ? 0.6 : (q === 'medium' ? 0.8 : 1.0);
      Engine.renderer.resize(Engine.canvas.width, Engine.canvas.height);
      return { result: 'quality: ' + q };
    }, 'quality {level: low|medium|high}');
  },
};

// ---------------------------------------------------------------------------
//  UI — HUD host, console, stats overlay, toasts (pure DOM, no dependencies)
// ---------------------------------------------------------------------------
class AgerUI {
  constructor() {
    this.root = document.createElement('div');
    this.root.id = 'ager-ui';
    this.root.style.cssText = 'position:fixed;inset:0;pointer-events:none;font-family:ui-monospace,Menlo,Consolas,monospace;color:#dff6ff;z-index:10';
    document.body.appendChild(this.root);
    this.toasts = document.createElement('div');
    this.toasts.style.cssText = 'position:absolute;left:18px;bottom:96px;display:flex;flex-direction:column;gap:6px;max-width:520px';
    this.root.appendChild(this.toasts);
    this.statsEl = document.createElement('div');
    this.statsEl.style.cssText = 'position:absolute;right:12px;top:10px;font-size:11px;line-height:1.45;text-align:right;opacity:0.85;text-shadow:0 1px 2px #000;white-space:pre';
    this.root.appendChild(this.statsEl);
    this.showStats = true;
    this._acc = 0;
    this.console = new AgerConsole(this);
    addEventListener('keydown', (e) => {
      if (e.code === 'F3') { e.preventDefault(); this.showStats = !this.showStats; this.statsEl.style.display = this.showStats ? '' : 'none'; }
      if (e.code === 'Backquote') { e.preventDefault(); this.console.toggle(); }
    });
  }
  toast(text, ms = 2600, color = '#9fe8ff') {
    const el = document.createElement('div');
    el.textContent = text;
    el.style.cssText = `background:rgba(6,14,20,0.72);border-left:3px solid ${color};padding:6px 10px;font-size:12.5px;letter-spacing:0.02em;text-shadow:0 1px 2px #000;transition:opacity .3s`;
    this.toasts.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 320); }, ms);
    return el;
  }
  tick(dt, stats) {
    this._acc += dt;
    if (this._acc < 0.25) return;
    this._acc = 0;
    if (!this.showStats) return;
    const gb = (stats.triangles / 1e6).toFixed(2);
    this.statsEl.textContent =
      `AGER ${AGER_VERSION}\n` +
      `${stats.fps} fps  ${stats.frameMs} ms  ${stats.resolution} [${stats.quality}]\n` +
      `${stats.drawCalls} draws  ${gb}M tris  ${stats.shadowDraws} shadow\n` +
      `${stats.entities} entities  ${stats.lights} lights  ${stats.physicsBodies} bodies`;
  }
}

class AgerConsole {
  constructor(ui) {
    this.ui = ui;
    this.el = document.createElement('div');
    this.el.style.cssText = 'position:absolute;left:50%;bottom:24px;transform:translateX(-50%);width:min(760px,92vw);pointer-events:auto;display:none';
    this.el.innerHTML = `
      <div style="background:rgba(4,10,14,0.92);border:1px solid rgba(90,200,255,0.35);box-shadow:0 12px 40px rgba(0,0,0,0.6);backdrop-filter:blur(4px)">
        <div id="ager-console-log" style="max-height:210px;overflow:auto;padding:10px 12px;font-size:12.5px;line-height:1.5;white-space:pre-wrap"></div>
        <div style="display:flex;align-items:center;border-top:1px solid rgba(90,200,255,0.22)">
          <span style="padding:0 8px;color:#5ad2ff;font-size:13px">&gt;</span>
          <input id="ager-console-input" spellcheck="false" autocomplete="off" placeholder="talk to the engine — e.g. &quot;spawn 12 crates near me&quot;, &quot;night&quot;, &quot;help&quot;"
            style="flex:1;background:transparent;border:0;outline:0;color:#eafaff;font-family:inherit;font-size:13px;padding:9px 8px 9px 0">
        </div>
      </div>`;
    ui.root.appendChild(this.el);
    this.log = this.el.querySelector('#ager-console-log');
    this.input = this.el.querySelector('#ager-console-input');
    this.open = false;
    this.input.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') { this.submit(this.input.value); this.input.value = ''; }
      if (e.key === 'Escape') this.toggle(false);
    });
    this.print(AgerAI.describeText());
    this.print('type "help" or a sentence — the engine parses it.');
  }
  print(text, color = '#b9e9ff') {
    const div = document.createElement('div');
    div.textContent = text;
    div.style.color = color;
    this.log.appendChild(div);
    this.log.scrollTop = this.log.scrollHeight;
    while (this.log.childNodes.length > 120) this.log.removeChild(this.log.firstChild);
  }
  submit(text) {
    if (!text.trim()) return;
    this.print('> ' + text, '#7ef7c8');
    const out = Ager.say(text);
    this.print(out, '#ffe9a8');
    return out;
  }
  toggle(force) {
    this.open = force !== undefined ? force : !this.open;
    this.el.style.display = this.open ? 'block' : 'none';
    if (this.open) { this.input.focus(); if (document.exitPointerLock) document.exitPointerLock(); }
    else if (Engine && Engine.input && Engine.input.mouse.locked === false && Engine.canvas) Engine.input.requestLock();
  }
}
