// ===========================================================================
//  AGER ENGINE  ·  00-core  ·  math, time, random, noise, utilities
//  A next-gen web engine. Zero dependencies. Runs on WebGL2.
// ===========================================================================
'use strict';

const AGER_VERSION = '1.0.0-crucible';
const TAU = Math.PI * 2;
const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const smoothstep = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
const smootherstep = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * t * (t * (t * 6 - 15) + 10); };
const damp = (a, b, lambda, dt) => lerp(a, b, 1 - Math.exp(-lambda * dt));
const mod = (a, n) => ((a % n) + n) % n;
const sign = Math.sign;
const fract = (x) => x - Math.floor(x);
const approach = (cur, target, delta) => cur < target ? Math.min(cur + delta, target) : Math.max(cur - delta, target);
const randRange = (a, b) => a + Math.random() * (b - a);
const randInt = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
const pick = (arr) => arr[(Math.random() * arr.length) | 0];
const now = () => performance.now() / 1000;

// --- deterministic hash / noise -------------------------------------------
function hash1(n) { const s = Math.sin(n * 127.1) * 43758.5453123; return s - Math.floor(s); }
function hash2(x, y) { const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123; return s - Math.floor(s); }
function hash3(x, y, z) { const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453123; return s - Math.floor(s); }

function valueNoise2(x, y) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi), b = hash2(xi + 1, yi), c = hash2(xi, yi + 1), d = hash2(xi + 1, yi + 1);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
function valueNoise3(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
  const n = (i, j, k) => hash3(xi + i, yi + j, zi + k);
  const x00 = lerp(n(0, 0, 0), n(1, 0, 0), u), x10 = lerp(n(0, 1, 0), n(1, 1, 0), u);
  const x01 = lerp(n(0, 0, 1), n(1, 0, 1), u), x11 = lerp(n(0, 1, 1), n(1, 1, 1), u);
  return lerp(lerp(x00, x10, v), lerp(x01, x11, v), w);
}
function fbm2(x, y, oct = 5, lac = 2.0, gain = 0.5) {
  let a = 0.5, f = 1, s = 0, norm = 0;
  for (let i = 0; i < oct; i++) { s += a * valueNoise2(x * f, y * f); norm += a; a *= gain; f *= lac; }
  return s / norm;
}
function fbm3(x, y, z, oct = 4, lac = 2.0, gain = 0.5) {
  let a = 0.5, f = 1, s = 0, norm = 0;
  for (let i = 0; i < oct; i++) { s += a * valueNoise3(x * f, y * f, z * f); norm += a; a *= gain; f *= lac; }
  return s / norm;
}
function ridged2(x, y, oct = 5) {
  let a = 0.5, f = 1, s = 0, norm = 0;
  for (let i = 0; i < oct; i++) { s += a * (1 - Math.abs(valueNoise2(x * f, y * f) * 2 - 1)); norm += a; a *= 0.5; f *= 2.07; }
  return s / norm;
}
function worley2(x, y, seed = 0) {
  const xi = Math.floor(x), yi = Math.floor(y);
  let best = 1e9, second = 1e9;
  for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
    const cx = xi + i, cy = yi + j;
    const px = cx + hash2(cx + seed * 13.7, cy - seed * 7.3);
    const py = cy + hash2(cx - seed * 3.1, cy + seed * 5.9);
    const d = (px - x) * (px - x) + (py - y) * (py - y);
    if (d < best) { second = best; best = d; } else if (d < second) second = d;
  }
  return { f1: Math.sqrt(best), f2: Math.sqrt(second), edge: Math.sqrt(second) - Math.sqrt(best) };
}

// --- Mat4 ------------------------------------------------------------------
const Mat4 = {
  create() { return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); },
  identity(o) { o.set([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); return o; },
  copy(o, a) { o.set(a); return o; },
  mul(o, a, b) {
    const a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3], a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7],
      a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11], a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
    for (let i = 0; i < 4; i++) {
      const b0 = b[i * 4], b1 = b[i * 4 + 1], b2 = b[i * 4 + 2], b3 = b[i * 4 + 3];
      o[i * 4] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
      o[i * 4 + 1] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
      o[i * 4 + 2] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
      o[i * 4 + 3] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
    }
    return o;
  },
  perspective(o, fovY, aspect, near, far) {
    const f = 1 / Math.tan(fovY / 2), nf = 1 / (near - far);
    o.set([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
    return o;
  },
  ortho(o, l, r, b, t, n, f) {
    o.set([2 / (r - l), 0, 0, 0, 0, 2 / (t - b), 0, 0, 0, 0, -2 / (f - n), 0,
      -(r + l) / (r - l), -(t + b) / (t - b), -(f + n) / (f - n), 1]);
    return o;
  },
  lookAt(o, eye, center, up) {
    let z0 = eye[0] - center[0], z1 = eye[1] - center[1], z2 = eye[2] - center[2];
    let len = Math.hypot(z0, z1, z2) || 1; z0 /= len; z1 /= len; z2 /= len;
    let x0 = up[1] * z2 - up[2] * z1, x1 = up[2] * z0 - up[0] * z2, x2 = up[0] * z1 - up[1] * z0;
    len = Math.hypot(x0, x1, x2); if (len < 1e-6) { x0 = 1; x1 = 0; x2 = 0; } else { x0 /= len; x1 /= len; x2 /= len; }
    const y0 = z1 * x2 - z2 * x1, y1 = z2 * x0 - z0 * x2, y2 = z0 * x1 - z1 * x0;
    o.set([x0, y0, z0, 0, x1, y1, z1, 0, x2, y2, z2, 0,
      -(x0 * eye[0] + x1 * eye[1] + x2 * eye[2]), -(y0 * eye[0] + y1 * eye[1] + y2 * eye[2]), -(z0 * eye[0] + z1 * eye[1] + z2 * eye[2]), 1]);
    return o;
  },
  fromTRS(o, p, q, s) {
    const x = q[0], y = q[1], z = q[2], w = q[3];
    const x2 = x + x, y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2, yy = y * y2, yz = y * z2, zz = z * z2, wx = w * x2, wy = w * y2, wz = w * z2;
    const sx = s ? s[0] : 1, sy = s ? s[1] : 1, sz = s ? s[2] : 1;
    o[0] = (1 - (yy + zz)) * sx; o[1] = (xy + wz) * sx; o[2] = (xz - wy) * sx; o[3] = 0;
    o[4] = (xy - wz) * sy; o[5] = (1 - (xx + zz)) * sy; o[6] = (yz + wx) * sy; o[7] = 0;
    o[8] = (xz + wy) * sz; o[9] = (yz - wx) * sz; o[10] = (1 - (xx + yy)) * sz; o[11] = 0;
    o[12] = p[0]; o[13] = p[1]; o[14] = p[2]; o[15] = 1;
    return o;
  },
  invert(o, m) {
    const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3], a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7],
      a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11], a30 = m[12], a31 = m[13], a32 = m[14], a33 = m[15];
    const b00 = a00 * a11 - a01 * a10, b01 = a00 * a12 - a02 * a10, b02 = a00 * a13 - a03 * a10,
      b03 = a01 * a12 - a02 * a11, b04 = a01 * a13 - a03 * a11, b05 = a02 * a13 - a03 * a12,
      b06 = a20 * a31 - a21 * a30, b07 = a20 * a32 - a22 * a30, b08 = a20 * a33 - a23 * a30,
      b09 = a21 * a32 - a22 * a31, b10 = a21 * a33 - a23 * a31, b11 = a22 * a33 - a23 * a32;
    let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
    if (!det) return Mat4.identity(o);
    det = 1 / det;
    o[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det; o[1] = (a02 * b10 - a01 * b11 - a03 * b09) * det;
    o[2] = (a31 * b05 - a32 * b04 + a33 * b03) * det; o[3] = (a22 * b04 - a21 * b05 - a23 * b03) * det;
    o[4] = (a12 * b08 - a10 * b11 - a13 * b07) * det; o[5] = (a00 * b11 - a02 * b08 + a03 * b07) * det;
    o[6] = (a32 * b02 - a30 * b05 - a33 * b01) * det; o[7] = (a20 * b05 - a22 * b02 + a23 * b01) * det;
    o[8] = (a10 * b10 - a11 * b08 + a13 * b06) * det; o[9] = (a01 * b08 - a00 * b10 - a03 * b06) * det;
    o[10] = (a30 * b04 - a31 * b02 + a33 * b00) * det; o[11] = (a21 * b02 - a20 * b04 - a23 * b00) * det;
    o[12] = (a11 * b07 - a10 * b09 - a12 * b06) * det; o[13] = (a00 * b09 - a01 * b07 + a02 * b06) * det;
    o[14] = (a31 * b01 - a30 * b03 - a32 * b00) * det; o[15] = (a20 * b03 - a21 * b01 + a22 * b00) * det;
    return o;
  },
  transpose(o, a) {
    if (o === a) {
      let t;
      t = a[1]; o[1] = a[4]; o[4] = t; t = a[2]; o[2] = a[8]; o[8] = t; t = a[3]; o[3] = a[12]; o[12] = t;
      t = a[6]; o[6] = a[9]; o[9] = t; t = a[7]; o[7] = a[13]; o[13] = t; t = a[11]; o[11] = a[14]; o[14] = t;
      return o;
    }
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) o[i * 4 + j] = a[j * 4 + i];
    return o;
  },
  normalMatrix(o3, m) {
    const a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6], g = m[8], h = m[9], i = m[10];
    const C00 = e * i - f * h, C01 = -(d * i - f * g), C02 = d * h - e * g;
    let det = a * C00 + b * C01 + c * C02;
    det = det ? 1 / det : 1;
    // inverse-transpose of upper 3x3
    const i00 = C00 * det, i01 = -(b * i - c * h) * det, i02 = (b * f - c * e) * det;
    const i10 = C01 * det, i11 = (a * i - c * g) * det, i12 = -(a * f - c * d) * det;
    const i20 = C02 * det, i21 = -(a * h - b * g) * det, i22 = (a * e - b * d) * det;
    o3[0] = i00; o3[1] = i10; o3[2] = i20;
    o3[3] = i01; o3[4] = i11; o3[5] = i21;
    o3[6] = i02; o3[7] = i12; o3[8] = i22;
    return o3;
  },
  transformPoint(o, m, p) {
    const x = p[0], y = p[1], z = p[2];
    let w = m[3] * x + m[7] * y + m[11] * z + m[15]; w = w || 1;
    o[0] = (m[0] * x + m[4] * y + m[8] * z + m[12]) / w;
    o[1] = (m[1] * x + m[5] * y + m[9] * z + m[13]) / w;
    o[2] = (m[2] * x + m[6] * y + m[10] * z + m[14]) / w;
    return o;
  },
  transformDir(o, m, p) {
    const x = p[0], y = p[1], z = p[2];
    o[0] = m[0] * x + m[4] * y + m[8] * z;
    o[1] = m[1] * x + m[5] * y + m[9] * z;
    o[2] = m[2] * x + m[6] * y + m[10] * z;
    return o;
  },
  getTranslation(o, m) { o[0] = m[12]; o[1] = m[13]; o[2] = m[14]; return o; },
};

// --- Quat ------------------------------------------------------------------
const Quat = {
  create() { return new Float32Array([0, 0, 0, 1]); },
  identity(o) { o[0] = o[1] = o[2] = 0; o[3] = 1; return o; },
  setAxisAngle(o, axis, rad) {
    const h = rad * 0.5, s = Math.sin(h);
    const len = Math.hypot(axis[0], axis[1], axis[2]) || 1;
    o[0] = axis[0] / len * s; o[1] = axis[1] / len * s; o[2] = axis[2] / len * s; o[3] = Math.cos(h);
    return o;
  },
  fromEuler(o, x, y, z) {
    const c1 = Math.cos(x / 2), c2 = Math.cos(y / 2), c3 = Math.cos(z / 2);
    const s1 = Math.sin(x / 2), s2 = Math.sin(y / 2), s3 = Math.sin(z / 2);
    o[0] = s1 * c2 * c3 + c1 * s2 * s3; o[1] = c1 * s2 * c3 - s1 * c2 * s3;
    o[2] = c1 * c2 * s3 - s1 * s2 * c3; o[3] = c1 * c2 * c3 + s1 * s2 * s3;
    return o;
  },
  mul(o, a, b) {
    const ax = a[0], ay = a[1], az = a[2], aw = a[3], bx = b[0], by = b[1], bz = b[2], bw = b[3];
    o[0] = ax * bw + aw * bx + ay * bz - az * by;
    o[1] = ay * bw + aw * by + az * bx - ax * bz;
    o[2] = az * bw + aw * bz + ax * by - ay * bx;
    o[3] = aw * bw - ax * bx - ay * by - az * bz;
    return o;
  },
  slerp(o, a, b, t) {
    let ax = a[0], ay = a[1], az = a[2], aw = a[3], bx = b[0], by = b[1], bz = b[2], bw = b[3];
    let cos = ax * bx + ay * by + az * bz + aw * bw;
    if (cos < 0) { cos = -cos; bx = -bx; by = -by; bz = -bz; bw = -bw; }
    if (cos > 0.9995) {
      o[0] = lerp(ax, bx, t); o[1] = lerp(ay, by, t); o[2] = lerp(az, bz, t); o[3] = lerp(aw, bw, t);
    } else {
      const theta = Math.acos(clamp(cos, -1, 1)), s = Math.sin(theta);
      const r0 = Math.sin((1 - t) * theta) / s, r1 = Math.sin(t * theta) / s;
      o[0] = ax * r0 + bx * r1; o[1] = ay * r0 + by * r1; o[2] = az * r0 + bz * r1; o[3] = aw * r0 + bw * r1;
    }
    const l = Math.hypot(o[0], o[1], o[2], o[3]) || 1;
    o[0] /= l; o[1] /= l; o[2] /= l; o[3] /= l;
    return o;
  },
  lookRotation(o, fwd, up = [0, 1, 0]) {
    let zx = -fwd[0], zy = -fwd[1], zz = -fwd[2];
    let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
    let x0 = up[1] * zz - up[2] * zy, x1 = up[2] * zx - up[0] * zz, x2 = up[0] * zy - up[1] * zx;
    l = Math.hypot(x0, x1, x2); if (l < 1e-6) { x0 = 1; x1 = 0; x2 = 0; } else { x0 /= l; x1 /= l; x2 /= l; }
    const y0 = zy * x2 - zz * x1, y1 = zz * x0 - zx * x2, y2 = zx * x1 - zy * x0;
    const m = [x0, y0, zx, 0, x1, y1, zy, 0, x2, y2, zz, 0, 0, 0, 0, 1];
    // matrix -> quat
    const tr = x0 + y1 + zz;
    if (tr > 0) {
      const s = Math.sqrt(tr + 1) * 2;
      o[3] = 0.25 * s; o[0] = (y2 - zy) / s; o[1] = (zx - x2) / s; o[2] = (x1 - y0) / s;
    } else if (x0 > y1 && x0 > zz) {
      const s = Math.sqrt(1 + x0 - y1 - zz) * 2;
      o[3] = (y2 - zy) / s; o[0] = 0.25 * s; o[1] = (y0 + x1) / s; o[2] = (zx + x2) / s;
    } else if (y1 > zz) {
      const s = Math.sqrt(1 + y1 - x0 - zz) * 2;
      o[3] = (zx - x2) / s; o[0] = (y0 + x1) / s; o[1] = 0.25 * s; o[2] = (zy + y2) / s;
    } else {
      const s = Math.sqrt(1 + zz - x0 - y1) * 2;
      o[3] = (x1 - y0) / s; o[0] = (zx + x2) / s; o[1] = (zy + y2) / s; o[2] = 0.25 * s;
    }
    return o;
  }
};

// --- Vec3 ------------------------------------------------------------------
const Vec3 = {
  create(x = 0, y = 0, z = 0) { return new Float32Array([x, y, z]); },
  of(v) { return new Float32Array(v); },
  set(o, x, y, z) { o[0] = x; o[1] = y; o[2] = z; return o; },
  copy(o, a) { o[0] = a[0]; o[1] = a[1]; o[2] = a[2]; return o; },
  add(o, a, b) { o[0] = a[0] + b[0]; o[1] = a[1] + b[1]; o[2] = a[2] + b[2]; return o; },
  sub(o, a, b) { o[0] = a[0] - b[0]; o[1] = a[1] - b[1]; o[2] = a[2] - b[2]; return o; },
  mul(o, a, b) { o[0] = a[0] * b[0]; o[1] = a[1] * b[1]; o[2] = a[2] * b[2]; return o; },
  scale(o, a, s) { o[0] = a[0] * s; o[1] = a[1] * s; o[2] = a[2] * s; return o; },
  madd(o, a, b, s) { o[0] = a[0] + b[0] * s; o[1] = a[1] + b[1] * s; o[2] = a[2] + b[2] * s; return o; },
  len(a) { return Math.hypot(a[0], a[1], a[2]); },
  len2(a) { return a[0] * a[0] + a[1] * a[1] + a[2] * a[2]; },
  dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]); },
  dist2(a, b) { const x = a[0] - b[0], y = a[1] - b[1], z = a[2] - b[2]; return x * x + y * y + z * z; },
  dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; },
  cross(o, a, b) {
    const ax = a[0], ay = a[1], az = a[2], bx = b[0], by = b[1], bz = b[2];
    o[0] = ay * bz - az * by; o[1] = az * bx - ax * bz; o[2] = ax * by - ay * bx; return o;
  },
  normalize(o, a) { const l = Math.hypot(a[0], a[1], a[2]) || 1; o[0] = a[0] / l; o[1] = a[1] / l; o[2] = a[2] / l; return o; },
  lerp(o, a, b, t) { o[0] = lerp(a[0], b[0], t); o[1] = lerp(a[1], b[1], t); o[2] = lerp(a[2], b[2], t); return o; },
  transformMat4(o, a, m) {
    const x = a[0], y = a[1], z = a[2];
    const w = m[3] * x + m[7] * y + m[11] * z + m[15] || 1;
    o[0] = (m[0] * x + m[4] * y + m[8] * z + m[12]) / w;
    o[1] = (m[1] * x + m[5] * y + m[9] * z + m[13]) / w;
    o[2] = (m[2] * x + m[6] * y + m[10] * z + m[14]) / w;
    return o;
  },
  reflect(o, v, n) { const d = Vec3.dot(v, n); o[0] = v[0] - 2 * d * n[0]; o[1] = v[1] - 2 * d * n[1]; o[2] = v[2] - 2 * d * n[2]; return o; },
  reflectXZ(o, v, n) { const d = v[0] * n[0] + v[1] * n[1] + v[2] * n[2]; return Vec3.set(o, v[0] - 2 * d * n[0], v[1] - 2 * d * n[1], v[2] - 2 * d * n[2]); },
};

// --- AABB / Ray / Frustum --------------------------------------------------
class AABB {
  constructor(min = [0, 0, 0], max = [0, 0, 0]) { this.min = Float32Array.from(min); this.max = Float32Array.from(max); }
  static fromCenterSize(c, s) {
    return new AABB([c[0] - s[0] / 2, c[1] - s[1] / 2, c[2] - s[2] / 2], [c[0] + s[0] / 2, c[1] + s[1] / 2, c[2] + s[2] / 2]);
  }
  set(min, max) { this.min.set(min); this.max.set(max); return this; }
  center(o = [0, 0, 0]) { o[0] = (this.min[0] + this.max[0]) / 2; o[1] = (this.min[1] + this.max[1]) / 2; o[2] = (this.min[2] + this.max[2]) / 2; return o; }
  size(o = [0, 0, 0]) { o[0] = this.max[0] - this.min[0]; o[1] = this.max[1] - this.min[1]; o[2] = this.max[2] - this.min[2]; return o; }
  expand(p, r = 0) {
    this.min[0] = Math.min(this.min[0], p[0] - r); this.min[1] = Math.min(this.min[1], p[1] - r); this.min[2] = Math.min(this.min[2], p[2] - r);
    this.max[0] = Math.max(this.max[0], p[0] + r); this.max[1] = Math.max(this.max[1], p[1] + r); this.max[2] = Math.max(this.max[2], p[2] + r);
    return this;
  }
  union(b) {
    for (let i = 0; i < 3; i++) { this.min[i] = Math.min(this.min[i], b.min[i]); this.max[i] = Math.max(this.max[i], b.max[i]); }
    return this;
  }
  containsPoint(p) { return p[0] >= this.min[0] && p[0] <= this.max[0] && p[1] >= this.min[1] && p[1] <= this.max[1] && p[2] >= this.min[2] && p[2] <= this.max[2]; }
  intersects(b) {
    return this.min[0] <= b.max[0] && this.max[0] >= b.min[0] && this.min[1] <= b.max[1] && this.max[1] >= b.min[1] &&
      this.min[2] <= b.max[2] && this.max[2] >= b.min[2];
  }
  intersectsSphere(c, r) {
    let d2 = 0;
    for (let i = 0; i < 3; i++) { const v = c[i] < this.min[i] ? this.min[i] - c[i] : (c[i] > this.max[i] ? c[i] - this.max[i] : 0); d2 += v * v; }
    return d2 <= r * r;
  }
  // slab test
  intersectsRay(o, d, tmax = 1e9) {
    let tmin = 0;
    for (let i = 0; i < 3; i++) {
      const inv = 1 / (d[i] || 1e-9);
      let t1 = (this.min[i] - o[i]) * inv, t2 = (this.max[i] - o[i]) * inv;
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
      if (tmin > tmax) return -1;
    }
    return tmin;
  }
  clone() { return new AABB(this.min, this.max); }
}

class Frustum {
  constructor() { this.planes = new Float32Array(24); }
  fromMatrix(m) {
    const p = this.planes;
    const set = (i, a, b, c, d) => {
      const len = Math.hypot(a, b, c) || 1;
      p[i * 4] = a / len; p[i * 4 + 1] = b / len; p[i * 4 + 2] = c / len; p[i * 4 + 3] = d / len;
    };
    set(0, m[3] + m[0], m[7] + m[4], m[11] + m[8], m[15] + m[12]);   // left
    set(1, m[3] - m[0], m[7] - m[4], m[11] - m[8], m[15] - m[12]);   // right
    set(2, m[3] + m[1], m[7] + m[5], m[11] + m[9], m[15] + m[13]);   // bottom
    set(3, m[3] - m[1], m[7] - m[5], m[11] - m[9], m[15] - m[13]);   // top
    set(4, m[3] + m[2], m[7] + m[6], m[11] + m[10], m[15] + m[14]);  // near
    set(5, m[3] - m[2], m[7] - m[6], m[11] - m[10], m[15] - m[14]);  // far
    return this;
  }
  intersectsAABB(b) {
    const p = this.planes;
    for (let i = 0; i < 6; i++) {
      const a = p[i * 4], bb = p[i * 4 + 1], c = p[i * 4 + 2], d = p[i * 4 + 3];
      const x = a > 0 ? b.max[0] : b.min[0], y = bb > 0 ? b.max[1] : b.min[1], z = c > 0 ? b.max[2] : b.min[2];
      if (a * x + bb * y + c * z + d < 0) return false;
    }
    return true;
  }
  intersectsSphere(c, r) {
    const p = this.planes;
    for (let i = 0; i < 6; i++) {
      if (p[i * 4] * c[0] + p[i * 4 + 1] * c[1] + p[i * 4 + 2] * c[2] + p[i * 4 + 3] < -r) return false;
    }
    return true;
  }
}

// --- misc utilities --------------------------------------------------------
class Clock {
  constructor() { this.t = 0; this.dt = 0; this.frame = 0; this.start = now(); this.fps = 60; this._acc = 0; this._n = 0; this._fpsT = 0; }
  tick() {
    const t = now();
    this.dt = Math.min(t - this.t, 0.1);
    if (this.t === 0) this.dt = 1 / 60;
    this.t = t; this.frame++;
    this._acc += this.dt; this._n++;
    if (this._acc > 0.25) { this.fps = this._n / this._acc; this._acc = 0; this._n = 0; }
    return this.dt;
  }
}

class Signal {
  constructor() { this.handlers = []; }
  on(fn) { this.handlers.push(fn); return () => { const i = this.handlers.indexOf(fn); if (i >= 0) this.handlers.splice(i, 1); }; }
  emit(...args) { for (const h of this.handlers) { try { h(...args); } catch (e) { console.warn('[ager] handler error', e); } } }
  clear() { this.handlers.length = 0; }
}

// spatial hash for broadphase queries
class SpatialHash {
  constructor(cell = 4) { this.cell = cell; this.map = new Map(); }
  key(x, y, z) { return (x | 0) * 73856093 ^ (y | 0) * 19349663 ^ (z | 0) * 83492791; }
  insert(box, obj) {
    const c = this.cell;
    const x0 = Math.floor(box.min[0] / c), x1 = Math.floor(box.max[0] / c);
    const y0 = Math.floor(box.min[1] / c), y1 = Math.floor(box.max[1] / c);
    const z0 = Math.floor(box.min[2] / c), z1 = Math.floor(box.max[2] / c);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) {
      const k = this.key(x, y, z);
      let a = this.map.get(k); if (!a) { a = []; this.map.set(k, a); }
      a.push(obj);
    }
    return this;
  }
  query(box, out = []) {
    out.length = 0;
    const c = this.cell, seen = this._seen || (this._seen = new Set());
    seen.clear();
    const x0 = Math.floor(box.min[0] / c), x1 = Math.floor(box.max[0] / c);
    const y0 = Math.floor(box.min[1] / c), y1 = Math.floor(box.max[1] / c);
    const z0 = Math.floor(box.min[2] / c), z1 = Math.floor(box.max[2] / c);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) {
      const a = this.map.get(this.key(x, y, z));
      if (a) for (const o of a) if (!seen.has(o)) { seen.add(o); out.push(o); }
    }
    return out;
  }
  querySphere(c, r, out = []) {
    const b = new AABB([c[0] - r, c[1] - r, c[2] - r], [c[0] + r, c[1] + r, c[2] + r]);
    const cand = this.query(b, this._tmp || (this._tmp = []));
    out.length = 0;
    const r2 = r * r;
    for (const o of cand) if (o.box.intersectsSphere(c, r) || Vec3.dist2(o.center || o.box.center(this._c || (this._c = [0, 0, 0])), c) < r2) out.push(o);
    return out;
  }
  clear() { this.map.clear(); }
}

function colorToLinear(hex) {
  // hex (0xRRGGBB) -> linear rgb floats, sRGB->linear
  const r = ((hex >> 16) & 255) / 255, g = ((hex >> 8) & 255) / 255, b = (hex & 255) / 255;
  const f = (c) => c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  return [f(r), f(g), f(b)];
}
function hexToRgb(hex) { return [((hex >> 16) & 255) / 255, ((hex >> 8) & 255) / 255, (hex & 255) / 255]; }
function rgbToHex(c) {
  const f = (v) => { const s = v <= 0.0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - 0.055; return clamp(Math.round(s * 255), 0, 255); };
  return '#' + [f(c[0]), f(c[1]), f(c[2])].map(v => v.toString(16).padStart(2, '0')).join('');
}

class Pool {
  constructor(factory, reset, size = 64) { this.factory = factory; this.reset = reset; this.free = []; this.all = []; for (let i = 0; i < size; i++) this.grow(); }
  grow() { const o = this.factory(); this.all.push(o); this.free.push(o); return o; }
  get() { if (!this.free.length) this.grow(); return this.free.pop(); }
  put(o) { this.reset(o); this.free.push(o); }
}
